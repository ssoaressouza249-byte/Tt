package com.raylan.nexgt.security

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

data class IntegrityReport(
    val isValid: Boolean,
    val detectedPackage: String,
    val detectedLabel: String,
    val reason: String
)

object SecurityGuard {
    private const val EXPECTED_PACKAGE = "com.raylan.nexgt"
    private val ALLOWED_LABELS = setOf("NEXGT", "FF Boost")

    fun verify(context: Context): IntegrityReport {
        return runCatching {
            val pkg = context.packageName
            val appInfo = context.applicationInfo
            val pm = context.packageManager
            val label = runCatching {
                appInfo.loadLabel(pm).toString().trim()
            }.getOrDefault("")

            val pkgValid = pkg == EXPECTED_PACKAGE
            val labelValid = label in ALLOWED_LABELS

            when {
                !pkgValid -> IntegrityReport(
                    isValid = false,
                    detectedPackage = pkg,
                    detectedLabel = label,
                    reason = "Pacote adulterado detectado: $pkg (esperado: $EXPECTED_PACKAGE)."
                )
                !labelValid -> IntegrityReport(
                    isValid = false,
                    detectedPackage = pkg,
                    detectedLabel = label,
                    reason = "Nome do aplicativo modificado: '$label' (esperado: NEXGT ou FF Boost)."
                )
                else -> IntegrityReport(
                    isValid = true,
                    detectedPackage = pkg,
                    detectedLabel = label,
                    reason = "Integridade verificada."
                )
            }
        }.getOrElse { err ->
            IntegrityReport(
                isValid = false,
                detectedPackage = context.packageName,
                detectedLabel = "DESCONHECIDO",
                reason = "Falha na verificação de integridade: ${err.message}"
            )
        }
    }

    fun launchUninstall(context: Context) {
        runCatching {
            val intent = Intent(Intent.ACTION_DELETE).apply {
                data = Uri.parse("package:${context.packageName}")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        }
    }
}

@Composable
fun TamperBlockedScreen(report: IntegrityReport) {
    val context = LocalContext.current

    // Bloqueia o botão Voltar permanentemente nesta tela vermelha
    BackHandler(enabled = true) {}

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF8B0000))
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF450A0A), RoundedCornerShape(24.dp))
                .border(2.dp, Color(0xFFEF4444), RoundedCornerShape(24.dp))
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Icon(
                imageVector = Icons.Default.Security,
                contentDescription = "Alerta de Segurança",
                tint = Color(0xFFFCA5A5),
                modifier = Modifier.size(56.dp)
            )

            Text(
                text = "APLICATIVO MODIFICADO DETECTADO",
                color = Color.White,
                fontSize = 20.sp,
                fontWeight = FontWeight.ExtraBold,
                fontFamily = FontFamily.Default,
                textAlign = TextAlign.Center
            )

            Text(
                text = "O NEXGT / FF Boost identificou adulteração no pacote ou nome original do aplicativo. Por segurança, a execução foi bloqueada.",
                color = Color(0xFFFECACA),
                fontSize = 14.sp,
                fontFamily = FontFamily.Default,
                textAlign = TextAlign.Center
            )

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF2B0606), RoundedCornerShape(14.dp))
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    text = "Pacote: ${report.detectedPackage}",
                    color = Color(0xFFFCA5A5),
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = "Rótulo: ${report.detectedLabel}",
                    color = Color(0xFFFCA5A5),
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = report.reason,
                    color = Color.White,
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            Button(
                onClick = { SecurityGuard.launchUninstall(context) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFFEF4444),
                    contentColor = Color.White
                )
            ) {
                Text(
                    text = "DESINSTALAR AGORA",
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 15.sp,
                    fontFamily = FontFamily.Default
                )
            }

            Text(
                text = "NEXGT / FF Boost • Criado por Raylan",
                color = Color(0xFFFCA5A5).copy(alpha = 0.8f),
                fontSize = 11.sp,
                fontFamily = FontFamily.Default
            )
        }
    }
}
