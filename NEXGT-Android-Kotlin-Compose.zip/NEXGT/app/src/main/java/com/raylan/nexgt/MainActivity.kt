package com.raylan.nexgt

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.raylan.nexgt.data.NavTab
import com.raylan.nexgt.data.NexgtViewModel
import com.raylan.nexgt.security.SecurityGuard
import com.raylan.nexgt.security.TamperBlockedScreen
import com.raylan.nexgt.shizuku.ShizukuManager
import com.raylan.nexgt.ui.components.ActiveFunctionsDialog
import com.raylan.nexgt.ui.components.MasterTurboStickyBar
import com.raylan.nexgt.ui.components.NexgtBottomNavBar
import com.raylan.nexgt.ui.screens.AxManageScreen
import com.raylan.nexgt.ui.screens.Fps120Screen
import com.raylan.nexgt.ui.screens.GamesScreen
import com.raylan.nexgt.ui.screens.HomeScreen
import com.raylan.nexgt.ui.screens.ToolsScreen
import com.raylan.nexgt.ui.screens.TweaksScreen
import com.raylan.nexgt.ui.theme.LocalNexgtPalette
import com.raylan.nexgt.ui.theme.NexgtTheme

class MainActivity : ComponentActivity() {
    private val viewModel: NexgtViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val integrity = SecurityGuard.verify(this)

        setContent {
            if (!integrity.isValid) {
                TamperBlockedScreen(report = integrity)
            } else {
                val selectedTheme by viewModel.selectedTheme.collectAsState()
                NexgtTheme(selectedTheme = selectedTheme) {
                    NexgtMainScaffold(viewModel = viewModel)
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        runCatching {
            ShizukuManager.refreshState()
            viewModel.refreshHardware()
            viewModel.refreshInstalledApps()
        }
    }
}

@Composable
private fun NexgtMainScaffold(viewModel: NexgtViewModel) {
    val palette = LocalNexgtPalette.current
    var currentTab by remember { mutableStateOf(NavTab.HOME) }
    var showActiveFunctionsModal by remember { mutableStateOf(false) }
    val snackbarHostState = remember { SnackbarHostState() }

    val selectedTheme by viewModel.selectedTheme.collectAsState()
    val shizukuState by viewModel.shizukuState.collectAsState()
    val shizukuUid by viewModel.shizukuUid.collectAsState()
    val shizukuVersion by viewModel.shizukuVersion.collectAsState()
    val activeFunctionEntries by viewModel.activeFunctionEntries.collectAsState()
    val activeCount by viewModel.activeFunctionCount.collectAsState()
    val hardware by viewModel.hardwareInfo.collectAsState()
    val activeProfile by viewModel.activeProfile.collectAsState()
    val turboActive by viewModel.turboActive.collectAsState()
    val games by viewModel.games.collectAsState()
    val installedApps by viewModel.installedApps.collectAsState()
    val targetPackage by viewModel.targetGamePackage.collectAsState()
    val smartEngine by viewModel.smartEngine.collectAsState()
    val renderScale by viewModel.renderScale.collectAsState()
    val fps120Modules by viewModel.fps120Modules.collectAsState()
    val axManageModules by viewModel.axManageModules.collectAsState()
    val tweaks by viewModel.tweaks.collectAsState()
    val fpsOverlayActive by viewModel.fpsOverlayActive.collectAsState()
    val nativeShowFps by viewModel.nativeShowFps.collectAsState()
    val floatingPanelActive by viewModel.floatingPanelActive.collectAsState()
    val bankMode by viewModel.bankMode.collectAsState()
    val logs by viewModel.logs.collectAsState()
    val banner by viewModel.statusBanner.collectAsState()
    val systemScore by viewModel.systemScore.collectAsState()
    val weeklyStats by viewModel.weeklyStats.collectAsState()
    val lastCleanResult by viewModel.lastCleanResult.collectAsState()
    val isCleaningRam by viewModel.isCleaningRam.collectAsState()
    val dpiState by viewModel.dpiState.collectAsState()
    val shaderCleanResult by viewModel.shaderCleanResult.collectAsState()
    val dnsShieldState by viewModel.dnsShieldState.collectAsState()
    val smoothRecorderState by viewModel.smoothRecorderState.collectAsState()
    val coolDownState by viewModel.coolDownState.collectAsState()
    val hudProfiles by viewModel.hudProfiles.collectAsState()
    val edgeLockState by viewModel.edgeLockState.collectAsState()

    val context = LocalContext.current
    val notifPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            viewModel.previewWeeklyNotification()
        }
    }

    LaunchedEffect(banner) {
        val msg = banner ?: return@LaunchedEffect
        snackbarHostState.showSnackbar(msg)
        viewModel.clearBanner()
    }

    Scaffold(
        containerColor = palette.oledBackground,
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        bottomBar = {
            Column(modifier = Modifier.fillMaxWidth()) {
                MasterTurboStickyBar(
                    turboActive = turboActive,
                    activeCount = activeCount,
                    onToggle = { viewModel.toggleMasterTurbo() },
                    onShowActiveList = { showActiveFunctionsModal = true }
                )
                NexgtBottomNavBar(
                    currentTab = currentTab,
                    onSelectTab = { currentTab = it }
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(palette.oledBackground)
                .padding(innerPadding)
        ) {
            when (currentTab) {
                NavTab.HOME -> HomeScreen(
                    shizukuState = shizukuState,
                    activeCount = activeCount,
                    hardware = hardware,
                    activeProfile = activeProfile,
                    favorites = tweaks.filter { it.isFavorite },
                    systemScore = systemScore,
                    weeklyStats = weeklyStats,
                    lastCleanResult = lastCleanResult,
                    isCleaningRam = isCleaningRam,
                    onConnectShizuku = { viewModel.connectShizuku() },
                    onSelectProfile = { viewModel.selectProfile(it) },
                    onToggleTweak = { viewModel.toggleTweak(it) },
                    onRunDeepRamClean = { viewModel.runDeepRamClean3Steps() },
                    onOpenActiveFunctions = { showActiveFunctionsModal = true },
                    onNavigateTab = { currentTab = it }
                )

                NavTab.GAMES -> GamesScreen(
                    games = games,
                    installedApps = installedApps,
                    targetPackage = targetPackage,
                    smartEngine = smartEngine,
                    renderScale = renderScale,
                    onSelectGame = { viewModel.selectTargetGame(it) },
                    onAddGame = { viewModel.addGame(it) },
                    onToggleSmartFeature = { viewModel.toggleSmartEngine(it) },
                    onSelectRenderScale = { viewModel.setRenderScale(it) }
                )

                NavTab.FPS_120 -> Fps120Screen(
                    games = games,
                    targetPackage = targetPackage,
                    modules = fps120Modules,
                    fpsOverlayActive = fpsOverlayActive,
                    nativeShowFps = nativeShowFps,
                    onSelectTargetGame = { viewModel.selectTargetGame(it) },
                    onUnlockExtremeOneTap = { viewModel.unlock120FpsExtremeOneTap() },
                    onToggleModule = { viewModel.toggleFpsModule(it) },
                    onToggleFpsOverlay = { viewModel.toggleFpsOverlay() },
                    onToggleNativeShowFps = { viewModel.toggleNativeShowFps() },
                    onRestoreFactoryFps = { viewModel.restoreFactoryFps() }
                )

                NavTab.TWEAKS -> TweaksScreen(
                    tweaks = tweaks,
                    onToggleTweak = { viewModel.toggleTweak(it) },
                    onToggleCategory = { cat, enable -> viewModel.toggleCategoryTweaks(cat, enable) }
                )

                NavTab.AX_MANAGE -> AxManageScreen(
                    modules = axManageModules,
                    targetPackage = targetPackage,
                    onToggleModule = { viewModel.toggleAxManageModule(it) },
                    onToggleAll = { enable -> viewModel.toggleAllAxManageModules(enable) }
                )

                NavTab.TOOLS -> ToolsScreen(
                    selectedTheme = selectedTheme,
                    targetPackage = targetPackage,
                    shizukuState = shizukuState,
                    shizukuUid = shizukuUid,
                    shizukuVersion = shizukuVersion,
                    floatingPanelActive = floatingPanelActive,
                    bankMode = bankMode,
                    activeTweaks = tweaks.filter { it.enabled },
                    installedApps = installedApps,
                    logs = logs,
                    systemScore = systemScore,
                    weeklyStats = weeklyStats,
                    lastCleanResult = lastCleanResult,
                    isCleaningRam = isCleaningRam,
                    dpiState = dpiState,
                    shaderCleanResult = shaderCleanResult,
                    dnsShieldState = dnsShieldState,
                    smoothRecorderState = smoothRecorderState,
                    coolDownState = coolDownState,
                    hudProfiles = hudProfiles,
                    edgeLockState = edgeLockState,
                    onSelectTheme = { viewModel.selectTheme(it) },
                    onToggleFloatingPanel = { viewModel.toggleFloatingPanelOverlay() },
                    onConnectShizuku = { viewModel.connectShizuku() },
                    onRunTerminalCommand = { viewModel.runCustomTerminalCommand(it) },
                    onToggleFreezeApp = { viewModel.toggleFreezeApp(it) },
                    onUnfreezeAllApps = { viewModel.unfreezeAllUserApps() },
                    onRunDeepRamClean = { viewModel.runDeepRamClean3Steps() },
                    onToggleWeeklyReport = { viewModel.toggleWeeklyReport() },
                    onPreviewWeeklyNotification = {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                        ) {
                            notifPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                        } else {
                            viewModel.previewWeeklyNotification()
                        }
                    },
                    onApplySafeDpi = { viewModel.applySafeDpi(it) },
                    onConfirmKeepDpi = { viewModel.confirmKeepDpi() },
                    onRestoreBackupDpi = { viewModel.restoreBackupDpi(isAutoRevert = false) },
                    onResetFactoryDpi = { viewModel.resetFactoryDpi() },
                    onClearDpiError = { viewModel.clearDpiError() },
                    onCleanShaders = { viewModel.cleanGameShaderCache() },
                    onActivateDnsShield = { viewModel.activatePingDnsShield() },
                    onDisableDnsShield = { viewModel.disableDnsShield() },
                    onToggleSmoothRecorder = { pkg, label -> viewModel.toggleSmoothRecorder(pkg, label) },
                    onStartCoolDown = { viewModel.startCoolDown() },
                    onStopCoolDown = { viewModel.stopCoolDown(completed = false) },
                    onSaveHudProfile = { name, dpi, general, redDot, s2x, s4x, awm, notes ->
                        viewModel.saveHudProfile(name, dpi, general, redDot, s2x, s4x, awm, notes)
                    },
                    onApplyHudProfile = { viewModel.applyHudProfile(it) },
                    onDeleteHudProfile = { viewModel.deleteHudProfile(it) },
                    onSetEdgeLockScope = { viewModel.setEdgeLockScope(it) },
                    onToggleEdgeLock = { viewModel.toggleEdgeLock() },
                    onApplySetting = { table, key, value -> viewModel.applySettingsEditor(table, key, value) },
                    onToggleBankMode = { viewModel.toggleBankMode() },
                    onRestoreAll = { viewModel.restoreAllTweaks() },
                    onUninstallWithCleanup = { viewModel.uninstallWithCleanup() }
                )
            }
        }
    }

    if (showActiveFunctionsModal) {
        ActiveFunctionsDialog(
            entries = activeFunctionEntries,
            onDisableOne = { viewModel.disableActiveEntry(it) },
            onDisableAll = { viewModel.restoreAllTweaks() },
            onDismiss = { showActiveFunctionsModal = false }
        )
    }
}
