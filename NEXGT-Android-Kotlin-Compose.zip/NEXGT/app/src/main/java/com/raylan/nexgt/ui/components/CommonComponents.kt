package com.raylan.nexgt.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Extension
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.raylan.nexgt.data.ActiveFunctionEntry
import com.raylan.nexgt.data.FeatureRiskLevel
import com.raylan.nexgt.data.HardwareHelpContent
import com.raylan.nexgt.data.NavTab
import com.raylan.nexgt.ui.theme.LocalNexgtPalette

@Composable
fun NexgtCard(
    modifier: Modifier = Modifier,
    highlighted: Boolean = false,
    dimmed: Boolean = false,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val palette = LocalNexgtPalette.current
    val shape = RoundedCornerShape(16.dp)
    val borderColor by animateColorAsState(
        targetValue = if (highlighted) palette.accent else palette.subtleBorder,
        animationSpec = tween(durationMillis = 150),
        label = "card_border"
    )
    val bgColor by animateColorAsState(
        targetValue = if (highlighted) Color(0xFF1A1217) else palette.cardSurface,
        animationSpec = tween(durationMillis = 150),
        label = "card_bg"
    )

    val baseModifier = modifier
        .alpha(if (dimmed) 0.58f else 1f)
        .clip(shape)
        .background(bgColor)
        .border(width = if (highlighted) 1.5.dp else 1.dp, color = borderColor, shape = shape)
        .let { if (onClick != null) it.clickable { onClick() } else it }
        .padding(14.dp)

    Column(modifier = baseModifier, content = content)
}

@Composable
fun RiskTagBadge(risk: FeatureRiskLevel) {
    val (color, bg) = when (risk) {
        FeatureRiskLevel.SAFE -> Color(0xFF34D399) to Color(0x2210B981)
        FeatureRiskLevel.ADVANCED -> Color(0xFFFBBF24) to Color(0x22F59E0B)
        FeatureRiskLevel.HARDWARE -> Color(0xFF38BDF8) to Color(0x2206B6D4)
    }
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(bg)
            .border(1.dp, color.copy(alpha = 0.45f), RoundedCornerShape(6.dp))
            .padding(horizontal = 6.dp, vertical = 2.dp)
    ) {
        Text(
            text = risk.label,
            color = color,
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Default
        )
    }
}

@Composable
fun FeatureHelpButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val palette = LocalNexgtPalette.current
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(Color(0xFF1A1A22))
            .border(1.dp, palette.subtleBorder, RoundedCornerShape(8.dp))
            .clickable { onClick() }
            .padding(horizontal = 8.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Icon(
            imageVector = Icons.Default.HelpOutline,
            contentDescription = "Ajuda",
            tint = palette.accent,
            modifier = Modifier.size(13.dp)
        )
        Text(
            text = "Ajuda",
            color = palette.textPrimary,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
fun NexgtSwitch(
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    val palette = LocalNexgtPalette.current
    Switch(
        checked = checked,
        onCheckedChange = onCheckedChange,
        colors = SwitchDefaults.colors(
            checkedThumbColor = Color.White,
            checkedTrackColor = palette.accent,
            uncheckedThumbColor = palette.textSecondary,
            uncheckedTrackColor = Color(0xFF1D1D24),
            uncheckedBorderColor = palette.subtleBorder
        )
    )
}

@Composable
fun MasterTurboStickyBar(
    turboActive: Boolean,
    activeCount: Int,
    onToggle: () -> Unit,
    onShowActiveList: () -> Unit = {}
) {
    val palette = LocalNexgtPalette.current
    val bgColor by animateColorAsState(
        targetValue = if (turboActive) palette.accent else Color(0xFF15151B),
        animationSpec = tween(durationMillis = 150),
        label = "turbo_bg"
    )

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(palette.oledBackground)
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Button(
            onClick = onToggle,
            modifier = Modifier
                .weight(1f)
                .height(48.dp)
                .border(1.5.dp, palette.accent, RoundedCornerShape(14.dp)),
            shape = RoundedCornerShape(14.dp),
            contentPadding = PaddingValues(horizontal = 12.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = bgColor,
                contentColor = Color.White
            )
        ) {
            Icon(
                imageVector = Icons.Default.Bolt,
                contentDescription = null,
                tint = if (turboActive) Color.White else palette.accent,
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = if (turboActive) "DESATIVAR TURBINA JOGOS" else "ATIVAR TURBINA JOGOS",
                fontWeight = FontWeight.ExtraBold,
                fontSize = 12.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }

        Box(
            modifier = Modifier
                .height(48.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(Color(0xFF16161D))
                .border(1.dp, palette.subtleBorder, RoundedCornerShape(14.dp))
                .clickable { onShowActiveList() }
                .padding(horizontal = 12.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "$activeCount ativas",
                color = Color.White,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
        }
    }
}

@Composable
fun NexgtBottomNavBar(
    currentTab: NavTab,
    onSelectTab: (NavTab) -> Unit
) {
    val palette = LocalNexgtPalette.current

    NavigationBar(
        containerColor = Color(0xFF0D0D11),
        contentColor = palette.textPrimary,
        tonalElevation = 0.dp
    ) {
        NavTab.entries.forEach { tab ->
            val selected = currentTab == tab
            val icon = when (tab) {
                NavTab.HOME -> Icons.Default.Home
                NavTab.GAMES -> Icons.Default.SportsEsports
                NavTab.FPS_120 -> Icons.Default.Speed
                NavTab.TWEAKS -> Icons.Default.Tune
                NavTab.AX_MANAGE -> Icons.Default.Extension
                NavTab.TOOLS -> Icons.Default.Build
            }
            NavigationBarItem(
                selected = selected,
                onClick = { onSelectTab(tab) },
                icon = {
                    Icon(
                        imageVector = icon,
                        contentDescription = tab.label,
                        modifier = Modifier.size(20.dp)
                    )
                },
                label = {
                    Text(
                        text = tab.label,
                        fontSize = 10.sp,
                        fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                        maxLines = 1,
                        overflow = TextOverflow.Clip
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = palette.accent,
                    selectedTextColor = palette.accent,
                    indicatorColor = palette.accentSoft,
                    unselectedIconColor = palette.textSecondary,
                    unselectedTextColor = palette.textSecondary
                )
            )
        }
    }
}

@Composable
fun FeatureHelpDialog(
    help: HardwareHelpContent,
    onDismiss: () -> Unit
) {
    val palette = LocalNexgtPalette.current
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = palette.cardSurfaceSolid,
        title = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                RiskTagBadge(risk = help.risk)
                Text(
                    text = help.title,
                    color = palette.textPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "O que faz no Hardware:",
                    color = palette.accent,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = help.hardwareImpact,
                    color = palette.textPrimary,
                    fontSize = 12.sp
                )
                Text(
                    text = "Benefício direto:",
                    color = palette.textSecondary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = help.whyUse,
                    color = palette.textSecondary,
                    fontSize = 12.sp
                )
                if (!help.command.isNullOrBlank()) {
                    Text(
                        text = "Comando Shell Shizuku (UID 2000):",
                        color = palette.accent,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color(0xFF09090C))
                            .border(1.dp, palette.subtleBorder, RoundedCornerShape(10.dp))
                            .padding(10.dp)
                    ) {
                        Text(
                            text = help.command,
                            color = Color(0xFFE4E4E7),
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Entendi", color = palette.accent, fontWeight = FontWeight.Bold)
            }
        }
    )
}

@Composable
fun CommandInfoDialog(
    title: String,
    command: String,
    description: String,
    onDismiss: () -> Unit
) {
    FeatureHelpDialog(
        help = HardwareHelpContent(
            title = title,
            risk = FeatureRiskLevel.SAFE,
            hardwareImpact = description,
            whyUse = "Executado diretamente via Shizuku UID 2000 para resposta imediata.",
            command = command
        ),
        onDismiss = onDismiss
    )
}

@Composable
fun ActiveFunctionsDialog(
    entries: List<ActiveFunctionEntry>,
    onDisableOne: (ActiveFunctionEntry) -> Unit,
    onDisableAll: () -> Unit,
    onDismiss: () -> Unit
) {
    val palette = LocalNexgtPalette.current
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = palette.cardSurfaceSolid,
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Funções Ativas (${entries.size})",
                    color = palette.textPrimary,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 16.sp
                )
                if (entries.isNotEmpty()) {
                    TextButton(onClick = {
                        onDisableAll()
                        onDismiss()
                    }) {
                        Text("Desativar Tudo", color = palette.danger, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        },
        text = {
            if (entries.isEmpty()) {
                Text(
                    text = "Nenhuma otimização está ligada no momento.",
                    color = palette.textSecondary,
                    fontSize = 12.sp
                )
            } else {
                LazyColumn(
                    modifier = Modifier.heightIn(max = 320.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(entries, key = { "${it.sourceType}_${it.id}" }) { entry ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(Color(0xFF18181F))
                                .border(1.dp, palette.subtleBorder, RoundedCornerShape(10.dp))
                                .padding(horizontal = 10.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(entry.title, color = palette.textPrimary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                Text(entry.category, color = palette.textSecondary, fontSize = 10.sp)
                            }
                            OutlinedButton(
                                onClick = { onDisableOne(entry) },
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(Icons.Default.Close, contentDescription = "Desligar", tint = palette.danger, modifier = Modifier.size(14.dp))
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Fechar", color = palette.accent, fontWeight = FontWeight.Bold)
            }
        }
    )
}

