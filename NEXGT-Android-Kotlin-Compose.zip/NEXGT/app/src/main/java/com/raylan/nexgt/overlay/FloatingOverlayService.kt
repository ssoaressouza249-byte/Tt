package com.raylan.nexgt.overlay

import android.app.ActivityManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.os.BatteryManager
import android.os.Build
import android.os.IBinder
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.util.TypedValue
import android.view.Choreographer
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import androidx.core.app.NotificationCompat
import com.raylan.nexgt.data.GraphicsPresetLevel
import com.raylan.nexgt.data.NexgtCatalog
import com.raylan.nexgt.data.OverlayPhoneBrand
import com.raylan.nexgt.data.SensiBrand
import com.raylan.nexgt.data.SensiPullStyle
import com.raylan.nexgt.shizuku.ShizukuManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class FloatingOverlayService : Service() {

    companion object {
        const val CHANNEL_ID = "nexgt_overlay_channel"
        const val NOTIFICATION_ID = 2026
        const val EXTRA_SHOW_BUBBLE = "show_bubble"
        const val EXTRA_SHOW_FPS = "show_fps"
        const val EXTRA_ACCENT_HEX = "accent_hex"
        const val EXTRA_TARGET_PKG = "target_pkg"
        const val EXTRA_REFRESH_HZ = "refresh_hz"
        const val EXTRA_CURRENT_DPI = "current_dpi"

        // Paleta HUD Tecnológica P&B (Baixo Consumo de RAM/GPU)
        private const val COLOR_BG_PANEL = "#F508080A" // #08080A com 96% de opacidade
        private const val COLOR_SURFACE_CARD = "#141417"
        private const val COLOR_BORDER_OUTER = "#3F3F46"
        private const val COLOR_BORDER_SUBTLE = "#27272A"
        private const val COLOR_TEXT_PRIMARY = "#FFFFFF"
        private const val COLOR_TEXT_SECONDARY = "#A1A1AA"
        private const val COLOR_ACTION_BG = "#FFFFFF"
        private const val COLOR_ACTION_TEXT = "#08080A"
    }

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var windowManager: WindowManager? = null

    private var bubbleView: View? = null
    private var panelView: View? = null
    private var panelLayoutParams: WindowManager.LayoutParams? = null
    private var fpsView: TextView? = null
    private var telemetryTextView: TextView? = null

    private var accentColor: Int = Color.parseColor("#E11D48")
    private var targetPkg: String = "com.dts.freefireth"
    private var refreshRateHz: Int = 60
    private var liveMeasuredFps: Int = 60
    private var currentSmallestWidthDpi: Int = 411
    private var isPanelOpen = false

    private enum class OverlayTab { RESOLUTION, SENSI, GRAPHICS }
    private var currentTab = OverlayTab.RESOLUTION

    // Aba 1: Seletor de Marca + Modelo Real + Limite Seguro (>= 480px)
    private var nativeWidthPx = 720
    private var nativeHeightPx = 1600
    private var nativeDensityDpi = 320
    private var selectedPhoneBrand = OverlayPhoneBrand.AUTO
    private var selectedModelId: String = "AUTO_DETECTED"
    private var modelSearchQuery: String = ""
    private var brandPickerExpanded = false
    private var modelPickerExpanded = false
    private var resolutionConfirmCountdown = 0
    private var resolutionRevertJob: Job? = null
    private var telemetryLoopJob: Job? = null
    private var resolutionStatusMsg = "Leitura automática via wm size"

    // Aba 2: Gerador de Sensi (0-100 e 0-200)
    private var selectedBrand = SensiBrand.SAMSUNG
    private var selectedStyle = SensiPullStyle.CAPA_RAPIDO
    private var sensiScale200Mode = true
    private var sensiFeedbackMsg: String? = null

    // Aba 3: Gráfico (Normal, Leve, Ultra Leve / Minecraft)
    private var activeGraphicsLevel = GraphicsPresetLevel.NORMAL
    private var gfxStatusMsg = "Renderização padrão (1.0x)"

    private var frameCount = 0
    private var lastFrameTimeNs = 0L
    private var fpsCallbackRunning = false

    private val frameCallback = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            if (!fpsCallbackRunning) return
            if (lastFrameTimeNs == 0L) {
                lastFrameTimeNs = frameTimeNanos
            }
            frameCount++
            val elapsedNs = frameTimeNanos - lastFrameTimeNs
            if (elapsedNs >= 500_000_000L) {
                val fps = ((frameCount * 1_000_000_000.0) / elapsedNs).toInt().coerceIn(1, 240)
                liveMeasuredFps = fps
                fpsView?.text = "$fps FPS"
                frameCount = 0
                lastFrameTimeNs = frameTimeNanos
            }
            Choreographer.getInstance().postFrameCallback(this)
        }
    }

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        readFallbackDisplayMetrics()
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, buildNotification())
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        runCatching {
            val showBubble = intent?.getBooleanExtra(EXTRA_SHOW_BUBBLE, false) ?: false
            val showFps = intent?.getBooleanExtra(EXTRA_SHOW_FPS, false) ?: false
            val hex = intent?.getStringExtra(EXTRA_ACCENT_HEX) ?: "#E11D48"
            targetPkg = intent?.getStringExtra(EXTRA_TARGET_PKG) ?: targetPkg
            refreshRateHz = intent?.getIntExtra(EXTRA_REFRESH_HZ, refreshRateHz) ?: refreshRateHz
            liveMeasuredFps = refreshRateHz
            currentSmallestWidthDpi = intent?.getIntExtra(EXTRA_CURRENT_DPI, currentSmallestWidthDpi) ?: currentSmallestWidthDpi
            accentColor = runCatching { Color.parseColor(hex) }.getOrDefault(Color.parseColor("#E11D48"))

            if (showBubble) {
                syncNativeWmSizeAndDensity()
                showMinimalBubble()
            } else {
                removeBubbleAndPanel()
            }
            if (showFps) showFpsMeter() else removeFpsMeter()
        }
        return START_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        resolutionRevertJob?.cancel()
        telemetryLoopJob?.cancel()
        removeBubbleAndPanel()
        removeFpsMeter()
        serviceScope.cancel()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun dp(value: Float): Int =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, value, resources.displayMetrics).toInt()

    private fun readFallbackDisplayMetrics() {
        val dm = resources.displayMetrics
        nativeWidthPx = dm.widthPixels.coerceAtLeast(480)
        nativeHeightPx = dm.heightPixels.coerceAtLeast(800)
        nativeDensityDpi = dm.densityDpi.coerceAtLeast(160)
        refreshRateHz = runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                display?.refreshRate?.toInt() ?: refreshRateHz
            } else {
                refreshRateHz
            }
        }.getOrDefault(refreshRateHz)
        liveMeasuredFps = refreshRateHz
    }

    private fun readLiveTelemetryLine(): String {
        val am = getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
        val memInfo = ActivityManager.MemoryInfo()
        val freeRamGb = if (am != null) {
            am.getMemoryInfo(memInfo)
            val gb = memInfo.availMem.toDouble() / (1024.0 * 1024.0 * 1024.0)
            String.format("%.1f", gb)
        } else {
            "1.4"
        }
        val tempC = runCatching {
            val intent = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val tenths = intent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 360) ?: 360
            (tenths / 10f).toInt()
        }.getOrDefault(36)
        val fpsShown = if (fpsCallbackRunning) liveMeasuredFps else refreshRateHz
        return "FPS: $fpsShown  |  RAM: ${freeRamGb}GB LIVRE  |  TEMP: ${tempC}°C"
    }

    private fun syncNativeWmSizeAndDensity() {
        serviceScope.launch {
            val (sizeOk, sizeOut) = ShizukuManager.runCommand("wm size")
            if (sizeOk) {
                val (w, h) = NexgtCatalog.parseWmSizeOutput(sizeOut, nativeWidthPx, nativeHeightPx)
                nativeWidthPx = w
                nativeHeightPx = h
            }
            val (densOk, densOut) = ShizukuManager.runCommand("wm density")
            if (densOk) {
                val (phys, ovr) = NexgtCatalog.parseWmDensityOutput(densOut, nativeDensityDpi)
                nativeDensityDpi = phys
                val eff = ovr ?: phys
                currentSmallestWidthDpi = ((nativeWidthPx * 160f) / eff.coerceAtLeast(120)).toInt()
            }
            if (isPanelOpen) refreshPanelContent()
        }
    }

    private fun overlayLayoutType(): Int =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

    // Ícone Flutuante Minimizado: 42dp círculo preto (#09090B), borda 1dp branca (#FFFFFF), 50% opacidade ocioso
    private fun showMinimalBubble() {
        removeBubbleAndPanel()
        val wm = windowManager ?: return
        val sizePx = dp(42f)
        val params = WindowManager.LayoutParams(
            sizePx,
            sizePx,
            overlayLayoutType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(16f)
            y = dp(180f)
        }

        val view = MinimalTechBubbleView(this).apply {
            alpha = 0.50f
        }
        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        var moved = false

        view.setOnTouchListener { v, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    v.alpha = 1.0f
                    startX = params.x
                    startY = params.y
                    touchX = event.rawX
                    touchY = event.rawY
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - touchX).toInt()
                    val dy = (event.rawY - touchY).toInt()
                    if (kotlin.math.abs(dx) > 6 || kotlin.math.abs(dy) > 6) moved = true
                    params.x = startX + dx
                    params.y = startY + dy
                    runCatching { wm.updateViewLayout(view, params) }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    v.alpha = if (isPanelOpen) 1.0f else 0.50f
                    if (!moved) toggleInGamePanel()
                    true
                }
                else -> false
            }
        }

        runCatching {
            wm.addView(view, params)
            bubbleView = view
        }
    }

    private fun toggleInGamePanel() {
        val wm = windowManager ?: return
        if (isPanelOpen && panelView != null) {
            telemetryLoopJob?.cancel()
            runCatching { wm.removeView(panelView) }
            panelView = null
            panelLayoutParams = null
            telemetryTextView = null
            isPanelOpen = false
            brandPickerExpanded = false
            modelPickerExpanded = false
            bubbleView?.alpha = 0.50f
            return
        }

        val dm = resources.displayMetrics
        val panelHeightPx = minOf(dp(472f), (dm.heightPixels * 0.88f).toInt())

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12f), dp(10f), dp(12f), dp(10f))
            background = TacticalHudFrameDrawable(this@FloatingOverlayService)
        }

        val params = WindowManager.LayoutParams(
            dp(300f),
            panelHeightPx,
            overlayLayoutType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.CENTER
        }

        runCatching {
            wm.addView(root, params)
            panelView = root
            panelLayoutParams = params
            isPanelOpen = true
            bubbleView?.alpha = 1.0f
            refreshPanelContent()
            startTelemetryLoop()
        }
    }

    private fun updatePanelFocusability(allowKeyboard: Boolean) {
        val wm = windowManager ?: return
        val root = panelView ?: return
        val lp = panelLayoutParams ?: return
        val nextFlags = if (allowKeyboard) {
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
        } else {
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        }
        if (lp.flags != nextFlags) {
            lp.flags = nextFlags
            runCatching { wm.updateViewLayout(root, lp) }
        }
    }

    private fun startTelemetryLoop() {
        telemetryLoopJob?.cancel()
        telemetryLoopJob = serviceScope.launch {
            while (isPanelOpen) {
                telemetryTextView?.text = readLiveTelemetryLine()
                delay(1500L)
            }
        }
    }

    private data class ActiveDeviceSpec(
        val label: String,
        val nativeWidth: Int,
        val nativeHeight: Int,
        val nativeDensity: Int,
        val minSafeWidth: Int,
        val minSafeHeight: Int,
        val refreshHz: Int
    )

    private fun resolveActiveDeviceSpec(): ActiveDeviceSpec {
        if (selectedPhoneBrand == OverlayPhoneBrand.AUTO && selectedModelId == "AUTO_DETECTED") {
            val (minW, minH) = NexgtCatalog.computeSafeMinBounds(nativeWidthPx, nativeHeightPx)
            return ActiveDeviceSpec(
                label = Build.MODEL,
                nativeWidth = nativeWidthPx,
                nativeHeight = nativeHeightPx,
                nativeDensity = nativeDensityDpi,
                minSafeWidth = minW,
                minSafeHeight = minH,
                refreshHz = refreshRateHz
            )
        }
        val filtered = NexgtCatalog.filterOverlayModels(selectedPhoneBrand, modelSearchQuery)
        val found = NexgtCatalog.overlayPhoneModels.find { it.id == selectedModelId } ?: filtered.firstOrNull()
        return if (found != null) {
            ActiveDeviceSpec(
                label = found.name,
                nativeWidth = found.nativeWidth,
                nativeHeight = found.nativeHeight,
                nativeDensity = found.nativeDensity,
                minSafeWidth = found.minSafeWidth,
                minSafeHeight = found.minSafeHeight,
                refreshHz = found.refreshHz
            )
        } else {
            val (minW, minH) = NexgtCatalog.computeSafeMinBounds(nativeWidthPx, nativeHeightPx)
            ActiveDeviceSpec(
                label = Build.MODEL,
                nativeWidth = nativeWidthPx,
                nativeHeight = nativeHeightPx,
                nativeDensity = nativeDensityDpi,
                minSafeWidth = minW,
                minSafeHeight = minH,
                refreshHz = refreshRateHz
            )
        }
    }

    private fun refreshPanelContent() {
        val root = panelView as? LinearLayout ?: return
        root.removeAllViews()
        updatePanelFocusability(modelPickerExpanded)
        val spec = resolveActiveDeviceSpec()

        // Cabeçalho fino com FF BOOST • HUD + Aparelho + Botão "X"
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 0, 0, dp(5f))
        }
        val titleCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        titleCol.addView(TextView(this).apply {
            text = "FF BOOST • HUD"
            setTextColor(Color.parseColor(COLOR_TEXT_PRIMARY))
            textSize = 11.5f
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
            letterSpacing = 0.08f
        })
        titleCol.addView(TextView(this).apply {
            text = "${spec.label} · ${spec.refreshHz}Hz"
            setTextColor(Color.parseColor(COLOR_TEXT_SECONDARY))
            textSize = 9.5f
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        })
        header.addView(titleCol)

        val closeBtn = TextView(this).apply {
            text = "✕"
            setTextColor(Color.parseColor(COLOR_TEXT_PRIMARY))
            textSize = 13f
            gravity = Gravity.CENTER
            setPadding(dp(9f), dp(4f), dp(9f), dp(4f))
            background = GradientDrawable().apply {
                setColor(Color.parseColor(COLOR_SURFACE_CARD))
                cornerRadius = dp(6f).toFloat()
                setStroke(dp(1f), Color.parseColor(COLOR_BORDER_OUTER))
            }
            setOnClickListener { toggleInGamePanel() }
        }
        header.addView(closeBtn)
        root.addView(header)

        // Faixa Fina de Telemetria em Tempo Real
        val telemetryTv = TextView(this).apply {
            text = readLiveTelemetryLine()
            setTextColor(Color.WHITE)
            textSize = 8.4f
            maxLines = 1
            typeface = Typeface.MONOSPACE
            gravity = Gravity.CENTER
            setPadding(dp(5f), dp(4f), dp(5f), dp(4f))
            background = GradientDrawable().apply {
                setColor(Color.parseColor(COLOR_SURFACE_CARD))
                cornerRadius = dp(6f).toFloat()
                setStroke(dp(1f), Color.parseColor(COLOR_BORDER_SUBTLE))
            }
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = dp(6f) }
        }
        telemetryTextView = telemetryTv
        root.addView(telemetryTv)

        // 3 abas superiores em linha limpa: Resolução, Sensi, Gráfico
        val tabsRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(2f), dp(2f), dp(2f), dp(2f))
            background = GradientDrawable().apply {
                setColor(Color.parseColor(COLOR_SURFACE_CARD))
                cornerRadius = dp(7f).toFloat()
                setStroke(dp(1f), Color.parseColor(COLOR_BORDER_SUBTLE))
            }
        }
        listOf(
            OverlayTab.RESOLUTION to "Resolução",
            OverlayTab.SENSI to "Sensi",
            OverlayTab.GRAPHICS to "Gráfico"
        ).forEach { (tab, label) ->
            val selected = currentTab == tab
            val tabView = TextView(this).apply {
                text = label
                gravity = Gravity.CENTER
                textSize = 10.5f
                typeface = if (selected) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
                setTextColor(
                    if (selected) Color.parseColor(COLOR_ACTION_TEXT)
                    else Color.parseColor(COLOR_TEXT_SECONDARY)
                )
                setPadding(dp(4f), dp(6f), dp(4f), dp(6f))
                background = GradientDrawable().apply {
                    setColor(if (selected) Color.parseColor(COLOR_ACTION_BG) else Color.TRANSPARENT)
                    cornerRadius = dp(5f).toFloat()
                }
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                setOnClickListener {
                    currentTab = tab
                    brandPickerExpanded = false
                    modelPickerExpanded = false
                    refreshPanelContent()
                }
            }
            tabsRow.addView(tabView)
        }
        root.addView(tabsRow, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = dp(8f) })

        // Corpo rolável com espaçamento confortável
        val scroll = ScrollView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                0,
                1f
            )
            isVerticalScrollBarEnabled = false
        }
        val body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        scroll.addView(body)
        root.addView(scroll)

        when (currentTab) {
            OverlayTab.RESOLUTION -> buildResolutionTab(body, spec)
            OverlayTab.SENSI -> buildSensiTab(body, spec)
            OverlayTab.GRAPHICS -> buildGraphicsTab(body)
        }

        // Rodapé fixo do painel
        val footer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(8f), 0, 0)
        }
        when (currentTab) {
            OverlayTab.RESOLUTION -> {
                footer.addView(makePrimaryButton("RESTAURAR RESOLUÇÃO ORIGINAL") {
                    restoreOverlayOriginalResolution(autoReverted = false)
                })
            }
            OverlayTab.SENSI -> {
                val report = NexgtCatalog.generateFreeFireSensitivity(
                    brand = selectedBrand,
                    style = selectedStyle,
                    refreshRateHz = spec.refreshHz,
                    currentDpi = currentSmallestWidthDpi
                )
                val btnRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                val copyBtn = makePrimaryButton("COPIAR SENSI") {
                    val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    cm.setPrimaryClip(ClipData.newPlainText("FF Boost Sensi", NexgtCatalog.formatSensitivityCopyText(report)))
                    sensiFeedbackMsg = "Sensi copiada!"
                    refreshPanelContent()
                }.apply {
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                        marginEnd = dp(4f)
                    }
                }
                val dpiBtn = Button(this).apply {
                    text = "APLICAR DPI"
                    isAllCaps = false
                    textSize = 10f
                    typeface = Typeface.DEFAULT_BOLD
                    setTextColor(Color.WHITE)
                    setPadding(dp(8f), dp(6f), dp(8f), dp(6f))
                    minHeight = dp(34f)
                    minimumHeight = dp(34f)
                    background = GradientDrawable().apply {
                        setColor(Color.parseColor(COLOR_SURFACE_CARD))
                        cornerRadius = dp(7f).toFloat()
                        setStroke(dp(1f), Color.WHITE)
                    }
                    setOnClickListener {
                        serviceScope.launch {
                            val targetDensity = NexgtCatalog.computeDensityFromSmallestWidth(spec.nativeWidth, report.recommendedDpi)
                            ShizukuManager.runCommand("wm density $targetDensity")
                            currentSmallestWidthDpi = report.recommendedDpi
                            sensiFeedbackMsg = "DPI ${report.recommendedDpi} aplicada (wm density $targetDensity)!"
                            refreshPanelContent()
                        }
                    }
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                }
                btnRow.addView(copyBtn)
                btnRow.addView(dpiBtn)
                footer.addView(btnRow)
            }
            OverlayTab.GRAPHICS -> {
                footer.addView(makePrimaryButton("RESTAURAR GRÁFICO NORMAL") {
                    applyGraphicsPreset(GraphicsPresetLevel.NORMAL, "1.0")
                })
            }
        }
        root.addView(footer)
    }

    // ABA 1: SELETOR REAL DE CELULARES + LIMITE SEGURO (>= 480px)
    private fun buildResolutionTab(container: LinearLayout, spec: ActiveDeviceSpec) {
        // 2 Seletores P&B: [Marca do Celular v] e [Modelo Exato v]
        val selectorsRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = dp(6f) }
        }

        val brandBtn = TextView(this).apply {
            text = "${selectedPhoneBrand.label} ▾"
            textSize = 9.8f
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            setTextColor(Color.WHITE)
            setPadding(dp(8f), dp(7f), dp(8f), dp(7f))
            background = GradientDrawable().apply {
                setColor(Color.parseColor(COLOR_SURFACE_CARD))
                cornerRadius = dp(6f).toFloat()
                setStroke(dp(1f), Color.parseColor(if (brandPickerExpanded) COLOR_TEXT_PRIMARY else COLOR_BORDER_OUTER))
            }
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                marginEnd = dp(4f)
            }
            setOnClickListener {
                brandPickerExpanded = !brandPickerExpanded
                modelPickerExpanded = false
                refreshPanelContent()
            }
        }
        val modelBtn = TextView(this).apply {
            text = "${spec.label} ▾"
            textSize = 9.8f
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            setTextColor(Color.WHITE)
            setPadding(dp(8f), dp(7f), dp(8f), dp(7f))
            background = GradientDrawable().apply {
                setColor(Color.parseColor(COLOR_SURFACE_CARD))
                cornerRadius = dp(6f).toFloat()
                setStroke(dp(1f), Color.parseColor(if (modelPickerExpanded) COLOR_TEXT_PRIMARY else COLOR_BORDER_OUTER))
            }
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            setOnClickListener {
                modelPickerExpanded = !modelPickerExpanded
                brandPickerExpanded = false
                refreshPanelContent()
            }
        }
        selectorsRow.addView(brandBtn)
        selectorsRow.addView(modelBtn)
        container.addView(selectorsRow)

        if (brandPickerExpanded) {
            val listCard = makeSurfaceCard(highlighted = true)
            OverlayPhoneBrand.entries.forEach { brand ->
                val active = selectedPhoneBrand == brand
                listCard.addView(TextView(this).apply {
                    text = brand.label
                    textSize = 10f
                    setTextColor(if (active) Color.parseColor(COLOR_ACTION_TEXT) else Color.WHITE)
                    typeface = if (active) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
                    setPadding(dp(8f), dp(6f), dp(8f), dp(6f))
                    background = GradientDrawable().apply {
                        setColor(if (active) Color.WHITE else Color.TRANSPARENT)
                        cornerRadius = dp(5f).toFloat()
                    }
                    setOnClickListener {
                        selectedPhoneBrand = brand
                        brandPickerExpanded = false
                        modelSearchQuery = ""
                        selectedModelId = if (brand == OverlayPhoneBrand.AUTO) {
                            "AUTO_DETECTED"
                        } else {
                            NexgtCatalog.overlayPhoneModels.firstOrNull { it.brand == brand }?.id ?: "AUTO_DETECTED"
                        }
                        refreshPanelContent()
                    }
                })
            }
            container.addView(listCard)
        }

        if (modelPickerExpanded) {
            val listCard = makeSurfaceCard(highlighted = true)
            val searchBox = EditText(this).apply {
                hint = "Buscar modelo..."
                setText(modelSearchQuery)
                setTextColor(Color.WHITE)
                setHintTextColor(Color.parseColor(COLOR_TEXT_SECONDARY))
                textSize = 10f
                setSingleLine(true)
                setPadding(dp(8f), dp(6f), dp(8f), dp(6f))
                background = GradientDrawable().apply {
                    setColor(Color.parseColor("#08080A"))
                    cornerRadius = dp(5f).toFloat()
                    setStroke(dp(1f), Color.parseColor(COLOR_BORDER_SUBTLE))
                }
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply { bottomMargin = dp(6f) }
            }
            listCard.addView(searchBox)

            val modelsContainer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            fun populateModels(query: String) {
                modelsContainer.removeAllViews()
                modelsContainer.addView(TextView(this@FloatingOverlayService).apply {
                    val active = selectedModelId == "AUTO_DETECTED"
                    text = "Auto (${Build.MODEL} · ${nativeWidthPx}x${nativeHeightPx})"
                    textSize = 9.8f
                    setTextColor(if (active) Color.parseColor(COLOR_ACTION_TEXT) else Color.WHITE)
                    typeface = if (active) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
                    setPadding(dp(8f), dp(6f), dp(8f), dp(6f))
                    background = GradientDrawable().apply {
                        setColor(if (active) Color.WHITE else Color.TRANSPARENT)
                        cornerRadius = dp(5f).toFloat()
                    }
                    setOnClickListener {
                        selectedPhoneBrand = OverlayPhoneBrand.AUTO
                        selectedModelId = "AUTO_DETECTED"
                        modelPickerExpanded = false
                        refreshPanelContent()
                    }
                })
                NexgtCatalog.filterOverlayModels(selectedPhoneBrand, query).forEach { m ->
                    val active = selectedModelId == m.id
                    modelsContainer.addView(TextView(this@FloatingOverlayService).apply {
                        text = "${m.name}  (${m.nativeWidth}x${m.nativeHeight})"
                        textSize = 9.8f
                        setTextColor(if (active) Color.parseColor(COLOR_ACTION_TEXT) else Color.WHITE)
                        typeface = if (active) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
                        setPadding(dp(8f), dp(6f), dp(8f), dp(6f))
                        background = GradientDrawable().apply {
                            setColor(if (active) Color.WHITE else Color.TRANSPARENT)
                            cornerRadius = dp(5f).toFloat()
                        }
                        setOnClickListener {
                            selectedPhoneBrand = m.brand
                            selectedModelId = m.id
                            modelPickerExpanded = false
                            refreshPanelContent()
                        }
                    })
                }
            }
            populateModels(modelSearchQuery)
            searchBox.addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                    modelSearchQuery = s?.toString() ?: ""
                    populateModels(modelSearchQuery)
                }
                override fun afterTextChanged(s: Editable?) {}
            })
            listCard.addView(modelsContainer)
            container.addView(listCard)
        }

        // Exibição Nativa + Limite Seguro
        container.addView(TextView(this).apply {
            text = "Nativa: ${spec.nativeWidth}x${spec.nativeHeight} • Limite Seguro: ${spec.minSafeWidth}x${spec.minSafeHeight}"
            setTextColor(Color.WHITE)
            textSize = 9.5f
            typeface = Typeface.MONOSPACE
            setPadding(dp(8f), dp(5f), dp(8f), dp(5f))
            background = GradientDrawable().apply {
                setColor(Color.parseColor(COLOR_SURFACE_CARD))
                cornerRadius = dp(6f).toFloat()
                setStroke(dp(1f), Color.parseColor(COLOR_BORDER_SUBTLE))
            }
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = dp(6f) }
        })

        if (resolutionConfirmCountdown > 0) {
            val warnCard = makeSurfaceCard(highlighted = true).apply {
                addView(TextView(this@FloatingOverlayService).apply {
                    text = "CONFIRMAR RESOLUÇÃO (${resolutionConfirmCountdown}s)"
                    setTextColor(Color.WHITE)
                    textSize = 11f
                    typeface = Typeface.MONOSPACE
                })
                addView(TextView(this@FloatingOverlayService).apply {
                    text = resolutionStatusMsg
                    setTextColor(Color.parseColor(COLOR_TEXT_SECONDARY))
                    textSize = 9.5f
                    setPadding(0, dp(2f), 0, dp(6f))
                })
                addView(makePrimaryButton("MANTER RESOLUÇÃO") {
                    resolutionRevertJob?.cancel()
                    resolutionConfirmCountdown = 0
                    resolutionStatusMsg = "Nova resolução mantida com segurança."
                    refreshPanelContent()
                })
            }
            container.addView(warnCard)
        }

        val options = NexgtCatalog.buildOverlayResolutionOptions(
            spec.nativeWidth,
            spec.nativeHeight,
            spec.nativeDensity,
            spec.minSafeWidth,
            spec.minSafeHeight
        )
        options.forEach { opt ->
            val card = makeSurfaceCard().apply {
                val topRow = LinearLayout(this@FloatingOverlayService).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                }
                val txtCol = LinearLayout(this@FloatingOverlayService).apply {
                    orientation = LinearLayout.VERTICAL
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                        marginEnd = dp(6f)
                    }
                }
                txtCol.addView(TextView(this@FloatingOverlayService).apply {
                    text = "${opt.label} • ${opt.width}x${opt.height}"
                    setTextColor(Color.WHITE)
                    textSize = 10.5f
                    typeface = Typeface.DEFAULT_BOLD
                })
                txtCol.addView(TextView(this@FloatingOverlayService).apply {
                    text = "DPI Calc: ${opt.scaledDensity} · Redução -${opt.reductionPercent}%"
                    setTextColor(Color.parseColor(COLOR_TEXT_SECONDARY))
                    textSize = 9.2f
                    typeface = Typeface.MONOSPACE
                })
                topRow.addView(txtCol)

                val applyBtn = TextView(this@FloatingOverlayService).apply {
                    text = "Aplicar"
                    textSize = 9.5f
                    typeface = Typeface.DEFAULT_BOLD
                    setTextColor(Color.parseColor(COLOR_ACTION_TEXT))
                    setPadding(dp(9f), dp(6f), dp(9f), dp(6f))
                    background = GradientDrawable().apply {
                        setColor(Color.parseColor(COLOR_ACTION_BG))
                        cornerRadius = dp(6f).toFloat()
                    }
                    setOnClickListener {
                        applyOverlayResolutionWith15sSafety(opt.width, opt.height, opt.scaledDensity)
                    }
                }
                topRow.addView(applyBtn)
                addView(topRow)

                // Descrição completa em 2 linhas sem cortes (...)
                addView(TextView(this@FloatingOverlayService).apply {
                    text = opt.subtitle
                    setTextColor(Color.parseColor(COLOR_TEXT_SECONDARY))
                    textSize = 9.2f
                    setPadding(0, dp(4f), 0, 0)
                })
            }
            container.addView(card)
        }
    }

    private fun applyOverlayResolutionWith15sSafety(width: Int, height: Int, scaledDensity: Int) {
        resolutionRevertJob?.cancel()
        serviceScope.launch {
            val cmd = NexgtCatalog.buildOverlayApplyResolutionCommand(width, height, scaledDensity)
            val (ok, _) = ShizukuManager.runCommand(cmd)
            resolutionStatusMsg = if (ok) {
                "Aplicado ${width}x${height} (wm density $scaledDensity)"
            } else {
                "Comando enviado: $cmd"
            }
            resolutionConfirmCountdown = 15
            refreshPanelContent()
            resolutionRevertJob = serviceScope.launch {
                for (sec in 15 downTo 1) {
                    resolutionConfirmCountdown = sec
                    refreshPanelContent()
                    delay(1000L)
                }
                restoreOverlayOriginalResolution(autoReverted = true)
            }
        }
    }

    private fun restoreOverlayOriginalResolution(autoReverted: Boolean) {
        resolutionRevertJob?.cancel()
        resolutionConfirmCountdown = 0
        serviceScope.launch {
            ShizukuManager.runCommand(NexgtCatalog.buildOverlayRestoreResolutionCommand())
            resolutionStatusMsg = if (autoReverted) {
                "Trava 15s: resolução original restaurada automaticamente."
            } else {
                "Resolução original restaurada (wm size reset + wm density reset)."
            }
            syncNativeWmSizeAndDensity()
            refreshPanelContent()
        }
    }

    // ABA 2: GERADOR DE SENSIBILIDADE (6 BARRAS LADO A LADO + [0-100]/[0-200])
    private fun buildSensiTab(container: LinearLayout, spec: ActiveDeviceSpec) {
        val brandScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = dp(5f) }
        }
        val brandRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        SensiBrand.entries.forEach { b ->
            val active = selectedBrand == b
            brandRow.addView(TextView(this).apply {
                text = b.label
                textSize = 9.5f
                setTextColor(if (active) Color.parseColor(COLOR_ACTION_TEXT) else Color.parseColor(COLOR_TEXT_SECONDARY))
                typeface = if (active) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
                setPadding(dp(8f), dp(5f), dp(8f), dp(5f))
                background = GradientDrawable().apply {
                    setColor(if (active) Color.WHITE else Color.parseColor(COLOR_SURFACE_CARD))
                    cornerRadius = dp(6f).toFloat()
                    setStroke(dp(1f), Color.parseColor(if (active) COLOR_TEXT_PRIMARY else COLOR_BORDER_SUBTLE))
                }
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply { marginEnd = dp(4f) }
                setOnClickListener {
                    selectedBrand = b
                    sensiFeedbackMsg = null
                    refreshPanelContent()
                }
            })
        }
        brandScroll.addView(brandRow)
        container.addView(brandScroll)

        val styleRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = dp(6f) }
        }
        SensiPullStyle.entries.forEach { st ->
            val active = selectedStyle == st
            val shortLabel = when (st) {
                SensiPullStyle.CAPA_RAPIDO -> "Capa Rápido"
                SensiPullStyle.EQUILIBRADA -> "Equilibrada"
                SensiPullStyle.MIRA_PRECISA -> "Mira 4x"
            }
            styleRow.addView(TextView(this).apply {
                text = shortLabel
                textSize = 9.5f
                gravity = Gravity.CENTER
                setTextColor(if (active) Color.WHITE else Color.parseColor(COLOR_TEXT_SECONDARY))
                typeface = if (active) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
                setPadding(dp(4f), dp(5f), dp(4f), dp(5f))
                background = GradientDrawable().apply {
                    setColor(Color.parseColor(COLOR_SURFACE_CARD))
                    cornerRadius = dp(6f).toFloat()
                    setStroke(dp(1f), Color.parseColor(if (active) COLOR_TEXT_PRIMARY else COLOR_BORDER_SUBTLE))
                }
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                    marginEnd = dp(3f)
                }
                setOnClickListener {
                    selectedStyle = st
                    sensiFeedbackMsg = null
                    refreshPanelContent()
                }
            })
        }
        container.addView(styleRow)

        // Seletor Rápido de Escala ([ 0 - 100 ] / [ 0 - 200 ])
        val scaleSwitch = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(2f), dp(2f), dp(2f), dp(2f))
            background = GradientDrawable().apply {
                setColor(Color.parseColor(COLOR_SURFACE_CARD))
                cornerRadius = dp(6f).toFloat()
                setStroke(dp(1f), Color.parseColor(COLOR_BORDER_SUBTLE))
            }
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = dp(6f) }
        }
        listOf(false to "[ 0 - 100 ]", true to "[ 0 - 200 ]").forEach { (is200, label) ->
            val selected = sensiScale200Mode == is200
            scaleSwitch.addView(TextView(this).apply {
                text = label
                gravity = Gravity.CENTER
                textSize = 10f
                typeface = Typeface.create(Typeface.MONOSPACE, if (selected) Typeface.BOLD else Typeface.NORMAL)
                setTextColor(if (selected) Color.parseColor(COLOR_ACTION_TEXT) else Color.parseColor(COLOR_TEXT_SECONDARY))
                setPadding(dp(4f), dp(5f), dp(4f), dp(5f))
                background = GradientDrawable().apply {
                    setColor(if (selected) Color.WHITE else Color.TRANSPARENT)
                    cornerRadius = dp(4f).toFloat()
                }
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                setOnClickListener {
                    sensiScale200Mode = is200
                    refreshPanelContent()
                }
            })
        }
        container.addView(scaleSwitch)

        val report = NexgtCatalog.generateFreeFireSensitivity(
            brand = selectedBrand,
            style = selectedStyle,
            refreshRateHz = spec.refreshHz,
            currentDpi = currentSmallestWidthDpi
        )
        val vals = if (sensiScale200Mode) report.scale200 else report.scale100
        val maxCap = if (sensiScale200Mode) 200 else 100
        val pairs = listOf(
            ("Geral" to vals.geral) to ("Ponto Vermelho" to vals.pontoVermelho),
            ("Mira 2x" to vals.mira2x) to ("Mira 4x" to vals.mira4x),
            ("AWM" to vals.awm) to ("Olhadinha" to vals.olhadinha)
        )

        pairs.forEach { (left, right) ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply { bottomMargin = dp(5f) }
            }
            row.addView(makeSensiBarCell(left.first, left.second, maxCap).apply {
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                    marginEnd = dp(4f)
                }
            })
            row.addView(makeSensiBarCell(right.first, right.second, maxCap).apply {
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            })
            container.addView(row)
        }

        container.addView(makeSurfaceCard().apply {
            addView(TextView(this@FloatingOverlayService).apply {
                text = "Botão Atirar: ${report.fireButtonSizePercent}%  ·  DPI Ideal: ${report.recommendedDpi}"
                setTextColor(Color.WHITE)
                textSize = 10f
                typeface = Typeface.MONOSPACE
            })
        })

        sensiFeedbackMsg?.let { msg ->
            container.addView(TextView(this).apply {
                text = msg
                setTextColor(Color.WHITE)
                textSize = 9.5f
                setPadding(0, dp(2f), 0, 0)
            })
        }
    }

    private fun makeSensiBarCell(label: String, value: Int, maxCap: Int): LinearLayout =
        LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(7f), dp(6f), dp(7f), dp(6f))
            background = GradientDrawable().apply {
                setColor(Color.parseColor(COLOR_SURFACE_CARD))
                cornerRadius = dp(6f).toFloat()
                setStroke(dp(1f), Color.parseColor(COLOR_BORDER_SUBTLE))
            }
            val top = LinearLayout(this@FloatingOverlayService).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply { bottomMargin = dp(4f) }
            }
            top.addView(TextView(this@FloatingOverlayService).apply {
                text = label
                textSize = 9.2f
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
                setTextColor(Color.parseColor(COLOR_TEXT_SECONDARY))
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            })
            top.addView(TextView(this@FloatingOverlayService).apply {
                text = "$value"
                textSize = 10.5f
                typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
                setTextColor(Color.WHITE)
            })
            addView(top)

            val bar = ProgressBar(this@FloatingOverlayService, null, android.R.attr.progressBarStyleHorizontal).apply {
                max = maxCap
                progress = value.coerceIn(0, maxCap)
                progressTintList = android.content.res.ColorStateList.valueOf(Color.WHITE)
                progressBackgroundTintList = android.content.res.ColorStateList.valueOf(Color.parseColor("#27272A"))
                layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(4f))
            }
            addView(bar)
        }

    // ABA 3: GRÁFICO (NORMAL, LEVE, ULTRA LEVE / ESTILO MINECRAFT)
    private fun buildGraphicsTab(container: LinearLayout) {
        NexgtCatalog.overlayGraphicsPresets.forEach { preset ->
            val selected = activeGraphicsLevel == preset.level
            val card = makeSurfaceCard(highlighted = selected).apply {
                val top = LinearLayout(this@FloatingOverlayService).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                }
                val infoCol = LinearLayout(this@FloatingOverlayService).apply {
                    orientation = LinearLayout.VERTICAL
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                        marginEnd = dp(6f)
                    }
                }
                infoCol.addView(TextView(this@FloatingOverlayService).apply {
                    text = preset.title
                    setTextColor(Color.WHITE)
                    textSize = 10.8f
                    typeface = Typeface.DEFAULT_BOLD
                })
                infoCol.addView(TextView(this@FloatingOverlayService).apply {
                    text = "⚡ ${preset.fpsGainEstimate}"
                    setTextColor(Color.WHITE)
                    textSize = 9.5f
                    typeface = Typeface.MONOSPACE
                })
                top.addView(infoCol)

                val applyBtn = TextView(this@FloatingOverlayService).apply {
                    text = if (selected) "Ativo" else "Aplicar"
                    textSize = 9.5f
                    typeface = Typeface.DEFAULT_BOLD
                    setTextColor(if (selected) Color.parseColor(COLOR_ACTION_TEXT) else Color.WHITE)
                    setPadding(dp(9f), dp(5f), dp(9f), dp(5f))
                    background = GradientDrawable().apply {
                        setColor(if (selected) Color.WHITE else Color.parseColor("#08080A"))
                        cornerRadius = dp(6f).toFloat()
                        if (!selected) setStroke(dp(1f), Color.parseColor(COLOR_BORDER_OUTER))
                    }
                    setOnClickListener {
                        applyGraphicsPreset(preset.level, preset.downscale)
                    }
                }
                top.addView(applyBtn)
                addView(top)

                addView(TextView(this@FloatingOverlayService).apply {
                    text = preset.description
                    setTextColor(Color.parseColor(COLOR_TEXT_SECONDARY))
                    textSize = 9.2f
                    setPadding(0, dp(4f), 0, 0)
                })
            }
            container.addView(card)
        }

        container.addView(TextView(this).apply {
            text = "Status: $gfxStatusMsg"
            setTextColor(Color.parseColor(COLOR_TEXT_SECONDARY))
            textSize = 9.2f
            typeface = Typeface.MONOSPACE
            setPadding(dp(4f), dp(2f), dp(4f), 0)
        })
    }

    private fun applyGraphicsPreset(level: GraphicsPresetLevel, downscale: String) {
        serviceScope.launch {
            val cmd = NexgtCatalog.buildMinecraftGraphicsCommand(downscale)
            ShizukuManager.runCommand(cmd)
            activeGraphicsLevel = level
            gfxStatusMsg = when (level) {
                GraphicsPresetLevel.NORMAL -> "Renderização padrão restaurada (1.0x)"
                GraphicsPresetLevel.LIGHT -> "Gráfico Leve ativo (0.75x + MSAA 0)"
                GraphicsPresetLevel.ULTRA -> "Ultra Leve / Minecraft ativo (0.5x + MSAA 0)"
            }
            refreshPanelContent()
        }
    }

    private fun makeSurfaceCard(highlighted: Boolean = false): LinearLayout =
        LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8f), dp(7f), dp(8f), dp(7f))
            background = GradientDrawable().apply {
                setColor(Color.parseColor(COLOR_SURFACE_CARD))
                cornerRadius = dp(7f).toFloat()
                setStroke(dp(1f), Color.parseColor(if (highlighted) COLOR_TEXT_PRIMARY else COLOR_BORDER_SUBTLE))
            }
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = dp(6f) }
        }

    private fun makePrimaryButton(label: String, onClick: () -> Unit): Button =
        Button(this).apply {
            text = label
            isAllCaps = false
            textSize = 10.2f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.parseColor(COLOR_ACTION_TEXT))
            setPadding(dp(8f), dp(6f), dp(8f), dp(6f))
            minHeight = dp(34f)
            minimumHeight = dp(34f)
            background = GradientDrawable().apply {
                setColor(Color.parseColor(COLOR_ACTION_BG))
                cornerRadius = dp(7f).toFloat()
            }
            setOnClickListener { onClick() }
        }

    private fun showFpsMeter() {
        removeFpsMeter()
        val wm = windowManager ?: return
        val tv = TextView(this).apply {
            text = "${refreshRateHz} FPS"
            setTextColor(Color.WHITE)
            textSize = 12f
            setPadding(22, 10, 22, 10)
            typeface = Typeface.MONOSPACE
            background = GradientDrawable().apply {
                setColor(Color.parseColor(COLOR_BG_PANEL))
                cornerRadius = 14f
                setStroke(2, Color.parseColor(COLOR_BORDER_OUTER))
            }
        }
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayLayoutType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = 24
            y = 84
        }

        runCatching {
            wm.addView(tv, params)
            fpsView = tv
            fpsCallbackRunning = true
            frameCount = 0
            lastFrameTimeNs = 0L
            Choreographer.getInstance().postFrameCallback(frameCallback)
        }
    }

    private fun removeBubbleAndPanel() {
        val wm = windowManager ?: return
        telemetryLoopJob?.cancel()
        bubbleView?.let { runCatching { wm.removeView(it) } }
        panelView?.let { runCatching { wm.removeView(it) } }
        bubbleView = null
        panelView = null
        panelLayoutParams = null
        telemetryTextView = null
        isPanelOpen = false
    }

    private fun removeFpsMeter() {
        fpsCallbackRunning = false
        Choreographer.getInstance().removeFrameCallback(frameCallback)
        val wm = windowManager ?: return
        fpsView?.let { runCatching { wm.removeView(it) } }
        fpsView = null
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "NEXGT / FF Boost Overlay",
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("FF Boost HUD Ativo")
            .setContentText("Painel HUD P&B 300x472 e telemetria ao vivo")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setOngoing(true)
            .build()
}

private class TacticalHudFrameDrawable(context: Context) : Drawable() {
    private val dm = context.resources.displayMetrics
    private fun dpF(v: Float): Float = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, dm)

    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#F508080A")
        style = Paint.Style.FILL
    }
    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#3F3F46")
        style = Paint.Style.STROKE
        strokeWidth = dpF(1f)
    }
    private val cornerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.STROKE
        strokeWidth = dpF(1.8f)
        strokeCap = Paint.Cap.SQUARE
    }

    override fun draw(canvas: Canvas) {
        val w = bounds.width().toFloat()
        val h = bounds.height().toFloat()
        val inset = borderPaint.strokeWidth / 2f
        val rect = RectF(inset, inset, w - inset, h - inset)
        val radius = dpF(8f)
        val arm = dpF(12f)

        canvas.drawRoundRect(rect, radius, radius, bgPaint)
        canvas.drawRoundRect(rect, radius, radius, borderPaint)

        // 4 Marcadores Táticos Brancos (#FFFFFF) nos Cantos
        canvas.drawLine(inset, inset + arm, inset, inset, cornerPaint)
        canvas.drawLine(inset, inset, inset + arm, inset, cornerPaint)

        canvas.drawLine(w - inset - arm, inset, w - inset, inset, cornerPaint)
        canvas.drawLine(w - inset, inset, w - inset, inset + arm, cornerPaint)

        canvas.drawLine(inset, h - inset - arm, inset, h - inset, cornerPaint)
        canvas.drawLine(inset, h - inset, inset + arm, h - inset, cornerPaint)

        canvas.drawLine(w - inset - arm, h - inset, w - inset, h - inset, cornerPaint)
        canvas.drawLine(w - inset, h - inset, w - inset, h - inset - arm, cornerPaint)
    }

    override fun setAlpha(alpha: Int) {
        bgPaint.alpha = alpha
    }

    override fun setColorFilter(colorFilter: ColorFilter?) {
        bgPaint.colorFilter = colorFilter
    }

    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}

private class MinimalTechBubbleView(context: Context) : View(context) {

    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#09090B")
        style = Paint.Style.FILL
    }
    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.STROKE
        strokeWidth = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 1f, context.resources.displayMetrics)
    }
    private val iconPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.STROKE
        strokeWidth = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 1.6f, context.resources.displayMetrics)
        strokeCap = Paint.Cap.ROUND
    }
    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.FILL
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f
        val cy = height / 2f
        val radius = (minOf(width, height) / 2f) - borderPaint.strokeWidth

        canvas.drawCircle(cx, cy, radius, bgPaint)
        canvas.drawCircle(cx, cy, radius, borderPaint)

        val rInner = radius * 0.42f
        canvas.drawCircle(cx, cy, rInner * 0.55f, iconPaint)
        canvas.drawLine(cx - rInner, cy, cx - rInner * 0.55f, cy, iconPaint)
        canvas.drawLine(cx + rInner * 0.55f, cy, cx + rInner, cy, iconPaint)
        canvas.drawLine(cx, cy - rInner, cx, cy - rInner * 0.55f, iconPaint)
        canvas.drawLine(cx, cy + rInner * 0.55f, cx, cy + rInner, iconPaint)
        canvas.drawCircle(cx, cy, radius * 0.08f, dotPaint)
    }
}
