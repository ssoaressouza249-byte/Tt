package com.raylan.nexgt.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.raylan.nexgt.data.FeatureRiskLevel
import com.raylan.nexgt.data.GameAppItem
import com.raylan.nexgt.data.HardwareHelpContent
import com.raylan.nexgt.data.SmartEngineFeature
import com.raylan.nexgt.ui.components.FeatureHelpButton
import com.raylan.nexgt.ui.components.FeatureHelpDialog
import com.raylan.nexgt.ui.components.NexgtCard
import com.raylan.nexgt.ui.components.NexgtSwitch
import com.raylan.nexgt.ui.components.RiskTagBadge
import com.raylan.nexgt.ui.theme.LocalNexgtPalette

@Composable
fun GamesScreen(
    games: List<GameAppItem>,
    installedApps: List<GameAppItem>,
    targetPackage: String,
    smartEngine: List<SmartEngineFeature>,
    renderScale: Int,
    onSelectGame: (String) -> Unit,
    onAddGame: (GameAppItem) -> Unit,
    onToggleSmartFeature: (String) -> Unit,
    onSelectRenderScale: (Int) -> Unit
) {
    val palette = LocalNexgtPalette.current
    var showAddDialog by remember { mutableStateOf(false) }
    var activeHelp by remember { mutableStateOf<HardwareHelpContent?>(null) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Meus Jogos",
                    color = palette.textPrimary,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
                Button(
                    onClick = { showAddDialog = true },
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = palette.accent,
                        contentColor = Color.White
                    )
                ) {
                    Icon(Icons.Default.Add, contentDescription = null)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("+ ADICIONAR", fontSize = 11.sp, fontWeight = FontWeight.ExtraBold)
                }
            }
            Spacer(modifier = Modifier.height(10.dp))

            LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                items(games, key = { it.packageName }) { game ->
                    val selected = game.packageName == targetPackage
                    NexgtCard(
                        modifier = Modifier.width(156.dp),
                        highlighted = selected,
                        onClick = { onSelectGame(game.packageName) }
                    ) {
                        Icon(
                            imageVector = Icons.Default.SportsEsports,
                            contentDescription = null,
                            tint = if (selected) palette.accent else palette.textSecondary
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = game.name,
                            color = palette.textPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            maxLines = 1
                        )
                        Text(
                            text = game.packageName,
                            color = palette.textSecondary,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            maxLines = 1
                        )
                    }
                }
            }
        }

        // Grade 2 colunas simétrica Motor Inteligente
        item {
            Text(
                text = "Motor Inteligente",
                color = palette.textPrimary,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(8.dp))
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                smartEngine.chunked(2).forEach { rowItems ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(IntrinsicSize.Max),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        rowItems.forEach { feature ->
                            NexgtCard(
                                modifier = Modifier
                                    .weight(1f)
                                    .fillMaxHeight(),
                                highlighted = feature.enabled
                            ) {
                                Column(
                                    modifier = Modifier.fillMaxHeight(),
                                    verticalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            RiskTagBadge(
                                                risk = if (feature.id == "perf_mode" || feature.id == "ia_void") {
                                                    FeatureRiskLevel.ADVANCED
                                                } else {
                                                    FeatureRiskLevel.SAFE
                                                }
                                            )
                                            FeatureHelpButton(
                                                onClick = {
                                                    activeHelp = HardwareHelpContent(
                                                        title = feature.title,
                                                        risk = if (feature.id == "perf_mode" || feature.id == "ia_void") FeatureRiskLevel.ADVANCED else FeatureRiskLevel.SAFE,
                                                        hardwareImpact = "Monitora a atividade do pacote $targetPackage no gerenciador do Android e ajusta prioridade de CPU, GPU e frame pacing automaticamente.",
                                                        whyUse = feature.description,
                                                        command = "cmd game mode performance $targetPackage"
                                                    )
                                                }
                                            )
                                        }
                                        Text(
                                            text = feature.title,
                                            color = palette.textPrimary,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 12.sp
                                        )
                                        Text(
                                            text = feature.description,
                                            color = palette.textSecondary,
                                            fontSize = 11.sp
                                        )
                                    }
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.End
                                    ) {
                                        NexgtSwitch(
                                            checked = feature.enabled,
                                            onCheckedChange = { onToggleSmartFeature(feature.id) }
                                        )
                                    }
                                }
                            }
                        }
                        if (rowItems.size == 1) {
                            Spacer(modifier = Modifier.weight(1f))
                        }
                    }
                }
            }
        }

        // Escala de Renderização
        item {
            NexgtCard {
                Text(
                    text = "Escala de Renderização (GameService Downscale)",
                    color = palette.textPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
                Text(
                    text = "Reduza a carga da GPU para manter 100–120 FPS estáveis em $targetPackage.",
                    color = palette.textSecondary,
                    fontSize = 12.sp
                )
                Spacer(modifier = Modifier.height(12.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf(100, 90, 80, 70).forEach { scale ->
                        val active = renderScale == scale
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(12.dp))
                                .background(if (active) palette.accent else Color(0xFF191924))
                                .border(
                                    1.dp,
                                    if (active) palette.accent else palette.accentBorder.copy(alpha = 0.35f),
                                    RoundedCornerShape(12.dp)
                                )
                                .clickable { onSelectRenderScale(scale) }
                                .padding(vertical = 12.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "$scale%",
                                color = Color.White,
                                fontWeight = FontWeight.ExtraBold,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 13.sp
                            )
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
        }
    }

    if (showAddDialog) {
        val candidates = (installedApps + listOf(
            GameAppItem("com.dts.freefireth", "Free Fire"),
            GameAppItem("com.dts.freefiremax", "Free Fire MAX"),
            GameAppItem("com.roblox.client", "Roblox"),
            GameAppItem("com.tencent.ig", "PUBG MOBILE"),
            GameAppItem("com.activision.callofduty.shooter", "Call of Duty Mobile")
        )).distinctBy { it.packageName }

        AlertDialog(
            onDismissRequest = { showAddDialog = false },
            containerColor = palette.cardSurfaceSolid,
            title = {
                Text("Adicionar Jogo Instalado", color = palette.textPrimary, fontWeight = FontWeight.Bold)
            },
            text = {
                LazyColumn(
                    modifier = Modifier.height(280.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(candidates, key = { it.packageName }) { app ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color(0xFF1A1A26))
                                .clickable {
                                    onAddGame(app)
                                    onSelectGame(app.packageName)
                                    showAddDialog = false
                                }
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(app.name, color = palette.textPrimary, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                                Text(app.packageName, color = palette.textSecondary, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                            }
                            Text("+ ADD", color = palette.accent, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showAddDialog = false }) {
                    Text("Fechar", color = palette.accent)
                }
            }
        )
    }

    activeHelp?.let { help ->
        FeatureHelpDialog(help = help, onDismiss = { activeHelp = null })
    }
}
