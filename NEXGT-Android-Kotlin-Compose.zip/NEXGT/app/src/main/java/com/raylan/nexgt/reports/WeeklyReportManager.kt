package com.raylan.nexgt.reports

import android.Manifest
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.raylan.nexgt.MainActivity
import com.raylan.nexgt.data.NexgtCatalog
import com.raylan.nexgt.data.NexgtRepository
import java.util.Calendar

object WeeklyReportScheduler {
    const val CHANNEL_ID = "nexgt_weekly_report_channel"
    const val NOTIFICATION_ID = 7077
    const val ACTION_SHOW_WEEKLY_REPORT = "com.raylan.nexgt.ACTION_WEEKLY_REPORT"
    private const val REQUEST_CODE_ALARM = 7001

    fun computeNextSundayTriggerMillis(nowMillis: Long = System.currentTimeMillis()): Long {
        val cal = Calendar.getInstance().apply {
            timeInMillis = nowMillis
            set(Calendar.HOUR_OF_DAY, 10)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        val currentDow = cal.get(Calendar.DAY_OF_WEEK)
        val daysUntilSunday = (Calendar.SUNDAY - currentDow + 7) % 7
        if (daysUntilSunday == 0 && cal.timeInMillis <= nowMillis) {
            cal.add(Calendar.DAY_OF_YEAR, 7)
        } else if (daysUntilSunday > 0) {
            cal.add(Calendar.DAY_OF_YEAR, daysUntilSunday)
        }
        return cal.timeInMillis
    }

    fun scheduleSundayReport(context: Context) {
        runCatching {
            val repo = NexgtRepository(context)
            if (!repo.isWeeklyReportEnabled()) {
                cancelSundayReport(context)
                return
            }
            val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val pendingIntent = buildAlarmPendingIntent(context)
            val triggerAt = computeNextSundayTriggerMillis()
            alarmManager.setInexactRepeating(
                AlarmManager.RTC,
                triggerAt,
                AlarmManager.INTERVAL_DAY * 7,
                pendingIntent
            )
        }
    }

    fun cancelSundayReport(context: Context) {
        runCatching {
            val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            alarmManager.cancel(buildAlarmPendingIntent(context))
        }
    }

    fun showDiscreetWeeklyNotificationNow(context: Context): Boolean {
        return runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                val granted = ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.POST_NOTIFICATIONS
                ) == PackageManager.PERMISSION_GRANTED
                if (!granted) return false
            }

            ensureDiscreetChannel(context)
            val repo = NexgtRepository(context)
            val stats = repo.getWeeklyReportStats()
            val hw = repo.readHardwareInfo()
            val apps = repo.getInstalledUserApps()
            val scoreReport = NexgtCatalog.calculateSystemScore(
                freeRamMb = hw.freeRamMb,
                totalRamMb = hw.totalRamMb,
                lastCleanTimestampMs = stats.lastCleanTimestampMs,
                frozenAppsCount = apps.count { it.isFrozen },
                stoppedAppsThisWeek = stats.appsStoppedCount,
                activeFunctionsCount = stats.lastKnownActiveFunctions,
                shizukuConnected = false
            )

            val spaceFormatted = formatMbOrGb(stats.savedSpaceMb)
            val ramFormatted = formatMbOrGb(stats.ramFreedMb)
            val summaryText = "Espaço economizado: $spaceFormatted • RAM liberada: $ramFormatted • ${stats.appsStoppedCount} apps parados • Saúde: ${scoreReport.score}/100"

            val openIntent = Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            }
            val contentIntent = PendingIntent.getActivity(
                context,
                7002,
                openIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val notification = NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_menu_info_details)
                .setContentTitle("FF Boost • Resumo Semanal de Domingo")
                .setContentText("Economia: $spaceFormatted • RAM: $ramFormatted • Nota ${scoreReport.score}/100")
                .setStyle(NotificationCompat.BigTextStyle().bigText(summaryText))
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .setSilent(true)
                .setAutoCancel(true)
                .setOnlyAlertOnce(true)
                .setContentIntent(contentIntent)
                .build()

            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.notify(NOTIFICATION_ID, notification)
            true
        }.getOrDefault(false)
    }

    private fun ensureDiscreetChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Relatório Semanal (Domingo)",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Notificação discreta aos domingos com economia de espaço e RAM."
                setSound(null, null)
                enableVibration(false)
                setShowBadge(false)
            }
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(channel)
        }
    }

    private fun buildAlarmPendingIntent(context: Context): PendingIntent {
        val intent = Intent(context, WeeklyReportReceiver::class.java).apply {
            action = ACTION_SHOW_WEEKLY_REPORT
        }
        return PendingIntent.getBroadcast(
            context,
            REQUEST_CODE_ALARM,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    fun formatMbOrGb(mb: Long): String {
        return if (mb >= 1024L) {
            val gb = mb / 1024.0
            String.format(java.util.Locale.US, "%.1f GB", gb)
        } else {
            "$mb MB"
        }
    }
}

class WeeklyReportReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val action = intent?.action ?: return
        when (action) {
            WeeklyReportScheduler.ACTION_SHOW_WEEKLY_REPORT -> {
                WeeklyReportScheduler.showDiscreetWeeklyNotificationNow(context)
            }
            Intent.ACTION_BOOT_COMPLETED,
            Intent.ACTION_MY_PACKAGE_REPLACED -> {
                WeeklyReportScheduler.scheduleSundayReport(context)
            }
        }
    }
}
