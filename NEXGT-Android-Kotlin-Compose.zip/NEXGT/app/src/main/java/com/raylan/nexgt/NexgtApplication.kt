package com.raylan.nexgt

import android.app.Application
import com.raylan.nexgt.reports.WeeklyReportScheduler
import com.raylan.nexgt.shizuku.ShizukuManager

class NexgtApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        runCatching {
            ShizukuManager.init()
            WeeklyReportScheduler.scheduleSundayReport(this)
        }
    }
}
