package com.raylan.nexgt.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import com.raylan.nexgt.ui.theme.LocalNexgtPalette
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun GojoFloatingBannerCanvas(
    modifier: Modifier = Modifier
        .fillMaxWidth()
        .height(210.dp)
) {
    val palette = LocalNexgtPalette.current
    val accent = palette.accent

    val infiniteTransition = rememberInfiniteTransition(label = "gojo_levitation")
    val floatOffset by infiniteTransition.animateFloat(
        initialValue = -10f,
        targetValue = 10f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 2200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "float_y"
    )
    val auraPulse by infiniteTransition.animateFloat(
        initialValue = 0.72f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1600, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "aura_pulse"
    )
    val orbitAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = (2f * PI).toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 4800, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "orbit_angle"
    )

    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        val cx = w * 0.74f
        val cy = h * 0.54f + floatOffset

        // Fundo de energia amaldiçoada radial
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(
                    accent.copy(alpha = 0.36f * auraPulse.coerceAtMost(1f)),
                    accent.copy(alpha = 0.12f),
                    Color.Transparent
                ),
                center = Offset(cx, cy),
                radius = h * 0.68f * auraPulse
            ),
            radius = h * 0.68f * auraPulse,
            center = Offset(cx, cy)
        )

        // Anéis de expansão de domínio atrás do personagem
        drawCircle(
            color = accent.copy(alpha = 0.35f),
            radius = h * 0.42f * auraPulse,
            center = Offset(cx, cy),
            style = Stroke(width = 2.2f)
        )
        drawCircle(
            color = accent.copy(alpha = 0.18f),
            radius = h * 0.54f,
            center = Offset(cx, cy),
            style = Stroke(width = 1.4f)
        )

        // Raios de energia ao redor
        for (i in 0 until 6) {
            val angle = orbitAngle + i * (PI.toFloat() / 3f)
            val rInner = h * 0.28f
            val rOuter = h * 0.52f
            val x1 = cx + cos(angle) * rInner
            val y1 = cy + sin(angle) * rInner * 0.85f
            val xm = cx + cos(angle + 0.18f) * ((rInner + rOuter) * 0.52f)
            val ym = cy + sin(angle + 0.18f) * ((rInner + rOuter) * 0.46f)
            val x2 = cx + cos(angle - 0.08f) * rOuter
            val y2 = cy + sin(angle - 0.08f) * rOuter * 0.88f

            val bolt = Path().apply {
                moveTo(x1, y1)
                lineTo(xm, ym)
                lineTo(x2, y2)
            }
            drawPath(
                path = bolt,
                color = accent.copy(alpha = 0.78f),
                style = Stroke(width = 2.8f, cap = StrokeCap.Round)
            )
        }

        // Partículas orbitantes
        for (p in 0 until 10) {
            val a = orbitAngle * 1.4f + p * 0.63f
            val dist = h * (0.33f + (p % 3) * 0.09f)
            val px = cx + cos(a) * dist
            val py = cy + sin(a) * dist * 0.75f
            drawCircle(
                color = if (p % 2 == 0) accent else Color.White.copy(alpha = 0.85f),
                radius = if (p % 2 == 0) 3.6f else 2.2f,
                center = Offset(px, py)
            )
        }

        // Sombra no solo acompanhando a levitação
        drawOval(
            color = accent.copy(alpha = 0.22f),
            topLeft = Offset(cx - 38f, h * 0.89f),
            size = Size(76f, 12f)
        )

        // Gola alta escura e ombros (uniforme Jujutsu)
        val torsoPath = Path().apply {
            moveTo(cx - 46f, cy + 72f)
            lineTo(cx - 32f, cy + 20f)
            lineTo(cx - 16f, cy + 12f)
            lineTo(cx + 16f, cy + 12f)
            lineTo(cx + 32f, cy + 20f)
            lineTo(cx + 46f, cy + 72f)
            close()
        }
        drawPath(path = torsoPath, color = Color(0xFF14141D))
        drawPath(
            path = torsoPath,
            color = accent.copy(alpha = 0.55f),
            style = Stroke(width = 1.8f)
        )

        // Gola alta central
        drawRoundRect(
            color = Color(0xFF191924),
            topLeft = Offset(cx - 18f, cy + 6f),
            size = Size(36f, 24f),
            cornerRadius = CornerRadius(6f, 6f)
        )

        // Pescoço e Rosto
        drawRoundRect(
            color = Color(0xFFF3DDD1),
            topLeft = Offset(cx - 8f, cy - 2f),
            size = Size(16f, 16f),
            cornerRadius = CornerRadius(4f, 4f)
        )

        val headPath = Path().apply {
            moveTo(cx - 21f, cy - 26f)
            lineTo(cx + 21f, cy - 26f)
            lineTo(cx + 19f, cy - 4f)
            lineTo(cx, cy + 8f)
            lineTo(cx - 19f, cy - 4f)
            close()
        }
        drawPath(path = headPath, color = Color(0xFFF8E5DA))

        // Sorriso confiante sutil
        drawLine(
            color = Color(0xFF8C5D53),
            start = Offset(cx - 6f, cy - 1f),
            end = Offset(cx + 7f, cy - 2.5f),
            strokeWidth = 2.1f,
            cap = StrokeCap.Round
        )

        // Venda escura característica + brilho dos Seis Olhos na cor do tema
        drawRoundRect(
            color = Color(0xFF0C0C12),
            topLeft = Offset(cx - 22f, cy - 29f),
            size = Size(44f, 17f),
            cornerRadius = CornerRadius(5f, 5f)
        )
        drawLine(
            color = accent,
            start = Offset(cx - 14f, cy - 20f),
            end = Offset(cx - 5f, cy - 20f),
            strokeWidth = 2.8f,
            cap = StrokeCap.Round
        )
        drawLine(
            color = accent,
            start = Offset(cx + 5f, cy - 20f),
            end = Offset(cx + 14f, cy - 20f),
            strokeWidth = 2.8f,
            cap = StrokeCap.Round
        )

        // Cabelo branco espetado em camadas
        val hairBack = Path().apply {
            moveTo(cx - 25f, cy - 24f)
            lineTo(cx - 38f, cy - 46f)
            lineTo(cx - 20f, cy - 42f)
            lineTo(cx - 26f, cy - 66f)
            lineTo(cx - 7f, cy - 52f)
            lineTo(cx + 4f, cy - 72f)
            lineTo(cx + 14f, cy - 50f)
            lineTo(cx + 32f, cy - 63f)
            lineTo(cx + 24f, cy - 41f)
            lineTo(cx + 40f, cy - 44f)
            lineTo(cx + 25f, cy - 24f)
            close()
        }
        drawPath(
            path = hairBack,
            brush = Brush.verticalGradient(
                colors = listOf(Color.White, Color(0xFFDDE2F0))
            )
        )
        drawPath(
            path = hairBack,
            color = accent.copy(alpha = 0.45f),
            style = Stroke(width = 1.5f)
        )

        // Aura nas mãos (Vazio Roxo / Técnica na cor do tema)
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(Color.White, accent, Color.Transparent),
                center = Offset(cx - 40f, cy + 28f),
                radius = 16f
            ),
            radius = 16f,
            center = Offset(cx - 40f, cy + 28f)
        )
    }
}
