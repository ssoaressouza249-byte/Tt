package com.raylan.nexgt.data

enum class NavTab(val label: String) {
    HOME("Início"),
    GAMES("Jogos"),
    FPS_120("120 FPS"),
    TWEAKS("Ajustes"),
    AX_MANAGE("AxManage"),
    TOOLS("Tools")
}

enum class FeatureRiskLevel(val label: String) {
    SAFE("Seguro"),
    ADVANCED("Avançado"),
    HARDWARE("Hardware")
}

enum class EdgeLockScope(val label: String) {
    GAME_ONLY("Somente Jogo"),
    FULL_SYSTEM("Sistema Todo")
}

enum class TweakCategory(val label: String) {
    PERFORMANCE("Desempenho"),
    DISPLAY("Tela e Imagem"),
    SYSTEM("Sistema"),
    SOUND("Som"),
    INTERNET("Internet")
}

enum class QuickProfile(
    val id: String,
    val title: String,
    val subtitle: String,
    val fpsScore: Float,
    val batteryScore: Float,
    val coolnessScore: Float
) {
    EXTREME("extreme", "EXTREMO", "Máximo FPS 120Hz", 1.0f, 0.35f, 0.45f),
    BALANCED("balanced", "EQUILIBRADO", "Estável 90 FPS", 0.78f, 0.72f, 0.75f),
    BATTERY("battery", "BATERIA", "Foco autonomia", 0.50f, 0.96f, 0.92f),
    CUSTOM("custom", "PERSONAL.", "Perfil customizado", 0.88f, 0.65f, 0.68f)
}

data class GameAppItem(
    val packageName: String,
    val name: String,
    val isAdded: Boolean = true,
    val isFrozen: Boolean = false,
    val isSystem: Boolean = false
)

data class HardwareInfo(
    val model: String = "Desconhecido",
    val socOrGpu: String = "ARM64",
    val refreshRateHz: Int = 60,
    val androidVersion: String = "14",
    val totalRamMb: Long = 0L,
    val freeRamMb: Long = 0L
)

data class Fps120Module(
    val id: String,
    val title: String,
    val description: String,
    val commandTemplate: String,
    val resetCommandTemplate: String,
    val enabled: Boolean = false
)

data class AxManageModule(
    val id: String,
    val code: String,
    val title: String,
    val subsystem: String,
    val description: String,
    val enableCmdTemplate: String,
    val disableCmdTemplate: String,
    val enabled: Boolean = false
)

data class TweakItem(
    val id: String,
    val title: String,
    val summary: String,
    val category: TweakCategory,
    val enableCmd: String,
    val disableCmd: String,
    val isFavorite: Boolean = false,
    val enabled: Boolean = false
)

data class SmartEngineFeature(
    val id: String,
    val title: String,
    val description: String,
    val enabled: Boolean = false
)

data class WeeklyReportStats(
    val savedSpaceMb: Long = 0L,
    val ramFreedMb: Long = 0L,
    val cleanCount: Int = 0,
    val appsStoppedCount: Int = 0,
    val lastCleanTimestampMs: Long = 0L,
    val sundayReportEnabled: Boolean = true,
    val lastKnownActiveFunctions: Int = 3
)

data class DeepRamCleanResult(
    val stepABackgroundKilled: Int = 0,
    val stepBForceStopped: Int = 0,
    val stepCGcExecuted: Boolean = false,
    val ramFreedMb: Long = 0L,
    val spaceSavedMb: Long = 0L,
    val usedShizukuForceStop: Boolean = false,
    val stoppedPackages: List<String> = emptyList()
)

data class SystemScoreReport(
    val score: Int = 55,
    val tierLabel: String = "Regular",
    val ramPoints: Int = 15,
    val cleanPoints: Int = 0,
    val organizationPoints: Int = 0,
    val boostPoints: Int = 5
)

data class DpiBackupInfo(
    val physicalDensity: Int = 440,
    val overrideDensity: Int? = null,
    val screenWidthPx: Int = 1080
) {
    val effectiveDensity: Int get() = overrideDensity ?: physicalDensity
    val smallestWidthDpi: Int get() = ((screenWidthPx * 160f) / effectiveDensity.coerceAtLeast(120)).toInt()
}

data class DpiPreset(
    val id: String,
    val label: String,
    val targetDpi: Int?
)

data class DpiChangerUiState(
    val screenWidthPx: Int = 1080,
    val physicalDensity: Int = 440,
    val overrideDensity: Int? = null,
    val currentSmallestWidthDpi: Int = 392,
    val pendingConfirmation: Boolean = false,
    val countdownSeconds: Int = 15,
    val backupBeforeChange: DpiBackupInfo? = null,
    val appliedTargetDpi: Int? = null,
    val appliedDensity: Int? = null,
    val errorMessage: String? = null
)

data class HardwareHelpContent(
    val title: String,
    val risk: FeatureRiskLevel,
    val hardwareImpact: String,
    val whyUse: String,
    val command: String? = null
)

data class DnsBenchmarkItem(
    val id: String,
    val name: String,
    val ip: String,
    val specifier: String,
    val pingMs: Int = -1
)

data class DnsShieldUiState(
    val active: Boolean = false,
    val isTesting: Boolean = false,
    val selectedDns: DnsBenchmarkItem? = null,
    val results: List<DnsBenchmarkItem> = emptyList(),
    val backgroundLocked: Boolean = false
)

data class ShaderCleanResult(
    val targetPackage: String,
    val clearedFilesCount: Int,
    val freedMb: Int
)

data class SmoothRecorderUiState(
    val active: Boolean = false,
    val recorderPackage: String = "com.android.systemui.screenrecord",
    val recorderLabel: String = "Gravador Nativo"
)

data class CoolDownUiState(
    val active: Boolean = false,
    val remainingSeconds: Int = 120,
    val startTempCelsius: Float = 42.5f,
    val currentTempCelsius: Float = 36.2f,
    val previousBrightness: Int = 140
)

data class HudSensitivityProfile(
    val id: String,
    val name: String,
    val dpi: Int,
    val general: Int,
    val redDot: Int,
    val scope2x: Int,
    val scope4x: Int,
    val awm: Int,
    val notes: String
)

data class EdgeLockUiState(
    val active: Boolean = false,
    val scope: EdgeLockScope = EdgeLockScope.GAME_ONLY
)

data class ActiveFunctionEntry(
    val id: String,
    val category: String,
    val title: String,
    val sourceType: String
)

object NexgtCatalog {
    val defaultGames: List<GameAppItem> = listOf(
        GameAppItem("com.dts.freefireth", "Free Fire", isAdded = true),
        GameAppItem("com.dts.freefiremax", "Free Fire MAX", isAdded = true),
        GameAppItem("com.roblox.client", "Roblox", isAdded = true)
    )

    val smartEngineDefaults: List<SmartEngineFeature> = listOf(
        SmartEngineFeature("auto_detect", "Detecção Automática", "Aplica perfil ao abrir jogo", true),
        SmartEngineFeature("game_only", "Só no Jogo", "Restaura ajustes ao sair", true),
        SmartEngineFeature("ia_void", "IA Void", "Alocação dinâmica de CPU/GPU", false),
        SmartEngineFeature("adaptive_fps", "FPS Adaptativo", "Estabiliza frame-pacing", true),
        SmartEngineFeature("perf_mode", "Modo Desempenho", "Prioridade máxima no GameService", false)
    )

    fun buildFps120Modules(): List<Fps120Module> = listOf(
        Fps120Module(
            id = "fps_game_service",
            title = "1. Destravar FPS via GameService",
            description = "Força modo performance e meta de 120 FPS diretamente no pacote.",
            commandTemplate = "cmd game set --mode performance --fps 120 {pkg} && cmd game mode performance {pkg}",
            resetCommandTemplate = "cmd game reset {pkg}"
        ),
        Fps120Module(
            id = "fps_downscale",
            title = "2. Downscale GPU (0.75x)",
            description = "Alivia carga de pixel shader mantendo nitidez para ganho bruto de FPS.",
            commandTemplate = "cmd game set --mode performance --downscale 0.75 {pkg}",
            resetCommandTemplate = "cmd game set --mode standard --downscale 1.0 {pkg}"
        ),
        Fps120Module(
            id = "fps_thermal",
            title = "3. Bloquear Estrangulamento Térmico",
            description = "Impede queda forçada de clock para 30/45 FPS durante partidas longas.",
            commandTemplate = "cmd thermalservice override-status 0",
            resetCommandTemplate = "cmd thermalservice reset"
        ),
        Fps120Module(
            id = "fps_fixed_perf",
            title = "4. Modo Performance Fixo CPU/GPU",
            description = "Trava frequências em estado de alto desempenho pelo PowerManager.",
            commandTemplate = "cmd power set-fixed-performance-mode-enabled true",
            resetCommandTemplate = "cmd power set-fixed-performance-mode-enabled false"
        ),
        Fps120Module(
            id = "fps_swap_interval",
            title = "5. Remover Trava SwapInterval & Divisor",
            description = "Zera espera de VSync EGL e remove divisor de quadros HWUI.",
            commandTemplate = "setprop debug.egl.swapinterval 0 && setprop debug.hwui.fps_divisor 1",
            resetCommandTemplate = "setprop debug.egl.swapinterval 1 && setprop debug.hwui.fps_divisor 0"
        ),
        Fps120Module(
            id = "fps_aot_compile",
            title = "6. Compilação Nativa Total (AOT)",
            description = "Compila bytecode completo do jogo em código nativo para zerar engasgos.",
            commandTemplate = "cmd package compile -m everything -f {pkg}",
            resetCommandTemplate = "cmd package compile -m speed-profile {pkg}"
        ),
        Fps120Module(
            id = "fps_refresh_120",
            title = "7. Sincronizar Tela em 120Hz",
            description = "Trava taxa mínima e máxima de atualização do display em 120.0 Hz.",
            commandTemplate = "settings put system peak_refresh_rate 120.0 && settings put system min_refresh_rate 120.0",
            resetCommandTemplate = "settings delete system min_refresh_rate && settings put system peak_refresh_rate 60.0"
        ),
        Fps120Module(
            id = "fps_surfaceflinger",
            title = "8. Desativar Backpressure SurfaceFlinger",
            description = "Reduz fila de composição de quadros e elimina atraso de renderização.",
            commandTemplate = "setprop debug.sf.disable_backpressure 1",
            resetCommandTemplate = "setprop debug.sf.disable_backpressure 0"
        )
    )

    // 14 Módulos AxManage
    fun buildAxManageModules(): List<AxManageModule> = listOf(
        AxManageModule(
            id = "ax_01",
            code = "AX-01",
            title = "AxScheduler Boost",
            subsystem = "Kernel / Sched",
            description = "Coloca o pacote do jogo no bucket ativo e prioriza threads principais.",
            enableCmdTemplate = "am set-standby-bucket {pkg} active && cmd game mode performance {pkg}",
            disableCmdTemplate = "cmd game mode standard {pkg}"
        ),
        AxManageModule(
            id = "ax_02",
            code = "AX-02",
            title = "AxVulkan Pipeline",
            subsystem = "GPU / Render",
            description = "Ativa backend SkiaVK para menor overhead de draw calls na GPU.",
            enableCmdTemplate = "setprop debug.hwui.renderer skiavk && setprop debug.renderengine.backend skiavk",
            disableCmdTemplate = "setprop debug.hwui.renderer skiagl"
        ),
        AxManageModule(
            id = "ax_03",
            code = "AX-03",
            title = "AxTouch Ultra 240Hz",
            subsystem = "Touch / Input",
            description = "Acelera resposta de ponteiro e reduz tempo de toque longo.",
            enableCmdTemplate = "settings put secure long_press_timeout 200 && settings put system pointer_speed 6",
            disableCmdTemplate = "settings put secure long_press_timeout 400 && settings put system pointer_speed 0"
        ),
        AxManageModule(
            id = "ax_04",
            code = "AX-04",
            title = "AxThermal Bypass",
            subsystem = "Thermal / Clock",
            description = "Bloqueia redução térmica de FPS durante sessões intensas.",
            enableCmdTemplate = "cmd thermalservice override-status 0",
            disableCmdTemplate = "cmd thermalservice reset"
        ),
        AxManageModule(
            id = "ax_05",
            code = "AX-05",
            title = "AxSurfaceFlinger Zero",
            subsystem = "Compositor",
            description = "Desativa backpressure e habilita latch unsignaled para zero input lag.",
            enableCmdTemplate = "setprop debug.sf.disable_backpressure 1 && setprop debug.sf.latch_unsignaled 1",
            disableCmdTemplate = "setprop debug.sf.disable_backpressure 0 && setprop debug.sf.latch_unsignaled 0"
        ),
        AxManageModule(
            id = "ax_06",
            code = "AX-06",
            title = "AxRAM Purifier",
            subsystem = "Memória / ZRAM",
            description = "Executa trim global de caches e encerra processos ociosos.",
            enableCmdTemplate = "pm trim-caches 999G && am kill-all",
            disableCmdTemplate = "echo ram_normal"
        ),
        AxManageModule(
            id = "ax_07",
            code = "AX-07",
            title = "AxAOT Compiler Pro",
            subsystem = "ART / Dex2Oat",
            description = "Compila 100% do código do jogo em nativo com modo everything.",
            enableCmdTemplate = "cmd package compile -m everything -f {pkg}",
            disableCmdTemplate = "cmd package compile -m speed-profile {pkg}"
        ),
        AxManageModule(
            id = "ax_08",
            code = "AX-08",
            title = "AxFramePacer 120",
            subsystem = "Display / Hz",
            description = "Trava taxa de atualização em 120Hz e zera swapinterval EGL.",
            enableCmdTemplate = "settings put system peak_refresh_rate 120.0 && settings put system min_refresh_rate 120.0 && setprop debug.egl.swapinterval 0",
            disableCmdTemplate = "settings delete system min_refresh_rate && setprop debug.egl.swapinterval 1"
        ),
        AxManageModule(
            id = "ax_09",
            code = "AX-09",
            title = "AxPower Lock",
            subsystem = "Power / SoC",
            description = "Mantém o PowerManager em modo de desempenho fixo contínuo.",
            enableCmdTemplate = "cmd power set-fixed-performance-mode-enabled true",
            disableCmdTemplate = "cmd power set-fixed-performance-mode-enabled false"
        ),
        AxManageModule(
            id = "ax_10",
            code = "AX-10",
            title = "AxNet PingShield",
            subsystem = "Rede / UDP",
            description = "Restringe banda em segundo plano e renova cache DNS para menor ping.",
            enableCmdTemplate = "cmd netpolicy set restrict-background true && cmd connectivity clear-dns-cache",
            disableCmdTemplate = "cmd netpolicy set restrict-background false"
        ),
        AxManageModule(
            id = "ax_11",
            code = "AX-11",
            title = "AxAudio Footstep",
            subsystem = "Áudio / DSP",
            description = "Reduz latência do buffer de áudio para passos e disparos instantâneos.",
            enableCmdTemplate = "setprop audio.deep_buffer.media false && setprop audio.offload.disable 1",
            disableCmdTemplate = "setprop audio.deep_buffer.media true && setprop audio.offload.disable 0"
        ),
        AxManageModule(
            id = "ax_12",
            code = "AX-12",
            title = "AxDoze Guard",
            subsystem = "Background",
            description = "Força modo Doze em apps ociosos liberando CPU para o jogo.",
            enableCmdTemplate = "dumpsys deviceidle force-idle",
            disableCmdTemplate = "dumpsys deviceidle unforce"
        ),
        AxManageModule(
            id = "ax_13",
            code = "AX-13",
            title = "AxGPU Shader Cache",
            subsystem = "HWUI / Shaders",
            description = "Amplia cache de textura HWUI e remove divisor de FPS.",
            enableCmdTemplate = "setprop ro.hwui.texture_cache_size 96 && setprop debug.hwui.fps_divisor 1",
            disableCmdTemplate = "setprop ro.hwui.texture_cache_size 48 && setprop debug.hwui.fps_divisor 0"
        ),
        AxManageModule(
            id = "ax_14",
            code = "AX-14",
            title = "AxNotification Shield",
            subsystem = "Foco / UI",
            description = "Desativa pop-ups heads-up e vibração háptica durante a partida.",
            enableCmdTemplate = "settings put global heads_up_notifications_enabled 0 && settings put system haptic_feedback_enabled 0",
            disableCmdTemplate = "settings put global heads_up_notifications_enabled 1 && settings put system haptic_feedback_enabled 1"
        )
    )

    // 94 funções reais organizadas nas 5 sub-abas (64 originais + 30 novas)
    fun build94Tweaks(targetPkg: String = "com.dts.freefireth"): List<TweakItem> = listOf(
        // === DESEMPENHO (22) ===
        TweakItem("perf_01", "Guarda Térmica Zero", "Desativa redução térmica via thermalservice", TweakCategory.PERFORMANCE, "cmd thermalservice override-status 0", "cmd thermalservice reset", isFavorite = true),
        TweakItem("perf_02", "Bloquear Economia de Energia", "Desliga modo economia global", TweakCategory.PERFORMANCE, "settings put global low_power 0", "settings put global low_power 1", isFavorite = true),
        TweakItem("perf_03", "Anti-Travadas AOT", "Compila pacote alvo em modo everything", TweakCategory.PERFORMANCE, "cmd package compile -m everything -f $targetPkg", "cmd package compile -m speed-profile $targetPkg", isFavorite = true),
        TweakItem("perf_04", "Espremer RAM (Trim)", "Libera caches ociosos de apps", TweakCategory.PERFORMANCE, "pm trim-caches 999G", "echo cache_normal", isFavorite = true),
        TweakItem("perf_05", "Compactar Memória", "Força compactação ZRAM/Lmkd", TweakCategory.PERFORMANCE, "am kill-all", "echo ok"),
        TweakItem("perf_06", "Modo Performance Fixo", "Ativa clocks fixos no PowerService", TweakCategory.PERFORMANCE, "cmd power set-fixed-performance-mode-enabled true", "cmd power set-fixed-performance-mode-enabled false"),
        TweakItem("perf_07", "Renderizador SkiaGL", "Usa pipeline OpenGL no HWUI", TweakCategory.PERFORMANCE, "setprop debug.hwui.renderer skiagl", "setprop debug.hwui.renderer skiavk"),
        TweakItem("perf_08", "SwapInterval Zero", "Remove bloqueio VSync EGL", TweakCategory.PERFORMANCE, "setprop debug.egl.swapinterval 0", "setprop debug.egl.swapinterval 1"),
        TweakItem("perf_09", "Forçar MSAA Desligado", "Remove antialiasing pesado", TweakCategory.PERFORMANCE, "setprop debug.egl.force_msaa 0", "setprop debug.egl.force_msaa 1"),
        TweakItem("perf_10", "CPU Boost Touch", "Prioridade ao toque no compositor", TweakCategory.PERFORMANCE, "setprop debug.sf.latch_unsignaled 1", "setprop debug.sf.latch_unsignaled 0"),
        TweakItem("perf_11", "GameMode Performance", "Define GameManager para performance", TweakCategory.PERFORMANCE, "cmd game mode performance $targetPkg", "cmd game mode standard $targetPkg"),
        TweakItem("perf_12", "Desativar Backpressure", "Menos atraso no SurfaceFlinger", TweakCategory.PERFORMANCE, "setprop debug.sf.disable_backpressure 1", "setprop debug.sf.disable_backpressure 0"),
        TweakItem("perf_13", "Sem Limite Processos", "Evita swap excessivo em segundo plano", TweakCategory.PERFORMANCE, "device_config put activity_manager max_cached_processes 32", "device_config delete activity_manager max_cached_processes"),
        TweakItem("perf_14", "Cache Shader GPU", "Maximiza cache de shaders EGL", TweakCategory.PERFORMANCE, "setprop ro.hwui.texture_cache_size 72", "setprop ro.hwui.texture_cache_size 48"),
        TweakItem("perf_15", "Filtro ART Speed", "Otimiza compilação dex2oat", TweakCategory.PERFORMANCE, "setprop dalvik.vm.dex2oat-filter speed", "setprop dalvik.vm.dex2oat-filter speed-profile"),
        TweakItem("perf_16", "Prioridade I/O Jogo", "Reduz latência de leitura de assets", TweakCategory.PERFORMANCE, "cmd shortcut reset-all-throttling", "echo ok"),
        // +6 novas Desempenho
        TweakItem("perf_17", "Renderizador SkiaVK", "Pipeline Vulkan experimental HWUI", TweakCategory.PERFORMANCE, "setprop debug.hwui.renderer skiavk", "setprop debug.hwui.renderer skiagl"),
        TweakItem("perf_18", "Bucket Ativo Permanente", "Impede restrição App Standby no jogo", TweakCategory.PERFORMANCE, "am set-standby-bucket $targetPkg active", "am set-standby-bucket $targetPkg working_set"),
        TweakItem("perf_19", "Remover Divisor HWUI", "Define fps_divisor=1 sem cortes", TweakCategory.PERFORMANCE, "setprop debug.hwui.fps_divisor 1", "setprop debug.hwui.fps_divisor 0"),
        TweakItem("perf_20", "Perfil Shader 96MB", "Amplia buffer de texturas GPU", TweakCategory.PERFORMANCE, "setprop ro.hwui.texture_cache_size 96", "setprop ro.hwui.texture_cache_size 48"),
        TweakItem("perf_21", "Desativar Trace GPU", "Corta coleta de traces OpenGL", TweakCategory.PERFORMANCE, "setprop debug.egl.trace error", "setprop debug.egl.trace 0"),
        TweakItem("perf_22", "Compilar Pacotes Perfil", "Otimiza bibliotecas compartilhadas ART", TweakCategory.PERFORMANCE, "cmd package compile -m speed -f $targetPkg", "cmd package compile -m speed-profile $targetPkg"),

        // === TELA E IMAGEM (20) ===
        TweakItem("disp_01", "Taxa Máxima 120Hz", "Define peak_refresh_rate em 120.0", TweakCategory.DISPLAY, "settings put system peak_refresh_rate 120.0", "settings put system peak_refresh_rate 60.0"),
        TweakItem("disp_02", "Taxa Mínima 120Hz", "Trava min_refresh_rate em 120.0", TweakCategory.DISPLAY, "settings put system min_refresh_rate 120.0", "settings delete system min_refresh_rate"),
        TweakItem("disp_03", "Escala Janela 0.5x", "Animações de janela ultrarrápidas", TweakCategory.DISPLAY, "settings put global window_animation_scale 0.5", "settings put global window_animation_scale 1.0"),
        TweakItem("disp_04", "Escala Transição 0.5x", "Transições entre telas mais rápidas", TweakCategory.DISPLAY, "settings put global transition_animation_scale 0.5", "settings put global transition_animation_scale 1.0"),
        TweakItem("disp_05", "Duração Animator 0.5x", "Acelera animações do sistema", TweakCategory.DISPLAY, "settings put global animator_duration_scale 0.5", "settings put global animator_duration_scale 1.0"),
        TweakItem("disp_06", "Desativar Blur Janela", "Remove desfoque translúcido da UI", TweakCategory.DISPLAY, "settings put global disable_window_blurs 1", "settings put global disable_window_blurs 0"),
        TweakItem("disp_07", "Brilho Manual Fixo", "Impede oscilações de brilho em jogo", TweakCategory.DISPLAY, "settings put system screen_brightness_mode 0", "settings put system screen_brightness_mode 1"),
        TweakItem("disp_08", "Contador Nativo SF FPS", "Exibe FPS do SurfaceFlinger", TweakCategory.DISPLAY, "setprop debug.sf.showfps 1", "setprop debug.sf.showfps 0"),
        TweakItem("disp_09", "Overdraw GPU Desligado", "Garante zero depuração extra de overdraw", TweakCategory.DISPLAY, "setprop debug.hwui.overdraw false", "setprop debug.hwui.overdraw false"),
        TweakItem("disp_10", "Tempo Tela 10 Min", "Evita apagar tela durante partidas", TweakCategory.DISPLAY, "settings put system screen_off_timeout 600000", "settings put system screen_off_timeout 60000"),
        TweakItem("disp_11", "Modo Cor Saturado", "Realça contraste em mapas escuros", TweakCategory.DISPLAY, "settings put system display_color_mode 2", "settings put system display_color_mode 0"),
        TweakItem("disp_12", "Resposta Toque Rápida", "Reduz atraso de toque longo", TweakCategory.DISPLAY, "settings put secure long_press_timeout 250", "settings put secure long_press_timeout 400"),
        TweakItem("disp_13", "Ponteiro Preciso", "Melhora rastreio de toque contínuo", TweakCategory.DISPLAY, "settings put system pointer_speed 4", "settings put system pointer_speed 0"),
        TweakItem("disp_14", "Downscale 0.8x Nitidez", "Equilíbrio entre nitidez e FPS", TweakCategory.DISPLAY, "cmd game set --mode performance --downscale 0.8 $targetPkg", "cmd game set --mode standard --downscale 1.0 $targetPkg"),
        // +6 novas Tela e Imagem
        TweakItem("disp_15", "Animações 0.0x Instantâneo", "Zera escalas de transição do sistema", TweakCategory.DISPLAY, "settings put global window_animation_scale 0.0 && settings put global transition_animation_scale 0.0", "settings put global window_animation_scale 1.0 && settings put global transition_animation_scale 1.0"),
        TweakItem("disp_16", "Toque Ultra 180ms", "Resposta ultrarrápida ao segurar", TweakCategory.DISPLAY, "settings put secure long_press_timeout 180", "settings put secure long_press_timeout 400"),
        TweakItem("disp_17", "Sensibilidade Ponteiro Máx", "Velocidade máxima de rastreio (7)", TweakCategory.DISPLAY, "settings put system pointer_speed 7", "settings put system pointer_speed 0"),
        TweakItem("disp_18", "Taxa Fixa 90Hz Estável", "Equilibra fluidez e temperatura em 90Hz", TweakCategory.DISPLAY, "settings put system peak_refresh_rate 90.0 && settings put system min_refresh_rate 90.0", "settings delete system min_refresh_rate"),
        TweakItem("disp_19", "Desativar Filtro Noturno", "Remove camada amarela durante partidas", TweakCategory.DISPLAY, "settings put secure night_display_activated 0", "settings put secure night_display_activated 1"),
        TweakItem("disp_20", "Imersão Barra Navegação", "Otimiza gestos sem barras intrusivas", TweakCategory.DISPLAY, "settings put global policy_control immersive.full=$targetPkg", "settings put global policy_control null"),

        // === SISTEMA (20) ===
        TweakItem("sys_01", "Congelar 2º Plano", "Restringe execução oculta via appops", TweakCategory.SYSTEM, "appops set $targetPkg RUN_IN_BACKGROUND allow", "appops set $targetPkg RUN_IN_BACKGROUND default"),
        TweakItem("sys_02", "Modo Doze Forçado", "Suspende serviços em idle", TweakCategory.SYSTEM, "dumpsys deviceidle force-idle", "dumpsys deviceidle unforce"),
        TweakItem("sys_03", "Limpar Caches Gerais", "Remove caches temporários de sistema", TweakCategory.SYSTEM, "pm trim-caches 999G", "echo ok"),
        TweakItem("sys_04", "Não Manter Atividades", "Libera telas antigas da memória", TweakCategory.SYSTEM, "settings put global always_finish_activities 0", "settings put global always_finish_activities 0"),
        TweakItem("sys_05", "Sem Logcat Pesado", "Reduz escrita de logs em disco", TweakCategory.SYSTEM, "logcat -G 64K", "logcat -G 256K"),
        TweakItem("sys_06", "Desativar Backup Nuvem", "Evita upload automático em partida", TweakCategory.SYSTEM, "bmgr enable false", "bmgr enable true"),
        TweakItem("sys_07", "Economia Adaptativa Off", "Impede Android de limitar CPU", TweakCategory.SYSTEM, "settings put global adaptive_battery_management_enabled 0", "settings put global adaptive_battery_management_enabled 1"),
        TweakItem("sys_08", "Notificações Heads-Up Off", "Bloqueia banners sobre o jogo", TweakCategory.SYSTEM, "settings put global heads_up_notifications_enabled 0", "settings put global heads_up_notifications_enabled 1"),
        TweakItem("sys_09", "Vibrar ao Tocar Off", "Economiza ciclos e bateria no toque", TweakCategory.SYSTEM, "settings put system haptic_feedback_enabled 0", "settings put system haptic_feedback_enabled 1"),
        TweakItem("sys_10", "Verificador ADB Off", "Acelera abertura e instalação", TweakCategory.SYSTEM, "settings put global verifier_verify_adb_installs 0", "settings put global verifier_verify_adb_installs 1"),
        TweakItem("sys_11", "Stats de Uso Leve", "Reduz polling de estatísticas", TweakCategory.SYSTEM, "cmd usagestats clear-last-used-timestamps $targetPkg", "echo ok"),
        TweakItem("sys_12", "Reset Limite Jobs", "Libera fila de jobs presos", TweakCategory.SYSTEM, "cmd jobscheduler reset-execution-quota -u 0 $targetPkg", "echo ok"),
        TweakItem("sys_13", "Permissão Storage Rápida", "Mantém acesso rápido ao OBB", TweakCategory.SYSTEM, "appops set $targetPkg LEGACY_STORAGE allow", "appops set $targetPkg LEGACY_STORAGE default"),
        TweakItem("sys_14", "Modo Jogo Ativo", "Informa estado GAME_ACTIVE ao sistema", TweakCategory.SYSTEM, "cmd game set --mode performance $targetPkg", "cmd game reset $targetPkg"),
        // +6 novas Sistema
        TweakItem("sys_15", "Desativar Rotação Auto", "Trava orientação sem giros acidentais", TweakCategory.SYSTEM, "settings put system accelerometer_rotation 0", "settings put system accelerometer_rotation 1"),
        TweakItem("sys_16", "Bloquear Localização Fundo", "Evita polling GPS em 2º plano", TweakCategory.SYSTEM, "settings put secure location_mode 0", "settings put secure location_mode 3"),
        TweakItem("sys_17", "Cache ART Dex2Oat Limpo", "Revalida perfis de compilação", TweakCategory.SYSTEM, "cmd package bg-dexopt-job", "echo ok"),
        TweakItem("sys_18", "Prioridade WakeLock Jogo", "Mantém CPU ativa para o pacote", TweakCategory.SYSTEM, "appops set $targetPkg WAKE_LOCK allow", "appops set $targetPkg WAKE_LOCK default"),
        TweakItem("sys_19", "Sem Relatórios ANR", "Reduz pausas de diagnóstico em erro", TweakCategory.SYSTEM, "settings put secure anr_show_background 0", "settings put secure anr_show_background 1"),
        TweakItem("sys_20", "Auto-Sync Desligado", "Pausa sincronização em nuvem no jogo", TweakCategory.SYSTEM, "cmd content set-sync-automatically false", "cmd content set-sync-automatically true"),

        // === SOM (16) ===
        TweakItem("snd_01", "Baixa Latência Áudio", "Prioriza buffer de áudio para passos", TweakCategory.SOUND, "setprop audio.deep_buffer.media false", "setprop audio.deep_buffer.media true"),
        TweakItem("snd_02", "Desativar Som Teclado", "Remove cliques desnecessários", TweakCategory.SOUND, "settings put system sound_effects_enabled 0", "settings put system sound_effects_enabled 1"),
        TweakItem("snd_03", "Desativar Som Bloqueio", "Silencia trava de tela", TweakCategory.SOUND, "settings put system lockscreen_sounds_enabled 0", "settings put system lockscreen_sounds_enabled 1"),
        TweakItem("snd_04", "Áudio Bluetooth HD", "Prioriza estabilidade A2DP sem atraso", TweakCategory.SOUND, "settings put global bluetooth_a2dp_supports_optional_codecs_enabled 1", "settings put global bluetooth_a2dp_supports_optional_codecs_enabled 0"),
        TweakItem("snd_05", "Modo Mono Off (Estéreo)", "Garante separação esquerda/direita", TweakCategory.SOUND, "settings put system master_mono 0", "settings put system master_mono 0"),
        TweakItem("snd_06", "Balanço Centralizado", "Mantém áudio 50/50 nos fones", TweakCategory.SOUND, "settings put system master_balance 0.0", "settings put system master_balance 0.0"),
        TweakItem("snd_07", "Sem Limite Volume Seguro", "Evita redução súbita em fones", TweakCategory.SOUND, "settings put global audio_safe_volume_state 2", "settings put global audio_safe_volume_state 3"),
        TweakItem("snd_08", "Offload PCM Direto", "Reduz processamento extra na DSP", TweakCategory.SOUND, "setprop audio.offload.disable 1", "setprop audio.offload.disable 0"),
        TweakItem("snd_09", "Microfone Prioritário", "Estabiliza captura de voz em squad", TweakCategory.SOUND, "appops set $targetPkg RECORD_AUDIO allow", "appops set $targetPkg RECORD_AUDIO default"),
        TweakItem("snd_10", "Silenciar Toque Chamada", "Evita cortes de áudio durante jogo", TweakCategory.SOUND, "settings put global zen_mode 1", "settings put global zen_mode 0"),
        // +6 novas Som
        TweakItem("snd_11", "Áudio Espacial Fones", "Realça direção 360º de passos", TweakCategory.SOUND, "settings put global spatial_audio_enabled 1", "settings put global spatial_audio_enabled 0"),
        TweakItem("snd_12", "Desativar Som Carregador", "Remove alerta sonoro ao conectar cabo", TweakCategory.SOUND, "settings put global charging_sounds_enabled 0", "settings put global charging_sounds_enabled 1"),
        TweakItem("snd_13", "Sem Som Discagem", "Silencia tons DTMF do sistema", TweakCategory.SOUND, "settings put system dtmf_tone 0", "settings put system dtmf_tone 1"),
        TweakItem("snd_14", "Bluetooth Latência Baixa", "Desativa volume absoluto conflituoso", TweakCategory.SOUND, "settings put global bluetooth_disabled_profiles 0", "settings delete global bluetooth_disabled_profiles"),
        TweakItem("snd_15", "Foco Áudio Exclusivo", "Permite mixagem limpa no jogo", TweakCategory.SOUND, "appops set $targetPkg TAKE_AUDIO_FOCUS allow", "appops set $targetPkg TAKE_AUDIO_FOCUS default"),
        TweakItem("snd_16", "Buffer Voz Direto", "Melhora clareza na call do squad", TweakCategory.SOUND, "setprop vendor.audio.feature.concurrent_capture.enable true", "setprop vendor.audio.feature.concurrent_capture.enable false"),

        // === INTERNET (16) ===
        TweakItem("net_01", "DNS Privado Cloudflare", "Configura 1dot1dot1dot1.cloudflare-dns.com", TweakCategory.INTERNET, "settings put global private_dns_mode hostname && settings put global private_dns_specifier 1dot1dot1dot1.cloudflare-dns.com", "settings put global private_dns_mode off"),
        TweakItem("net_02", "DNS Google Baixo Ping", "Define dns.google para rotas rápidas", TweakCategory.INTERNET, "settings put global private_dns_mode hostname && settings put global private_dns_specifier dns.google", "settings put global private_dns_mode off"),
        TweakItem("net_03", "Wi-Fi Scan Throttling Off", "Estabiliza latência sem buscas extras", TweakCategory.INTERNET, "settings put global wifi_scan_throttle_enabled 1", "settings put global wifi_scan_throttle_enabled 0"),
        TweakItem("net_04", "Sempre Wi-Fi Ativo", "Mantém placa Wi-Fi em modo ativo", TweakCategory.INTERNET, "settings put global wifi_sleep_policy 2", "settings put global wifi_sleep_policy 0"),
        TweakItem("net_05", "Dados em 2º Plano Leve", "Ativa economia para apps paralelos", TweakCategory.INTERNET, "cmd netpolicy set restrict-background true", "cmd netpolicy set restrict-background false"),
        TweakItem("net_06", "Wakeup Wi-Fi Otimizado", "Reduz jitter de pacotes UDP", TweakCategory.INTERNET, "settings put global wifi_wakeup_enabled 0", "settings put global wifi_wakeup_enabled 1"),
        TweakItem("net_07", "TCP Congestion Cubic", "Ajuste de estabilidade de pacotes", TweakCategory.INTERNET, "settings put global tcp_default_init_rwnd 60", "settings delete global tcp_default_init_rwnd"),
        TweakItem("net_08", "Sem Verificação Captive", "Menos pings automáticos de sistema", TweakCategory.INTERNET, "settings put global captive_portal_mode 0", "settings put global captive_portal_mode 1"),
        TweakItem("net_09", "Liberar Sockets Ociosos", "Limpa conexões zumbis no netd", TweakCategory.INTERNET, "cmd connectivity clear-dns-cache", "echo ok"),
        TweakItem("net_10", "Modo Baixa Latência Wi-Fi", "Força Wi-Fi Low Latency Lock", TweakCategory.INTERNET, "cmd wifi set-wifi-enabled enabled", "echo ok"),
        // +6 novas Internet
        TweakItem("net_11", "DNS AdGuard Limpo", "Bloqueia rastreadores via dns.adguard-dns.com", TweakCategory.INTERNET, "settings put global private_dns_mode hostname && settings put global private_dns_specifier dns.adguard-dns.com", "settings put global private_dns_mode off"),
        TweakItem("net_12", "DNS Quad9 Seguro", "Rota rápida dns.quad9.net", TweakCategory.INTERNET, "settings put global private_dns_mode hostname && settings put global private_dns_specifier dns.quad9.net", "settings put global private_dns_mode off"),
        TweakItem("net_13", "Evitar Troca Wi-Fi/4G", "Impede alternância súbita em partida", TweakCategory.INTERNET, "settings put global mobile_data_always_on 0", "settings put global mobile_data_always_on 1"),
        TweakItem("net_14", "Sem Busca BLE Fundo", "Corta varredura Bluetooth que interfere no 2.4GHz", TweakCategory.INTERNET, "settings put global ble_scan_always_enabled 0", "settings put global ble_scan_always_enabled 1"),
        TweakItem("net_15", "Sem Busca Wi-Fi Fundo", "Evita perda de pacotes durante scans", TweakCategory.INTERNET, "settings put global wifi_scan_always_enabled 0", "settings put global wifi_scan_always_enabled 1"),
        TweakItem("net_16", "Whitelist Tráfego Jogo", "Uso irrestrito para o pacote", TweakCategory.INTERNET, "cmd netpolicy add restrict-background-whitelist 1000", "echo ok")
    )

    private val heavyPackageKeywords = listOf(
        "whatsapp", "instagram", "facebook", "katana", "orca", "tiktok", "musically",
        "kwai", "twitter", "discord", "telegram", "snapchat", "reddit", "pinterest",
        "shopee", "mercadolibre", "amazon", "aliexpress", "shein", "temu", "vending",
        "netflix", "spotify", "youtube", "twitch", "primevideo", "hbo", "disney",
        "pubg", "tencent.ig", "roblox", "brawlstars", "supercell", "callofduty",
        "activision", "minecraft", "genshin", "mobilelegends", "freefire"
    )

    fun isHeavyPackage(packageName: String): Boolean {
        val lower = packageName.lowercase()
        return heavyPackageKeywords.any { lower.contains(it) }
    }

    fun calculateSystemScore(
        freeRamMb: Long,
        totalRamMb: Long,
        lastCleanTimestampMs: Long,
        frozenAppsCount: Int,
        stoppedAppsThisWeek: Int,
        activeFunctionsCount: Int,
        shizukuConnected: Boolean,
        nowMs: Long = System.currentTimeMillis()
    ): SystemScoreReport {
        val base = 25
        val ramRatio = if (totalRamMb > 0L) {
            (freeRamMb.toFloat() / totalRamMb.toFloat()).coerceIn(0f, 1f)
        } else {
            0.45f
        }
        val ramPoints = ((ramRatio / 0.55f).coerceIn(0f, 1f) * 25f).toInt()

        val cleanPoints = if (lastCleanTimestampMs <= 0L) {
            0
        } else {
            val daysAgo = ((nowMs - lastCleanTimestampMs).coerceAtLeast(0L) / (1000L * 60L * 60L * 24L)).toInt()
            when {
                daysAgo <= 1 -> 20
                daysAgo <= 3 -> 16
                daysAgo <= 6 -> 12
                daysAgo == 7 -> 8
                else -> 3
            }
        }

        val orgUnits = frozenAppsCount + (stoppedAppsThisWeek / 2)
        val organizationPoints = (orgUnits * 3).coerceIn(0, 15)

        val boostPoints = (if (shizukuConnected) 5 else 0) + (activeFunctionsCount / 2).coerceIn(0, 10)
        val total = (base + ramPoints + cleanPoints + organizationPoints + boostPoints).coerceIn(0, 100)

        val tier = when {
            total >= 88 -> "Lendário"
            total >= 72 -> "Organizado"
            total >= 52 -> "Regular"
            else -> "Atenção"
        }

        return SystemScoreReport(
            score = total,
            tierLabel = tier,
            ramPoints = ramPoints,
            cleanPoints = cleanPoints,
            organizationPoints = organizationPoints,
            boostPoints = boostPoints
        )
    }

    const val DPI_MIN = 300
    const val DPI_MAX = 1200
    const val DPI_CONFIRM_SECONDS = 15

    val dpiPresets: List<DpiPreset> = listOf(
        DpiPreset("factory", "Padrão Fábrica", null),
        DpiPreset("sensi_med", "Sensi Média (550)", 550),
        DpiPreset("sensi_high", "Sensi Alta (680)", 680),
        DpiPreset("sensi_extreme", "Sensi Extrema (800)", 800)
    )

    fun parseWmDensityOutput(output: String, fallbackPhysical: Int = 440): Pair<Int, Int?> {
        val physicalMatch = Regex("Physical density:\\s*(\\d+)", RegexOption.IGNORE_CASE).find(output)
        val overrideMatch = Regex("Override density:\\s*(\\d+)", RegexOption.IGNORE_CASE).find(output)
        val physical = physicalMatch?.groupValues?.getOrNull(1)?.toIntOrNull() ?: fallbackPhysical
        val overrideVal = overrideMatch?.groupValues?.getOrNull(1)?.toIntOrNull()
        return physical to overrideVal
    }

    fun validateTargetDpi(dpi: Int?): String? {
        if (dpi == null) return "Informe um valor numérico válido de DPI."
        if (dpi < DPI_MIN || dpi > DPI_MAX) {
            return "Trava de segurança: use entre $DPI_MIN e $DPI_MAX DPI para proteger o SystemUI."
        }
        return null
    }

    fun computeDensityFromSmallestWidth(screenWidthPx: Int, targetDpi: Int): Int {
        val safeWidth = screenWidthPx.coerceAtLeast(480)
        val safeTarget = targetDpi.coerceIn(DPI_MIN, DPI_MAX)
        return kotlin.math.round((safeWidth * 160.0) / safeTarget).toInt().coerceAtLeast(120)
    }

    fun buildDpiRestoreCommand(backup: DpiBackupInfo?): String {
        val overrideVal = backup?.overrideDensity
        return if (overrideVal != null) {
            "wm density $overrideVal"
        } else {
            "wm density reset"
        }
    }

    val dnsProviders: List<DnsBenchmarkItem> = listOf(
        DnsBenchmarkItem("cloudflare", "Cloudflare Gamer", "1.1.1.1", "1dot1dot1dot1.cloudflare-dns.com"),
        DnsBenchmarkItem("google", "Google DNS", "8.8.8.8", "dns.google"),
        DnsBenchmarkItem("opendns", "OpenDNS", "208.67.222.222", "doh.opendns.com")
    )

    val recorderApps: List<Pair<String, String>> = listOf(
        "com.android.systemui.screenrecord" to "Gravador Nativo",
        "com.glitch.gg" to "Glip Screen Recorder",
        "com.hecorat.screenrecorder.free" to "AZ Screen Recorder",
        "com.rsupport.mvagent" to "Mobizen Recorder"
    )

    val defaultHudProfiles: List<HudSensitivityProfile> = listOf(
        HudSensitivityProfile("hud_branca", "Sensi Mira Branca", 580, 100, 96, 92, 88, 72, "Puxada rápida de Desert / UMP sem passar da cabeça"),
        HudSensitivityProfile("hud_camp", "Sensi Campeonato", 680, 98, 95, 90, 86, 65, "Estabilidade em trocação de média distância e gelo agachado"),
        HudSensitivityProfile("hud_4x", "Sensi 4x Precisão", 550, 94, 92, 89, 82, 60, "Controle fino para mira 4x aberta em longa distância")
    )

    fun buildShaderCleanCommand(pkg: String): String =
        "rm -rf /sdcard/Android/data/$pkg/cache/ShaderCache* /sdcard/Android/data/$pkg/code_cache/* && pm trim-caches 512M && cmd package compile -m speed-profile -f $pkg"

    fun buildDnsShieldCommand(specifier: String, pkg: String): String =
        "cmd connectivity clear-dns-cache && settings put global private_dns_mode hostname && settings put global private_dns_specifier $specifier && cmd netpolicy set restrict-background true && cmd netpolicy add restrict-background-whitelist 1000"

    fun buildSmoothRecorderCommand(targetPkg: String, recorderPkg: String, enable: Boolean): String =
        if (enable) {
            "settings put global window_animation_scale 0.0 && settings put global transition_animation_scale 0.0 && settings put global animator_duration_scale 0.0 && pm trim-caches 512M && am set-standby-bucket $targetPkg active && am set-standby-bucket $recorderPkg active && cmd game mode performance $targetPkg"
        } else {
            "settings put global window_animation_scale 1.0 && settings put global transition_animation_scale 1.0 && settings put global animator_duration_scale 1.0 && cmd game mode standard $targetPkg"
        }

    fun buildCoolDownCommand(targetPkg: String): String =
        "am force-stop $targetPkg && am kill-all && settings put system screen_brightness_mode 0 && settings put system screen_brightness 15 && cmd content set-sync-automatically false"

    fun buildCoolDownRestoreCommand(previousBrightness: Int): String =
        "settings put system screen_brightness ${previousBrightness.coerceIn(20, 255)} && cmd content set-sync-automatically true"

    fun buildEdgeLockCommand(scope: EdgeLockScope, targetPkg: String, enable: Boolean): String =
        if (!enable) {
            "settings put global policy_control null"
        } else if (scope == EdgeLockScope.GAME_ONLY) {
            "settings put global policy_control immersive.full=$targetPkg"
        } else {
            "settings put global policy_control immersive.full=*"
        }

    fun getTweakHelp(tweak: TweakItem): HardwareHelpContent {
        val risk = if (
            tweak.id.startsWith("perf_01") ||
            tweak.id.startsWith("perf_06") ||
            tweak.id.startsWith("perf_17") ||
            tweak.id.startsWith("disp_20")
        ) {
            FeatureRiskLevel.ADVANCED
        } else {
            FeatureRiskLevel.SAFE
        }
        val hwImpact = when (tweak.category) {
            TweakCategory.PERFORMANCE -> "Atua no escalonador de CPU/GPU, compilação ART (dex2oat) ou fila de renderização HWUI/Vulkan, mantendo clocks e draw calls estáveis sob carga."
            TweakCategory.DISPLAY -> "Ajusta taxa de atualização do painel (Hz), duração das escalas do SurfaceFlinger e resposta do controlador de toque (digitizer)."
            TweakCategory.SYSTEM -> "Reduz interrupções de processos em segundo plano (Doze/AppOps), logs de disco e sincronizações que disputam I/O e memória RAM."
            TweakCategory.SOUND -> "Reduz o tamanho do buffer DSP/PCM do Android para diminuir a latência entre o evento do jogo e a saída nos fones."
            TweakCategory.INTERNET -> "Otimiza resolução DNS, política de dados em 2º plano e evita varreduras Wi-Fi/BLE que geram picos de jitter."
        }
        return HardwareHelpContent(
            title = tweak.title,
            risk = risk,
            hardwareImpact = hwImpact,
            whyUse = tweak.summary,
            command = tweak.enableCmd
        )
    }

    fun getFpsModuleHelp(mod: Fps120Module, targetPkg: String): HardwareHelpContent {
        val risk = if (mod.id == "fps_thermal" || mod.id == "fps_fixed_perf") {
            FeatureRiskLevel.ADVANCED
        } else {
            FeatureRiskLevel.SAFE
        }
        return HardwareHelpContent(
            title = mod.title,
            risk = risk,
            hardwareImpact = "Configura GameManagerService, frequência mínima/máxima do display, pipeline EGL/SurfaceFlinger ou compilação nativa AOT diretamente no pacote $targetPkg.",
            whyUse = mod.description,
            command = mod.commandTemplate.replace("{pkg}", targetPkg)
        )
    }

    fun getAxModuleHelp(mod: AxManageModule, targetPkg: String): HardwareHelpContent {
        val risk = if (mod.code in listOf("AX-04", "AX-05", "AX-09")) {
            FeatureRiskLevel.ADVANCED
        } else {
            FeatureRiskLevel.SAFE
        }
        return HardwareHelpContent(
            title = "${mod.code} · ${mod.title}",
            risk = risk,
            hardwareImpact = "Atua no subsistema ${mod.subsystem}, ajustando parâmetros de kernel/compositor/memória diretamente via shell Shizuku UID 2000.",
            whyUse = mod.description,
            command = mod.enableCmdTemplate.replace("{pkg}", targetPkg)
        )
    }

    fun getToolHelp(toolId: String, targetPkg: String): HardwareHelpContent = when (toolId) {
        "dpi_safe" -> HardwareHelpContent(
            title = "Alterador de DPI Seguro (15s)",
            risk = FeatureRiskLevel.SAFE,
            hardwareImpact = "Recalcula a densidade lógica do DisplayMetrics no WindowManager (wm density) mantendo a resolução física nativa e restaurando automaticamente em 15s se não houver confirmação.",
            whyUse = "Aumenta a sensibilidade lateral da mira (puxada mais leve) sem precisar abrir as Opções do Desenvolvedor.",
            command = "wm density <densidade_calculada>"
        )
        "shader_cleaner" -> HardwareHelpContent(
            title = "Limpador de Cache de Shaders",
            risk = FeatureRiskLevel.SAFE,
            hardwareImpact = "Remove exclusivamente shaders pré-compilados obsoletos (code_cache / ShaderCache) da GPU sem tocar em arquivos de conta, HUD ou OBB do jogo.",
            whyUse = "Elimina engasgos nas primeiras partidas logo após atualizações do Free Fire ou outro jogo.",
            command = buildShaderCleanCommand(targetPkg)
        )
        "dns_shield" -> HardwareHelpContent(
            title = "Escudo de Ping & DNS Gamer",
            risk = FeatureRiskLevel.ADVANCED,
            hardwareImpact = "Esvazia o cache de resolução do netd, testa latência ICMP/TCP para Cloudflare, Google e OpenDNS e bloqueia tráfego paralelo via NetPolicy.",
            whyUse = "Evita saltos repentinos de ping (20ms para 999ms) causados por downloads e notificações em segundo plano.",
            command = buildDnsShieldCommand("1dot1dot1dot1.cloudflare-dns.com", targetPkg)
        )
        "smooth_recorder" -> HardwareHelpContent(
            title = "Modo Gravador Liso (Clipadas)",
            risk = FeatureRiskLevel.ADVANCED,
            hardwareImpact = "Zera animações do WindowManager, libera caches da RAM e eleva o bucket de agendamento CPU/GPU para o jogo e o app gravador simultaneamente.",
            whyUse = "Evita que o FPS caia pela metade ao gravar highlights e clipadas para TikTok/YouTube.",
            command = buildSmoothRecorderCommand(targetPkg, "com.android.systemui.screenrecord", true)
        )
        "cool_down" -> HardwareHelpContent(
            title = "Resfriamento Rápido (Cool Down)",
            risk = FeatureRiskLevel.HARDWARE,
            hardwareImpact = "Encerra processos pesados na CPU, reduz a corrente do backlight do display ao mínimo por 2 minutos, pausa auto-sync e monitora o sensor térmico da bateria em °C.",
            whyUse = "Reduz o aquecimento pós-partida rapidamente, preservando a saúde da bateria e evitando thermal throttling.",
            command = buildCoolDownCommand(targetPkg)
        )
        "hud_backup" -> HardwareHelpContent(
            title = "Backup de HUD / Sensibilidade",
            risk = FeatureRiskLevel.SAFE,
            hardwareImpact = "Armazena localmente perfis nomeados com DPI, sensibilidades de mira e observações, aplicando a DPI salva via WindowManager ao restaurar.",
            whyUse = "Permite testar novas configurações sem risco de perder aquela sensibilidade perfeita de campeonato.",
            command = null
        )
        "edge_lock" -> HardwareHelpContent(
            title = "Bloqueador de Gestos (Trava de Borda)",
            risk = FeatureRiskLevel.ADVANCED,
            hardwareImpact = "Aplica immersive.full no policy_control do WindowManager, ocultando barra de status e navegação e exigindo duplo deslize nas bordas.",
            whyUse = "Impede puxar notificações ou apertar Voltar acidentalmente na hora de subir capa ou puxar gelo rápido.",
            command = buildEdgeLockCommand(EdgeLockScope.GAME_ONLY, targetPkg, true)
        )
        else -> HardwareHelpContent(
            title = "Limpeza Real de RAM (3 Passos)",
            risk = FeatureRiskLevel.SAFE,
            hardwareImpact = "Passo A encerra processos em 2º plano via ActivityManager; Passo B executa am force-stop via Shizuku em apps pesados; Passo C aciona o Garbage Collector da JVM.",
            whyUse = "Libera RAM real ocupada por redes sociais e lojas impedindo que reiniciem imediatamente durante a partida.",
            command = "am force-stop <pacote_pesado> && pm trim-caches 999G"
        )
    }
}
