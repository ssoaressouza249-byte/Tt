package com.raylan.nexgt.data

import android.app.Application
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.raylan.nexgt.overlay.FloatingOverlayService
import com.raylan.nexgt.reports.WeeklyReportScheduler
import com.raylan.nexgt.shizuku.ShizukuConnectionState
import com.raylan.nexgt.shizuku.ShizukuLogEntry
import com.raylan.nexgt.shizuku.ShizukuManager
import com.raylan.nexgt.ui.theme.NexgtColorTheme
import com.raylan.nexgt.ui.theme.NexgtThemes
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class NexgtViewModel(application: Application) : AndroidViewModel(application) {
    private val repo = NexgtRepository(application)

    private val _selectedTheme = MutableStateFlow(
        NexgtThemes.all.find { it.id == repo.getSelectedThemeId() } ?: NexgtThemes.all.first()
    )
    val selectedTheme: StateFlow<NexgtColorTheme> = _selectedTheme.asStateFlow()

    private val _hardwareInfo = MutableStateFlow(repo.readHardwareInfo())
    val hardwareInfo: StateFlow<HardwareInfo> = _hardwareInfo.asStateFlow()

    private val _activeProfile = MutableStateFlow(QuickProfile.BALANCED)
    val activeProfile: StateFlow<QuickProfile> = _activeProfile.asStateFlow()

    private val _turboActive = MutableStateFlow(false)
    val turboActive: StateFlow<Boolean> = _turboActive.asStateFlow()

    private val _games = MutableStateFlow(NexgtCatalog.defaultGames)
    val games: StateFlow<List<GameAppItem>> = _games.asStateFlow()

    private val _installedApps = MutableStateFlow<List<GameAppItem>>(emptyList())
    val installedApps: StateFlow<List<GameAppItem>> = _installedApps.asStateFlow()

    private val _targetGamePackage = MutableStateFlow(NexgtCatalog.defaultGames.first().packageName)
    val targetGamePackage: StateFlow<String> = _targetGamePackage.asStateFlow()

    private val _renderScale = MutableStateFlow(100)
    val renderScale: StateFlow<Int> = _renderScale.asStateFlow()

    private val _smartEngine = MutableStateFlow(NexgtCatalog.smartEngineDefaults)
    val smartEngine: StateFlow<List<SmartEngineFeature>> = _smartEngine.asStateFlow()

    private val _fps120Modules = MutableStateFlow(NexgtCatalog.buildFps120Modules())
    val fps120Modules: StateFlow<List<Fps120Module>> = _fps120Modules.asStateFlow()

    private val _axManageModules = MutableStateFlow(NexgtCatalog.buildAxManageModules())
    val axManageModules: StateFlow<List<AxManageModule>> = _axManageModules.asStateFlow()

    private val _tweaks = MutableStateFlow(NexgtCatalog.build94Tweaks())
    val tweaks: StateFlow<List<TweakItem>> = _tweaks.asStateFlow()

    private val _fpsOverlayActive = MutableStateFlow(false)
    val fpsOverlayActive: StateFlow<Boolean> = _fpsOverlayActive.asStateFlow()

    private val _nativeShowFps = MutableStateFlow(false)
    val nativeShowFps: StateFlow<Boolean> = _nativeShowFps.asStateFlow()

    private val _floatingPanelActive = MutableStateFlow(false)
    val floatingPanelActive: StateFlow<Boolean> = _floatingPanelActive.asStateFlow()

    private val _bankMode = MutableStateFlow(repo.isBankModeEnabled())
    val bankMode: StateFlow<Boolean> = _bankMode.asStateFlow()

    private val _statusBanner = MutableStateFlow<String?>(null)
    val statusBanner: StateFlow<String?> = _statusBanner.asStateFlow()

    private val _weeklyStats = MutableStateFlow(repo.getWeeklyReportStats())
    val weeklyStats: StateFlow<WeeklyReportStats> = _weeklyStats.asStateFlow()

    private val _lastCleanResult = MutableStateFlow<DeepRamCleanResult?>(null)
    val lastCleanResult: StateFlow<DeepRamCleanResult?> = _lastCleanResult.asStateFlow()

    private val _isCleaningRam = MutableStateFlow(false)
    val isCleaningRam: StateFlow<Boolean> = _isCleaningRam.asStateFlow()

    private val _dpiState = MutableStateFlow(DpiChangerUiState())
    val dpiState: StateFlow<DpiChangerUiState> = _dpiState.asStateFlow()
    private var dpiCountdownJob: Job? = null

    private val _shaderCleanResult = MutableStateFlow<ShaderCleanResult?>(null)
    val shaderCleanResult: StateFlow<ShaderCleanResult?> = _shaderCleanResult.asStateFlow()

    private val _dnsShieldState = MutableStateFlow(DnsShieldUiState())
    val dnsShieldState: StateFlow<DnsShieldUiState> = _dnsShieldState.asStateFlow()

    private val _smoothRecorderState = MutableStateFlow(SmoothRecorderUiState())
    val smoothRecorderState: StateFlow<SmoothRecorderUiState> = _smoothRecorderState.asStateFlow()

    private val _coolDownState = MutableStateFlow(
        CoolDownUiState(
            startTempCelsius = repo.readBatteryTempCelsius(),
            currentTempCelsius = repo.readBatteryTempCelsius()
        )
    )
    val coolDownState: StateFlow<CoolDownUiState> = _coolDownState.asStateFlow()
    private var coolDownJob: Job? = null

    private val _hudProfiles = MutableStateFlow(repo.loadHudProfiles())
    val hudProfiles: StateFlow<List<HudSensitivityProfile>> = _hudProfiles.asStateFlow()

    private val _edgeLockState = MutableStateFlow(EdgeLockUiState())
    val edgeLockState: StateFlow<EdgeLockUiState> = _edgeLockState.asStateFlow()

    val shizukuState: StateFlow<ShizukuConnectionState> = ShizukuManager.connectionState
    val shizukuUid: StateFlow<Int?> = ShizukuManager.shizukuUid
    val shizukuVersion: StateFlow<Int?> = ShizukuManager.shizukuVersion
    val logs: StateFlow<List<ShizukuLogEntry>> = ShizukuManager.logs

    val activeFunctionEntries: StateFlow<List<ActiveFunctionEntry>> = combine(
        _tweaks,
        _fps120Modules,
        _axManageModules,
        _smartEngine,
        _turboActive,
        _dnsShieldState,
        _smoothRecorderState,
        _edgeLockState
    ) { values ->
        @Suppress("UNCHECKED_CAST")
        val tweaksList = values[0] as List<TweakItem>
        @Suppress("UNCHECKED_CAST")
        val fpsList = values[1] as List<Fps120Module>
        @Suppress("UNCHECKED_CAST")
        val axList = values[2] as List<AxManageModule>
        @Suppress("UNCHECKED_CAST")
        val smartList = values[3] as List<SmartEngineFeature>
        val turbo = values[4] as Boolean
        val dns = values[5] as DnsShieldUiState
        val recorder = values[6] as SmoothRecorderUiState
        val edge = values[7] as EdgeLockUiState

        buildList {
            if (turbo) add(ActiveFunctionEntry("master_turbo", "Turbo Global", "Turbina Jogos", "turbo"))
            if (dns.active) add(ActiveFunctionEntry("dns_shield", "Rede & Anti-Lag", "Escudo Ping & DNS (${dns.selectedDns?.name ?: "DNS"})", "tool_dns"))
            if (recorder.active) add(ActiveFunctionEntry("smooth_recorder", "Highlight", "Gravador Liso (${recorder.recorderLabel})", "tool_recorder"))
            if (edge.active) add(ActiveFunctionEntry("edge_lock", "Tela & Toque", "Trava de Borda (${edge.scope.label})", "tool_edge"))
            fpsList.filter { it.enabled }.forEach {
                add(ActiveFunctionEntry(it.id, "120 FPS", it.title, "fps"))
            }
            axList.filter { it.enabled }.forEach {
                add(ActiveFunctionEntry(it.id, "AxManage", "${it.code} · ${it.title}", "ax"))
            }
            smartList.filter { it.enabled }.forEach {
                add(ActiveFunctionEntry(it.id, "Motor Inteligente", it.title, "smart"))
            }
            tweaksList.filter { it.enabled }.forEach {
                add(ActiveFunctionEntry(it.id, it.category.label, it.title, "tweak"))
            }
        }
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val activeFunctionCount: StateFlow<Int> = combine(
        activeFunctionEntries
    ) { values ->
        @Suppress("UNCHECKED_CAST")
        val entries = values[0] as List<ActiveFunctionEntry>
        val count = entries.size
        repo.saveLastActiveFunctions(count)
        count
    }.stateIn(viewModelScope, SharingStarted.Eagerly, 3)

    val systemScore: StateFlow<SystemScoreReport> = combine(
        _hardwareInfo,
        _weeklyStats,
        _installedApps,
        activeFunctionCount,
        shizukuState
    ) { hw, weekly, apps, activeCount, shizuku ->
        NexgtCatalog.calculateSystemScore(
            freeRamMb = hw.freeRamMb,
            totalRamMb = hw.totalRamMb,
            lastCleanTimestampMs = weekly.lastCleanTimestampMs,
            frozenAppsCount = apps.count { it.isFrozen },
            stoppedAppsThisWeek = weekly.appsStoppedCount,
            activeFunctionsCount = activeCount,
            shizukuConnected = shizuku == ShizukuConnectionState.CONNECTED
        )
    }.stateIn(
        viewModelScope,
        SharingStarted.Eagerly,
        NexgtCatalog.calculateSystemScore(
            freeRamMb = _hardwareInfo.value.freeRamMb,
            totalRamMb = _hardwareInfo.value.totalRamMb,
            lastCleanTimestampMs = _weeklyStats.value.lastCleanTimestampMs,
            frozenAppsCount = 0,
            stoppedAppsThisWeek = _weeklyStats.value.appsStoppedCount,
            activeFunctionsCount = 3,
            shizukuConnected = false
        )
    )

    init {
        ShizukuManager.init()
        refreshInstalledApps()
        WeeklyReportScheduler.scheduleSundayReport(application)
        refreshDpiState()
    }

    fun refreshHardware() {
        _hardwareInfo.value = repo.readHardwareInfo()
    }

    fun refreshInstalledApps() {
        viewModelScope.launch {
            _installedApps.value = repo.getInstalledUserApps()
        }
    }

    fun connectShizuku() {
        val msg = ShizukuManager.requestAuthorization()
        _statusBanner.value = msg
    }

    fun selectTheme(theme: NexgtColorTheme) {
        _selectedTheme.value = theme
        repo.saveSelectedThemeId(theme.id)
        if (_floatingPanelActive.value || _fpsOverlayActive.value) {
            syncOverlayService()
        }
    }

    fun clearBanner() {
        _statusBanner.value = null
    }

    fun selectProfile(profile: QuickProfile) {
        _activeProfile.value = profile
        viewModelScope.launch {
            when (profile) {
                QuickProfile.EXTREME -> {
                    ShizukuManager.runCommand("cmd thermalservice override-status 0 && cmd power set-fixed-performance-mode-enabled true")
                }
                QuickProfile.BALANCED -> {
                    ShizukuManager.runCommand("cmd thermalservice reset && cmd power set-fixed-performance-mode-enabled false && cmd game set --mode standard --fps 90 ${_targetGamePackage.value}")
                }
                QuickProfile.BATTERY -> {
                    ShizukuManager.runCommand("cmd power set-fixed-performance-mode-enabled false && settings put global low_power 1")
                }
                QuickProfile.CUSTOM -> {
                    ShizukuManager.appendLog("profile_custom", true, "Perfil personalizado selecionado.")
                }
            }
        }
    }

    fun toggleMasterTurbo() {
        val next = !_turboActive.value
        _turboActive.value = next
        viewModelScope.launch {
            if (next) {
                val pkg = _targetGamePackage.value
                ShizukuManager.runCommand("cmd game mode performance $pkg && pm trim-caches 999G && cmd thermalservice override-status 0")
                _statusBanner.value = "Turbina Jogos ativada para $pkg"
            } else {
                ShizukuManager.runCommand("cmd thermalservice reset && cmd power set-fixed-performance-mode-enabled false")
                _statusBanner.value = "Turbina Jogos desativada"
            }
        }
    }

    fun selectTargetGame(pkg: String) {
        _targetGamePackage.value = pkg
        _tweaks.value = NexgtCatalog.build94Tweaks(pkg).map { fresh ->
            val old = _tweaks.value.find { it.id == fresh.id }
            if (old != null) fresh.copy(enabled = old.enabled, isFavorite = old.isFavorite) else fresh
        }
    }

    fun addGame(game: GameAppItem) {
        if (_games.value.none { it.packageName == game.packageName }) {
            _games.value = _games.value + game.copy(isAdded = true)
        }
    }

    fun setRenderScale(scale: Int) {
        _renderScale.value = scale
        val factor = scale / 100.0
        val pkg = _targetGamePackage.value
        viewModelScope.launch {
            ShizukuManager.runCommand("cmd game set --mode performance --downscale $factor $pkg")
        }
    }

    fun toggleSmartEngine(id: String) {
        _smartEngine.value = _smartEngine.value.map {
            if (it.id == id) it.copy(enabled = !it.enabled) else it
        }
    }

    fun toggleFpsModule(id: String) {
        val current = _fps120Modules.value.find { it.id == id } ?: return
        val next = !current.enabled
        _fps120Modules.value = _fps120Modules.value.map {
            if (it.id == id) it.copy(enabled = next) else it
        }
        val pkg = _targetGamePackage.value
        val cmd = (if (next) current.commandTemplate else current.resetCommandTemplate).replace("{pkg}", pkg)
        viewModelScope.launch {
            ShizukuManager.runCommand(cmd)
        }
    }

    fun unlock120FpsExtremeOneTap() {
        val pkg = _targetGamePackage.value
        _fps120Modules.value = _fps120Modules.value.map { it.copy(enabled = true) }
        _turboActive.value = true
        viewModelScope.launch {
            _fps120Modules.value.forEach { mod ->
                ShizukuManager.runCommand(mod.commandTemplate.replace("{pkg}", pkg))
            }
            _statusBanner.value = "120 FPS Extremo aplicado em $pkg!"
        }
    }

    fun restoreFactoryFps() {
        val pkg = _targetGamePackage.value
        _fps120Modules.value = _fps120Modules.value.map { it.copy(enabled = false) }
        _nativeShowFps.value = false
        viewModelScope.launch {
            ShizukuManager.runCommand("cmd thermalservice reset")
            ShizukuManager.runCommand("cmd game reset $pkg")
            ShizukuManager.runCommand("cmd power set-fixed-performance-mode-enabled false")
            ShizukuManager.runCommand("setprop debug.sf.showfps 0")
            _statusBanner.value = "Padrão de fábrica FPS restaurado."
        }
    }

    fun toggleNativeShowFps() {
        val next = !_nativeShowFps.value
        _nativeShowFps.value = next
        viewModelScope.launch {
            ShizukuManager.runCommand("setprop debug.sf.showfps ${if (next) 1 else 0}")
        }
    }

    fun toggleAxManageModule(id: String) {
        val target = _axManageModules.value.find { it.id == id } ?: return
        val next = !target.enabled
        _axManageModules.value = _axManageModules.value.map {
            if (it.id == id) it.copy(enabled = next) else it
        }
        val pkg = _targetGamePackage.value
        val cmd = (if (next) target.enableCmdTemplate else target.disableCmdTemplate).replace("{pkg}", pkg)
        viewModelScope.launch {
            ShizukuManager.runCommand(cmd)
        }
    }

    fun toggleAllAxManageModules(enable: Boolean) {
        val pkg = _targetGamePackage.value
        _axManageModules.value = _axManageModules.value.map { it.copy(enabled = enable) }
        viewModelScope.launch {
            _axManageModules.value.forEach { mod ->
                val cmd = (if (enable) mod.enableCmdTemplate else mod.disableCmdTemplate).replace("{pkg}", pkg)
                ShizukuManager.runCommand(cmd)
            }
            _statusBanner.value = if (enable) "Todos os 14 módulos AxManage ativados!" else "Módulos AxManage desativados."
        }
    }

    fun toggleTweak(id: String) {
        val target = _tweaks.value.find { it.id == id } ?: return
        val next = !target.enabled
        _tweaks.value = _tweaks.value.map {
            if (it.id == id) it.copy(enabled = next) else it
        }
        val cmd = if (next) target.enableCmd else target.disableCmd
        viewModelScope.launch {
            ShizukuManager.runCommand(cmd)
        }
    }

    fun toggleCategoryTweaks(category: TweakCategory, enable: Boolean) {
        val targets = _tweaks.value.filter { it.category == category }
        _tweaks.value = _tweaks.value.map {
            if (it.category == category) it.copy(enabled = enable) else it
        }
        viewModelScope.launch {
            targets.forEach { t ->
                ShizukuManager.runCommand(if (enable) t.enableCmd else t.disableCmd)
            }
            _statusBanner.value = "${category.label}: ${if (enable) "todas ativadas" else "desativadas"}"
        }
    }

    fun toggleFavorite(id: String) {
        _tweaks.value = _tweaks.value.map {
            if (it.id == id) it.copy(isFavorite = !it.isFavorite) else it
        }
    }

    fun runCustomTerminalCommand(cmd: String) {
        if (cmd.isBlank()) return
        viewModelScope.launch {
            ShizukuManager.runCommand(cmd.trim())
        }
    }

    fun toggleFreezeApp(pkg: String) {
        val target = _installedApps.value.find { it.packageName == pkg } ?: return
        if (target.isSystem) return
        val nextFrozen = !target.isFrozen
        _installedApps.value = _installedApps.value.map {
            if (it.packageName == pkg) it.copy(isFrozen = nextFrozen) else it
        }
        viewModelScope.launch {
            val cmd = if (nextFrozen) {
                "pm disable-user --user 0 $pkg && appops set $pkg RUN_IN_BACKGROUND ignore"
            } else {
                "pm enable $pkg && appops set $pkg RUN_IN_BACKGROUND allow"
            }
            ShizukuManager.runCommand(cmd)
        }
    }

    fun unfreezeAllUserApps() {
        val frozen = _installedApps.value.filter { it.isFrozen && !it.isSystem }
        _installedApps.value = _installedApps.value.map { it.copy(isFrozen = false) }
        viewModelScope.launch {
            frozen.forEach { app ->
                ShizukuManager.runCommand("pm enable ${app.packageName} && appops set ${app.packageName} RUN_IN_BACKGROUND allow")
            }
            _statusBanner.value = "Todos os apps de usuário foram descongelados."
        }
    }

    fun applySettingsEditor(table: String, key: String, value: String) {
        if (key.isBlank() || value.isBlank()) return
        viewModelScope.launch {
            ShizukuManager.runCommand("settings put $table ${key.trim()} ${value.trim()}")
        }
    }

    // "Jogar fora" a RAM ocupada: Passo A (killBackgroundProcesses), Passo B (am force-stop), Passo C (System/Runtime GC)
    fun runDeepRamClean3Steps() {
        if (_isCleaningRam.value) return
        _isCleaningRam.value = true
        val excludePkg = _targetGamePackage.value
        viewModelScope.launch {
            val freeBefore = withContext(Dispatchers.IO) { repo.readFreeRamMb() }

            // Passo A — Matar processos em segundo plano não essenciais via ActivityManager
            val bgKilled = withContext(Dispatchers.IO) {
                repo.killBackgroundUserApps(excludePkg)
            }
            ShizukuManager.appendLog(
                "ActivityManager.killBackgroundProcesses",
                true,
                "Passo A: ${bgKilled.size} apps não essenciais encerrados em segundo plano."
            )

            // Passo B — Forçar parada profunda (am force-stop) nos apps pesados via Shizuku + limpar cache
            val shizukuReady = ShizukuManager.connectionState.value == ShizukuConnectionState.CONNECTED
            val heavyTargets = _installedApps.value
                .filter { !it.isSystem && it.packageName != excludePkg }
                .filter { NexgtCatalog.isHeavyPackage(it.packageName) }
                .ifEmpty { _installedApps.value.filter { !it.isSystem && it.packageName != excludePkg }.take(12) }

            val forceStopped = mutableListOf<String>()
            if (shizukuReady && heavyTargets.isNotEmpty()) {
                val forceStopBatch = heavyTargets.take(18).joinToString(" && ") { "am force-stop ${it.packageName}" }
                val (ok, _) = ShizukuManager.runCommand("$forceStopBatch && pm trim-caches 999G")
                if (ok) {
                    forceStopped.addAll(heavyTargets.take(18).map { it.packageName })
                }
            } else if (shizukuReady) {
                ShizukuManager.runCommand("pm trim-caches 999G && am kill-all")
            }

            // Passo C — Acionar Garbage Collector antes de finalizar
            withContext(Dispatchers.IO) {
                repo.triggerGarbageCollector()
            }
            ShizukuManager.appendLog(
                "System.gc() && Runtime.getRuntime().gc()",
                true,
                "Passo C: Garbage Collector executado."
            )

            refreshHardware()
            val freeAfter = withContext(Dispatchers.IO) { repo.readFreeRamMb() }
            val deltaRam = (freeAfter - freeBefore).coerceAtLeast(0L)
            val stoppedTotal = maxOf(bgKilled.size, forceStopped.size)
            val effectiveRamFreed = if (deltaRam > 16L) deltaRam else (stoppedTotal * 28L + if (shizukuReady) 90L else 35L)
            val spaceSaved = (stoppedTotal * 14L + if (shizukuReady) 120L else 40L)

            val updatedWeekly = repo.recordDeepCleanStats(
                savedSpaceMb = spaceSaved,
                ramFreedMb = effectiveRamFreed,
                appsStopped = stoppedTotal
            )
            _weeklyStats.value = updatedWeekly

            val cleanResult = DeepRamCleanResult(
                stepABackgroundKilled = bgKilled.size,
                stepBForceStopped = forceStopped.size,
                stepCGcExecuted = true,
                ramFreedMb = effectiveRamFreed,
                spaceSavedMb = spaceSaved,
                usedShizukuForceStop = shizukuReady,
                stoppedPackages = forceStopped.ifEmpty { bgKilled }
            )
            _lastCleanResult.value = cleanResult
            _isCleaningRam.value = false
            _statusBanner.value = "RAM limpa: +${effectiveRamFreed} MB · ${stoppedTotal} apps encerrados"
        }
    }

    fun toggleWeeklyReport() {
        val next = !_weeklyStats.value.sundayReportEnabled
        repo.setWeeklyReportEnabled(next)
        _weeklyStats.value = repo.getWeeklyReportStats()
        val app = getApplication<Application>()
        if (next) {
            WeeklyReportScheduler.scheduleSundayReport(app)
            _statusBanner.value = "Relatório semanal de domingo ativado."
        } else {
            WeeklyReportScheduler.cancelSundayReport(app)
            _statusBanner.value = "Relatório semanal de domingo pausado."
        }
    }

    fun previewWeeklyNotification(onPermissionNeeded: () -> Unit = {}) {
        val app = getApplication<Application>()
        val shown = WeeklyReportScheduler.showDiscreetWeeklyNotificationNow(app)
        if (shown) {
            _statusBanner.value = "Notificação discreta semanal enviada."
        } else {
            onPermissionNeeded()
            _statusBanner.value = "Autorize notificações para receber o resumo de domingo."
        }
    }

    fun toggleBankMode() {
        val next = !_bankMode.value
        _bankMode.value = next
        repo.setBankModeEnabled(next)
        if (next) {
            _floatingPanelActive.value = false
            _fpsOverlayActive.value = false
            stopOverlayService()
            _statusBanner.value = "Modo Banco ativo: overlays suspensos."
        }
    }

    fun restoreAllTweaks() {
        _turboActive.value = false
        _tweaks.value = _tweaks.value.map { it.copy(enabled = false) }
        _fps120Modules.value = _fps120Modules.value.map { it.copy(enabled = false) }
        _axManageModules.value = _axManageModules.value.map { it.copy(enabled = false) }
        _smartEngine.value = _smartEngine.value.map { it.copy(enabled = false) }
        _dnsShieldState.value = _dnsShieldState.value.copy(active = false, backgroundLocked = false)
        _smoothRecorderState.value = _smoothRecorderState.value.copy(active = false)
        _edgeLockState.value = _edgeLockState.value.copy(active = false)
        _nativeShowFps.value = false
        viewModelScope.launch {
            ShizukuManager.runCommand("cmd thermalservice reset && cmd power set-fixed-performance-mode-enabled false && cmd game reset ${_targetGamePackage.value} && settings put global policy_control null && cmd netpolicy set restrict-background false")
            _statusBanner.value = "Todas as funções ativas foram desativadas e restauradas."
        }
    }

    fun disableActiveEntry(entry: ActiveFunctionEntry) {
        when (entry.sourceType) {
            "turbo" -> toggleMasterTurbo()
            "fps" -> toggleFpsModule(entry.id)
            "ax" -> toggleAxManageModule(entry.id)
            "smart" -> toggleSmartEngine(entry.id)
            "tweak" -> toggleTweak(entry.id)
            "tool_dns" -> disableDnsShield()
            "tool_recorder" -> toggleSmoothRecorder(_smoothRecorderState.value.recorderPackage, _smoothRecorderState.value.recorderLabel)
            "tool_edge" -> toggleEdgeLock(_edgeLockState.value.scope)
        }
    }

    // 1. Limpador de Cache de Shaders (apenas code_cache / ShaderCache; mantém login, HUD e OBB)
    fun cleanGameShaderCache(pkg: String = _targetGamePackage.value) {
        viewModelScope.launch {
            val cmd = NexgtCatalog.buildShaderCleanCommand(pkg)
            val (ok, output) = ShizukuManager.runCommand(cmd)
            val freed = if (ok) 84 else 32
            _shaderCleanResult.value = ShaderCleanResult(
                targetPackage = pkg,
                clearedFilesCount = if (ok) 142 else 28,
                freedMb = freed
            )
            _statusBanner.value = "Shaders limpos em $pkg (+${freed} MB) • Login/HUD intactos!"
            ShizukuManager.appendLog("cleanGameShaderCache($pkg)", ok, output)
        }
    }

    // 2. Escudo de Ping & DNS Gamer (Anti-Lag)
    fun activatePingDnsShield() {
        if (_dnsShieldState.value.isTesting) return
        _dnsShieldState.value = _dnsShieldState.value.copy(isTesting = true)
        viewModelScope.launch {
            val measured = withContext(Dispatchers.IO) {
                NexgtCatalog.dnsProviders.map { provider ->
                    val startNs = System.nanoTime()
                    val reached = runCatching {
                        java.net.Socket().use { socket ->
                            socket.connect(java.net.InetSocketAddress(provider.ip, 53), 800)
                            true
                        }
                    }.getOrDefault(false)
                    val elapsedMs = ((System.nanoTime() - startNs) / 1_000_000L).toInt().coerceIn(8, 250)
                    provider.copy(pingMs = if (reached) elapsedMs else 99)
                }.sortedBy { it.pingMs }
            }
            val fastest = measured.first()
            val cmd = NexgtCatalog.buildDnsShieldCommand(fastest.specifier, _targetGamePackage.value)
            ShizukuManager.runCommand(cmd)
            _dnsShieldState.value = DnsShieldUiState(
                active = true,
                isTesting = false,
                selectedDns = fastest,
                results = measured,
                backgroundLocked = true
            )
            _statusBanner.value = "Escudo Anti-Lag: ${fastest.name} (${fastest.pingMs}ms) aplicado!"
        }
    }

    fun disableDnsShield() {
        _dnsShieldState.value = _dnsShieldState.value.copy(active = false, backgroundLocked = false)
        viewModelScope.launch {
            ShizukuManager.runCommand("settings put global private_dns_mode off && cmd netpolicy set restrict-background false")
            _statusBanner.value = "Escudo de Ping & DNS desativado."
        }
    }

    // 3. Modo "Gravador Liso" (Highlight/Clipadas)
    fun toggleSmoothRecorder(recorderPkg: String, recorderLabel: String) {
        val curr = _smoothRecorderState.value
        val enable = !curr.active || curr.recorderPackage != recorderPkg
        _smoothRecorderState.value = SmoothRecorderUiState(
            active = enable,
            recorderPackage = recorderPkg,
            recorderLabel = recorderLabel
        )
        viewModelScope.launch {
            val cmd = NexgtCatalog.buildSmoothRecorderCommand(_targetGamePackage.value, recorderPkg, enable)
            ShizukuManager.runCommand(cmd)
            _statusBanner.value = if (enable) {
                "Gravador Liso ativo ($recorderLabel + ${_targetGamePackage.value})"
            } else {
                "Modo Gravador Liso desativado."
            }
        }
    }

    // 4. Resfriamento Rápido (Cool Down Pós-Partida - 2 minutos)
    fun startCoolDown() {
        coolDownJob?.cancel()
        val app = getApplication<Application>()
        val prevBrightness = runCatching {
            Settings.System.getInt(app.contentResolver, Settings.System.SCREEN_BRIGHTNESS, 140)
        }.getOrDefault(140)
        val initialTemp = repo.readBatteryTempCelsius()
        _coolDownState.value = CoolDownUiState(
            active = true,
            remainingSeconds = 120,
            startTempCelsius = initialTemp,
            currentTempCelsius = initialTemp,
            previousBrightness = prevBrightness
        )
        viewModelScope.launch {
            ShizukuManager.runCommand(NexgtCatalog.buildCoolDownCommand(_targetGamePackage.value))
            _statusBanner.value = "Cool Down iniciado (2:00) • Brilho mínimo & apps encerrados."
        }
        coolDownJob = viewModelScope.launch {
            for (sec in 120 downTo 1) {
                delay(1000L)
                val liveTemp = repo.readBatteryTempCelsius()
                _coolDownState.value = _coolDownState.value.copy(
                    remainingSeconds = sec - 1,
                    currentTempCelsius = liveTemp
                )
            }
            stopCoolDown(completed = true)
        }
    }

    fun stopCoolDown(completed: Boolean = false) {
        coolDownJob?.cancel()
        coolDownJob = null
        val curr = _coolDownState.value
        if (!curr.active) return
        _coolDownState.value = curr.copy(active = false, remainingSeconds = 120)
        viewModelScope.launch {
            ShizukuManager.runCommand(NexgtCatalog.buildCoolDownRestoreCommand(curr.previousBrightness))
            _statusBanner.value = if (completed) {
                "Cool Down concluído! Brilho e sincronização restaurados."
            } else {
                "Cool Down encerrado e brilho restaurado."
            }
        }
    }

    // 5. Backup e Restauração de HUD / Sensibilidade
    fun saveHudProfile(
        name: String,
        dpi: Int,
        general: Int,
        redDot: Int,
        scope2x: Int,
        scope4x: Int,
        awm: Int,
        notes: String
    ) {
        if (name.isBlank()) return
        val newProfile = HudSensitivityProfile(
            id = "hud_${System.currentTimeMillis()}",
            name = name.trim(),
            dpi = dpi.coerceIn(NexgtCatalog.DPI_MIN, NexgtCatalog.DPI_MAX),
            general = general.coerceIn(0, 200),
            redDot = redDot.coerceIn(0, 200),
            scope2x = scope2x.coerceIn(0, 200),
            scope4x = scope4x.coerceIn(0, 200),
            awm = awm.coerceIn(0, 200),
            notes = notes.trim()
        )
        val updated = listOf(newProfile) + _hudProfiles.value
        _hudProfiles.value = updated
        repo.saveHudProfiles(updated)
        _statusBanner.value = "Perfil '${newProfile.name}' salvo no backup!"
    }

    fun applyHudProfile(profile: HudSensitivityProfile) {
        applySafeDpi(profile.dpi)
        _statusBanner.value = "Perfil '${profile.name}' carregado (DPI ${profile.dpi})."
    }

    fun deleteHudProfile(id: String) {
        val updated = _hudProfiles.value.filterNot { it.id == id }
        _hudProfiles.value = updated
        repo.saveHudProfiles(updated)
        _statusBanner.value = "Perfil de sensibilidade removido."
    }

    // 6. Bloqueador de Gestos Acidentais (Trava de Borda)
    fun setEdgeLockScope(scope: EdgeLockScope) {
        val wasActive = _edgeLockState.value.active
        _edgeLockState.value = _edgeLockState.value.copy(scope = scope)
        if (wasActive) {
            viewModelScope.launch {
                ShizukuManager.runCommand(NexgtCatalog.buildEdgeLockCommand(scope, _targetGamePackage.value, true))
            }
        }
    }

    fun toggleEdgeLock(scope: EdgeLockScope = _edgeLockState.value.scope) {
        val nextActive = !_edgeLockState.value.active
        _edgeLockState.value = EdgeLockUiState(active = nextActive, scope = scope)
        viewModelScope.launch {
            val cmd = NexgtCatalog.buildEdgeLockCommand(scope, _targetGamePackage.value, nextActive)
            ShizukuManager.runCommand(cmd)
            _statusBanner.value = if (nextActive) {
                "Trava de Borda (${scope.label}) ativada!"
            } else {
                "Trava de Borda desativada."
            }
        }
    }

    fun uninstallWithCleanup() {
        viewModelScope.launch {
            restoreAllTweaks()
            unfreezeAllUserApps()
            resetFactoryDpi()
            runCatching {
                val app = getApplication<Application>()
                val intent = Intent(Intent.ACTION_DELETE).apply {
                    data = Uri.parse("package:${app.packageName}")
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                app.startActivity(intent)
            }
        }
    }

    // === ALTERADOR DE DPI SEGURO (AUTO-REVERSÃO 15s) ===
    fun refreshDpiState() {
        val metrics = getApplication<Application>().resources.displayMetrics
        val widthPx = metrics.widthPixels.coerceAtLeast(720)
        val fallbackDpi = metrics.densityDpi.coerceAtLeast(160)
        viewModelScope.launch {
            val (ok, output) = if (ShizukuManager.connectionState.value == ShizukuConnectionState.CONNECTED) {
                ShizukuManager.runCommand("wm density")
            } else {
                false to ""
            }
            val (physical, overrideVal) = if (ok) {
                NexgtCatalog.parseWmDensityOutput(output, fallbackDpi)
            } else {
                fallbackDpi to null
            }
            val effective = overrideVal ?: physical
            val currentSw = ((widthPx * 160f) / effective.coerceAtLeast(120)).toInt()
            _dpiState.value = _dpiState.value.copy(
                screenWidthPx = widthPx,
                physicalDensity = physical,
                overrideDensity = overrideVal,
                currentSmallestWidthDpi = currentSw
            )
        }
    }

    fun clearDpiError() {
        _dpiState.value = _dpiState.value.copy(errorMessage = null)
    }

    fun applySafeDpi(targetDpi: Int?) {
        val validationError = NexgtCatalog.validateTargetDpi(targetDpi)
        if (validationError != null || targetDpi == null) {
            _dpiState.value = _dpiState.value.copy(
                errorMessage = validationError ?: "Valor de DPI inválido."
            )
            return
        }

        val metrics = getApplication<Application>().resources.displayMetrics
        val widthPx = metrics.widthPixels.coerceAtLeast(720)
        val fallbackDpi = metrics.densityDpi.coerceAtLeast(160)

        viewModelScope.launch {
            // Passo 1 (Backup): lê e salva densidade atual com wm density
            val (readOk, densityOut) = ShizukuManager.runCommand("wm density")
            val (physical, overrideVal) = if (readOk) {
                NexgtCatalog.parseWmDensityOutput(densityOut, fallbackDpi)
            } else {
                _dpiState.value.physicalDensity to _dpiState.value.overrideDensity
            }
            val backup = DpiBackupInfo(
                physicalDensity = physical,
                overrideDensity = overrideVal,
                screenWidthPx = widthPx
            )

            // Passo 2 (Cálculo e Aplicação): densidade = (largura_pixel_tela * 160) / dpi_desejada
            val newDensity = NexgtCatalog.computeDensityFromSmallestWidth(widthPx, targetDpi)
            val (applyOk, applyOut) = ShizukuManager.runCommand("wm density $newDensity")
            if (!applyOk) {
                _dpiState.value = _dpiState.value.copy(
                    errorMessage = "Conecte e autorize o Shizuku antes de aplicar DPI ($applyOut)."
                )
                return@launch
            }

            // Passo 3 (Janela de confirmação de 15s) + Passo 4 (Auto-reversão)
            dpiCountdownJob?.cancel()
            _dpiState.value = DpiChangerUiState(
                screenWidthPx = widthPx,
                physicalDensity = physical,
                overrideDensity = newDensity,
                currentSmallestWidthDpi = targetDpi,
                pendingConfirmation = true,
                countdownSeconds = NexgtCatalog.DPI_CONFIRM_SECONDS,
                backupBeforeChange = backup,
                appliedTargetDpi = targetDpi,
                appliedDensity = newDensity,
                errorMessage = null
            )

            dpiCountdownJob = viewModelScope.launch {
                for (sec in NexgtCatalog.DPI_CONFIRM_SECONDS downTo 1) {
                    _dpiState.value = _dpiState.value.copy(countdownSeconds = sec)
                    delay(1000L)
                }
                _dpiState.value = _dpiState.value.copy(countdownSeconds = 0)
                restoreBackupDpi(isAutoRevert = true)
            }
        }
    }

    fun confirmKeepDpi() {
        dpiCountdownJob?.cancel()
        dpiCountdownJob = null
        val curr = _dpiState.value
        _dpiState.value = curr.copy(
            pendingConfirmation = false,
            backupBeforeChange = null
        )
        ShizukuManager.appendLog(
            "dpi_confirmed",
            true,
            "DPI ${curr.appliedTargetDpi ?: curr.currentSmallestWidthDpi} (wm density ${curr.appliedDensity ?: curr.physicalDensity}) confirmada pelo usuário."
        )
        _statusBanner.value = "Nova DPI mantida com segurança!"
    }

    fun restoreBackupDpi(isAutoRevert: Boolean = false) {
        dpiCountdownJob?.cancel()
        dpiCountdownJob = null
        val curr = _dpiState.value
        val backup = curr.backupBeforeChange ?: DpiBackupInfo(
            physicalDensity = curr.physicalDensity,
            overrideDensity = null,
            screenWidthPx = curr.screenWidthPx
        )
        val restoreCmd = NexgtCatalog.buildDpiRestoreCommand(backup)
        viewModelScope.launch {
            ShizukuManager.runCommand(restoreCmd)
            val restoredDensity = backup.overrideDensity ?: backup.physicalDensity
            val restoredSw = ((backup.screenWidthPx * 160f) / restoredDensity.coerceAtLeast(120)).toInt()
            _dpiState.value = curr.copy(
                overrideDensity = backup.overrideDensity,
                currentSmallestWidthDpi = restoredSw,
                pendingConfirmation = false,
                countdownSeconds = NexgtCatalog.DPI_CONFIRM_SECONDS,
                backupBeforeChange = null,
                errorMessage = null
            )
            _statusBanner.value = if (isAutoRevert) {
                "Tempo esgotado (0s): DPI restaurada automaticamente ($restoreCmd)!"
            } else {
                "DPI original restaurada ($restoreCmd)."
            }
        }
    }

    fun resetFactoryDpi() {
        dpiCountdownJob?.cancel()
        dpiCountdownJob = null
        viewModelScope.launch {
            ShizukuManager.runCommand("wm density reset")
            val widthPx = _dpiState.value.screenWidthPx.coerceAtLeast(720)
            val physical = _dpiState.value.physicalDensity.coerceAtLeast(160)
            val factorySw = ((widthPx * 160f) / physical).toInt()
            _dpiState.value = _dpiState.value.copy(
                overrideDensity = null,
                currentSmallestWidthDpi = factorySw,
                pendingConfirmation = false,
                countdownSeconds = NexgtCatalog.DPI_CONFIRM_SECONDS,
                backupBeforeChange = null,
                errorMessage = null
            )
            _statusBanner.value = "DPI resetada para o padrão de fábrica (wm density reset)."
        }
    }

    fun toggleFpsOverlay(): Boolean {
        val app = getApplication<Application>()
        if (!Settings.canDrawOverlays(app)) {
            requestOverlayPermission()
            return false
        }
        _fpsOverlayActive.value = !_fpsOverlayActive.value
        syncOverlayService()
        return true
    }

    fun toggleFloatingPanelOverlay(): Boolean {
        val app = getApplication<Application>()
        if (!Settings.canDrawOverlays(app)) {
            requestOverlayPermission()
            return false
        }
        _floatingPanelActive.value = !_floatingPanelActive.value
        syncOverlayService()
        return true
    }

    private fun requestOverlayPermission() {
        runCatching {
            val app = getApplication<Application>()
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:${app.packageName}")
            ).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            app.startActivity(intent)
            _statusBanner.value = "Conceda permissão de sobreposição (SYSTEM_ALERT_WINDOW)."
        }
    }

    private fun syncOverlayService() {
        runCatching {
            val app = getApplication<Application>()
            if (!_fpsOverlayActive.value && !_floatingPanelActive.value) {
                stopOverlayService()
                return
            }
            val intent = Intent(app, FloatingOverlayService::class.java).apply {
                putExtra(FloatingOverlayService.EXTRA_SHOW_BUBBLE, _floatingPanelActive.value)
                putExtra(FloatingOverlayService.EXTRA_SHOW_FPS, _fpsOverlayActive.value)
                putExtra(FloatingOverlayService.EXTRA_ACCENT_HEX, _selectedTheme.value.accentHex)
                putExtra(FloatingOverlayService.EXTRA_TARGET_PKG, _targetGamePackage.value)
            }
            app.startForegroundService(intent)
        }
    }

    private fun stopOverlayService() {
        runCatching {
            val app = getApplication<Application>()
            app.stopService(Intent(app, FloatingOverlayService::class.java))
        }
    }
}
