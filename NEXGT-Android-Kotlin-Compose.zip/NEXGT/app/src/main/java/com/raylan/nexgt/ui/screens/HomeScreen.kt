package com.raylan.nexgt.ui.screens

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.NotificationsNone
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.raylan.nexgt.data.DeepRamCleanResult
import com.raylan.nexgt.data.HardwareInfo
import com.raylan.nexgt.data.NavTab
import com.raylan.nexgt.data.QuickProfile
import com.raylan.nexgt.data.SystemScoreReport
import com.raylan.nexgt.data.TweakItem
import com.raylan.nexgt.data.WeeklyReportStats
import com.raylan.nexgt.reports.WeeklyReportScheduler
import com.raylan.nexgt.shizuku.ShizukuConnectionState
import com.raylan.nexgt.ui.components.GojoFloatingBannerCanvas
import com.raylan.nexgt.ui.components.NexgtCard
import com.raylan.nexgt.ui.components.NexgtSwitch
import com.raylan.nexgt.ui.theme.LocalNexgtPalette
import kotlinx.coroutines.delay

@Composable
fun HomeScreen(
    shizukuState: ShizukuConnectionState,
    activeCount: Int,
    hardware: HardwareInfo,
    activeProfile: QuickProfile,
    favorites: List<TweakItem>,
    systemScore: SystemScoreReport,
    weeklyStats: WeeklyReportStats,
    lastCleanResult: DeepRamCleanResult?,
    isCleaningRam: Boolean,
    onConnectShizuku: () -> Unit,
    onSelectProfile: (QuickProfile) -> Unit,
    onToggleTweak: (String) -> Unit,
    onRunDeepRamClean: () -> Unit,
    onOpenActiveFunctions: () -> Unit,
    onNavigateTab: (NavTab) -> Unit
) {
    val palette = LocalNexgtPalette.current
    var showFfBoostTitle by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        delay(850L)
        showFfBoostTitle = true
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(6.dp))
            // Banner Hero Satoru Gojo + Transição NEXGT -> FF Boost
            NexgtCard(highlighted = true) {
                Box(modifier = Modifier.fillMaxWidth()) {
                    GojoFloatingBannerCanvas(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(195.dp)
                    )
                    Column(
                        modifier = Modifier
                            .align(Alignment.CenterStart)
                            .fillMaxWidth(0.56f)
                            .padding(vertical = 8.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        AnimatedContent(
                            targetState = showFfBoostTitle,
                            transitionSpec = {
                                (fadeIn(tween(150)) + slideInVertically(tween(150)) { it / 3 }) togetherWith
                                    (fadeOut(tween(150)) + slideOutVertically(tween(150)) { -it / 3 })
                            },
                            label = "brand_transition"
                        ) { isBoost ->
                            Text(
                                text = if (isBoost) "FF Boost" else "NEXGT",
                                color = Color.White,
                                fontSize = 30.sp,
                                fontWeight = FontWeight.ExtraBold,
                                fontFamily = FontFamily.Default
                            )
                        }
                        Text(
                            text = "Motor de Alto Desempenho 120 FPS & Shell UID 2000",
                            color = palette.textSecondary,
                            fontSize = 12.sp,
                            fontFamily = FontFamily.Default
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Button(
                            onClick = onConnectShizuku,
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = palette.accent,
                                contentColor = Color.White
                            )
                        ) {
                            Text(
                                text = if (shizukuState == ShizukuConnectionState.CONNECTED) {
                                    "Shizuku Conectado"
                                } else {
                                    "Conectar / Autorizar Shizuku"
                                },
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // Pílulas de status real
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                val connected = shizukuState == ShizukuConnectionState.CONNECTED
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(CircleShape)
                        .background(
                            if (connected) palette.success.copy(alpha = 0.16f)
                            else palette.accentSoft
                        )
                        .border(
                            1.dp,
                            if (connected) palette.success else palette.accent,
                            CircleShape
                        )
                        .clickable { onConnectShizuku() }
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = if (connected) "SHIZUKU • CONECTADO" else "TOQUE P/ ATIVAR SHIZUKU",
                        color = if (connected) palette.success else palette.accent,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.ExtraBold,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Box(
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(palette.cardSurface)
                        .border(1.dp, palette.accentBorder, CircleShape)
                        .clickable { onOpenActiveFunctions() }
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "$activeCount FUNÇÕES ATIVAS",
                        color = palette.textPrimary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }

        // Pontuação de Saúde do Sistema (System Score 0–100) + Limpeza Real de RAM
        item {
            NexgtCard(highlighted = systemScore.score >= 72) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Saúde do Sistema (System Score)",
                            color = palette.textPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                        Text(
                            text = "Mantenha a RAM e apps organizados toda semana",
                            color = palette.textSecondary,
                            fontSize = 11.sp
                        )
                    }
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(14.dp))
                            .background(palette.accentSoft)
                            .border(1.5.dp, palette.accent, RoundedCornerShape(14.dp))
                            .padding(horizontal = 12.dp, vertical = 6.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = "${systemScore.score}/100",
                                color = Color.White,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.ExtraBold,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = systemScore.tierLabel.uppercase(),
                                color = palette.accent,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.ExtraBold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                LinearProgressIndicator(
                    progress = { (systemScore.score / 100f).coerceIn(0f, 1f) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .clip(CircleShape),
                    color = palette.accent,
                    trackColor = Color(0xFF1F1F2B)
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("RAM +${systemScore.ramPoints}", color = palette.textSecondary, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                    Text("Limpeza +${systemScore.cleanPoints}", color = palette.textSecondary, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                    Text("Org +${systemScore.organizationPoints}", color = palette.textSecondary, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                    Text("Boost +${systemScore.boostPoints}", color = palette.textSecondary, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                }

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Button(
                        onClick = onRunDeepRamClean,
                        enabled = !isCleaningRam,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = palette.accent,
                            contentColor = Color.White
                        )
                    ) {
                        Icon(Icons.Default.CleaningServices, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (isCleaningRam) "LIMPANDO RAM..." else "JOGAR FORA RAM (3 PASSOS)",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }
                    OutlinedButton(
                        onClick = { onNavigateTab(NavTab.TOOLS) },
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.NotificationsNone, contentDescription = null, tint = palette.accent, modifier = Modifier.size(16.dp))
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                val savedStr = WeeklyReportScheduler.formatMbOrGb(weeklyStats.savedSpaceMb)
                val ramStr = WeeklyReportScheduler.formatMbOrGb(weeklyStats.ramFreedMb)
                Text(
                    text = if (lastCleanResult != null) {
                        "Última limpeza: +${lastCleanResult.ramFreedMb} MB RAM • ${lastCleanResult.stepABackgroundKilled} bg / ${lastCleanResult.stepBForceStopped} force-stop • GC OK"
                    } else {
                        "Resumo Domingo: $savedStr economizados • $ramStr RAM liberada (${weeklyStats.cleanCount} limpezas)"
                    },
                    color = palette.accent,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
        }

        // Card de Hardware automático
        item {
            NexgtCard {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Memory,
                        contentDescription = null,
                        tint = palette.accent,
                        modifier = Modifier.size(18.dp)
                    )
                    Text(
                        text = "Hardware Detectado",
                        color = palette.textPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    HardwareSpecColumn("Aparelho", hardware.model, Modifier.weight(1f))
                    HardwareSpecColumn("GPU / SoC", hardware.socOrGpu, Modifier.weight(1f))
                }
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    HardwareSpecColumn("Tela Atual", "${hardware.refreshRateHz} Hz", Modifier.weight(1f))
                    HardwareSpecColumn("Android", "Android ${hardware.androidVersion}", Modifier.weight(1f))
                    HardwareSpecColumn(
                        "RAM Livre / Total",
                        "${hardware.freeRamMb} / ${hardware.totalRamMb} MB",
                        Modifier.weight(1.3f)
                    )
                }
            }
        }

        // Grade 2x2 de Perfis Rápidos
        item {
            Text(
                text = "Perfis Rápidos",
                color = palette.textPrimary,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(8.dp))
            val profiles = QuickProfile.entries
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                profiles.chunked(2).forEach { rowItems ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(IntrinsicSize.Max),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        rowItems.forEach { profile ->
                            val isSelected = activeProfile == profile
                            NexgtCard(
                                modifier = Modifier
                                    .weight(1f)
                                    .fillMaxHeight(),
                                highlighted = isSelected,
                                dimmed = !isSelected,
                                onClick = { onSelectProfile(profile) }
                            ) {
                                Text(
                                    text = profile.title,
                                    color = if (isSelected) palette.accent else palette.textPrimary,
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 13.sp
                                )
                                Text(
                                    text = profile.subtitle,
                                    color = palette.textSecondary,
                                    fontSize = 11.sp
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                ProfileMetricBar("FPS", profile.fpsScore, palette.accent)
                                ProfileMetricBar("Bateria", profile.batteryScore, Color(0xFF10B981))
                                ProfileMetricBar("Frescor", profile.coolnessScore, Color(0xFF06B6D4))
                            }
                        }
                    }
                }
            }
        }

        // Atalhos simétricos DNA Nexgt e Central Shizuku
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(IntrinsicSize.Max),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                NexgtCard(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight(),
                    onClick = { onNavigateTab(NavTab.FPS_120) }
                ) {
                    Icon(Icons.Default.Bolt, contentDescription = null, tint = palette.accent)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("DNA Nexgt", color = palette.textPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Text("Destravar 120 FPS", color = palette.textSecondary, fontSize = 11.sp)
                }
                NexgtCard(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight(),
                    onClick = { onNavigateTab(NavTab.TOOLS) }
                ) {
                    Icon(Icons.Default.Terminal, contentDescription = null, tint = palette.accent)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("Central Shizuku", color = palette.textPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Text("Terminal & Tools", color = palette.textSecondary, fontSize = 11.sp)
                }
            }
        }

        if (favorites.isNotEmpty()) {
            item {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(Icons.Default.Star, contentDescription = null, tint = palette.accent, modifier = Modifier.size(16.dp))
                    Text(
                        text = "Favoritos",
                        color = palette.textPrimary,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    favorites.take(4).forEach { tweak ->
                        NexgtCard(highlighted = tweak.enabled) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(tweak.title, color = palette.textPrimary, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                                    Text(tweak.summary, color = palette.textSecondary, fontSize = 11.sp)
                                }
                                NexgtSwitch(
                                    checked = tweak.enabled,
                                    onCheckedChange = { onToggleTweak(tweak.id) }
                                )
                            }
                        }
                    }
                }
            }
        }

        // Rodapé oficial obrigatório
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 14.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "NEXGT / FF Boost • Criado por Raylan",
                    color = palette.textSecondary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium,
                    fontFamily = FontFamily.Default
                )
            }
        }
    }
}

@Composable
private fun HardwareSpecColumn(
    label: String,
    value: String,
    modifier: Modifier = Modifier
) {
    val palette = LocalNexgtPalette.current
    Column(modifier = modifier) {
        Text(label, color = palette.textSecondary, fontSize = 10.sp)
        Text(
            text = value,
            color = palette.textPrimary,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            fontFamily = FontFamily.Monospace
        )
    }
}

@Composable
private fun ProfileMetricBar(
    label: String,
    progress: Float,
    color: Color
) {
    val palette = LocalNexgtPalette.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Text(
            text = label,
            color = palette.textSecondary,
            fontSize = 10.sp,
            modifier = Modifier.width(42.dp)
        )
        LinearProgressIndicator(
            progress = { progress },
            modifier = Modifier
                .weight(1f)
                .height(5.dp)
                .clip(CircleShape),
            color = color,
            trackColor = Color(0xFF22222E)
        )
    }
}
