package com.raylan.nexgt.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AcUnit
import androidx.compose.material.icons.filled.AspectRatio
import androidx.compose.material.icons.filled.AutoFixHigh
import androidx.compose.material.icons.filled.BookmarkAdd
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.NetworkCheck
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.ScreenLockPortrait
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material.icons.filled.Thermostat
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.raylan.nexgt.data.CoolDownUiState
import com.raylan.nexgt.data.DeepRamCleanResult
import com.raylan.nexgt.data.DnsShieldUiState
import com.raylan.nexgt.data.DpiChangerUiState
import com.raylan.nexgt.data.EdgeLockScope
import com.raylan.nexgt.data.EdgeLockUiState
import com.raylan.nexgt.data.FeatureRiskLevel
import com.raylan.nexgt.data.GameAppItem
import com.raylan.nexgt.data.HardwareHelpContent
import com.raylan.nexgt.data.HudSensitivityProfile
import com.raylan.nexgt.data.NexgtCatalog
import com.raylan.nexgt.data.ShaderCleanResult
import com.raylan.nexgt.data.SmoothRecorderUiState
import com.raylan.nexgt.data.SystemScoreReport
import com.raylan.nexgt.data.TweakItem
import com.raylan.nexgt.data.WeeklyReportStats
import com.raylan.nexgt.reports.WeeklyReportScheduler
import com.raylan.nexgt.shizuku.ShizukuConnectionState
import com.raylan.nexgt.shizuku.ShizukuLogEntry
import com.raylan.nexgt.ui.components.FeatureHelpButton
import com.raylan.nexgt.ui.components.FeatureHelpDialog
import com.raylan.nexgt.ui.components.NexgtCard
import com.raylan.nexgt.ui.components.NexgtSwitch
import com.raylan.nexgt.ui.components.RiskTagBadge
import com.raylan.nexgt.ui.theme.LocalNexgtPalette
import com.raylan.nexgt.ui.theme.NexgtColorTheme
import com.raylan.nexgt.ui.theme.NexgtThemes

@Composable
fun ToolsScreen(
    selectedTheme: NexgtColorTheme,
    targetPackage: String,
    shizukuState: ShizukuConnectionState,
    shizukuUid: Int?,
    shizukuVersion: Int?,
    floatingPanelActive: Boolean,
    bankMode: Boolean,
    activeTweaks: List<TweakItem>,
    installedApps: List<GameAppItem>,
    logs: List<ShizukuLogEntry>,
    systemScore: SystemScoreReport,
    weeklyStats: WeeklyReportStats,
    lastCleanResult: DeepRamCleanResult?,
    isCleaningRam: Boolean,
    dpiState: DpiChangerUiState,
    shaderCleanResult: ShaderCleanResult?,
    dnsShieldState: DnsShieldUiState,
    smoothRecorderState: SmoothRecorderUiState,
    coolDownState: CoolDownUiState,
    hudProfiles: List<HudSensitivityProfile>,
    edgeLockState: EdgeLockUiState,
    onSelectTheme: (NexgtColorTheme) -> Unit,
    onToggleFloatingPanel: () -> Unit,
    onConnectShizuku: () -> Unit,
    onRunTerminalCommand: (String) -> Unit,
    onToggleFreezeApp: (String) -> Unit,
    onUnfreezeAllApps: () -> Unit,
    onRunDeepRamClean: () -> Unit,
    onToggleWeeklyReport: () -> Unit,
    onPreviewWeeklyNotification: () -> Unit,
    onApplySafeDpi: (Int?) -> Unit,
    onConfirmKeepDpi: () -> Unit,
    onRestoreBackupDpi: () -> Unit,
    onResetFactoryDpi: () -> Unit,
    onClearDpiError: () -> Unit,
    onCleanShaders: () -> Unit,
    onActivateDnsShield: () -> Unit,
    onDisableDnsShield: () -> Unit,
    onToggleSmoothRecorder: (String, String) -> Unit,
    onStartCoolDown: () -> Unit,
    onStopCoolDown: () -> Unit,
    onSaveHudProfile: (String, Int, Int, Int, Int, Int, Int, String) -> Unit,
    onApplyHudProfile: (HudSensitivityProfile) -> Unit,
    onDeleteHudProfile: (String) -> Unit,
    onSetEdgeLockScope: (EdgeLockScope) -> Unit,
    onToggleEdgeLock: () -> Unit,
    onApplySetting: (String, String, String) -> Unit,
    onToggleBankMode: () -> Unit,
    onRestoreAll: () -> Unit,
    onUninstallWithCleanup: () -> Unit
) {
    val palette = LocalNexgtPalette.current

    var expandedSection by remember { mutableStateOf("gamer") }
    var activeHelp by remember { mutableStateOf<HardwareHelpContent?>(null) }

    var customDpiInput by remember { mutableStateOf("600") }
    var terminalCmd by remember { mutableStateOf("id && getprop ro.build.version.release") }
    var settingsTable by remember { mutableStateOf("system") }
    var settingKey by remember { mutableStateOf("peak_refresh_rate") }
    var settingValue by remember { mutableStateOf("120.0") }

    // Campos novo Backup HUD / Sensibilidade
    var hudName by remember { mutableStateOf("") }
    var hudGeneral by remember { mutableStateOf("98") }
    var hudRedDot by remember { mutableStateOf("95") }
    var hud2x by remember { mutableStateOf("90") }
    var hud4x by remember { mutableStateOf("86") }
    var hudAwm by remember { mutableStateOf("65") }
    var hudNotes by remember { mutableStateOf("") }

    // Congelador de Apps (somente apps de usuário)
    var appSearchQuery by remember { mutableStateOf("") }
    var freezerFilter by remember { mutableStateOf("Todos") }

    val filteredUserApps = remember(installedApps, appSearchQuery, freezerFilter) {
        installedApps
            .filter { !it.isSystem }
            .filter { app ->
                val matchesSearch = appSearchQuery.isBlank() ||
                    app.name.contains(appSearchQuery, ignoreCase = true) ||
                    app.packageName.contains(appSearchQuery, ignoreCase = true)
                val matchesFilter = when (freezerFilter) {
                    "Ativos" -> !app.isFrozen
                    "Congelados" -> app.isFrozen
                    else -> true
                }
                matchesSearch && matchesFilter
            }
    }

    var touchHz by remember { mutableIntStateOf(0) }
    var lastEventMs by remember { mutableLongStateOf(0L) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Overlay Principal
        item {
            Spacer(modifier = Modifier.height(6.dp))
            Button(
                onClick = onToggleFloatingPanel,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (floatingPanelActive) palette.success else palette.accent,
                    contentColor = Color.White
                )
            ) {
                Icon(Icons.Default.Layers, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (floatingPanelActive) {
                        "PAINEL FLUTUANTE ATIVO (TOQUE P/ DESATIVAR)"
                    } else {
                        "ATIVAR PAINEL FLUTUANTE (OVERLAY)"
                    },
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 12.sp
                )
            }
        }

        // === ACORDEÃO 1: TOQUE, DPI & BACKUP DE SENSIBILIDADE ===
        item {
            ToolsAccordionHeader(
                title = "Toque, DPI & Sensibilidade",
                subtitle = "DPI 15s, Backup de HUD/Sensi e Teste de Toque",
                expanded = expandedSection == "dpi",
                onClick = { expandedSection = if (expandedSection == "dpi") "" else "dpi" }
            )
            AnimatedVisibility(
                visible = expandedSection == "dpi",
                enter = fadeIn(tween(150)) + expandVertically(tween(150)),
                exit = fadeOut(tween(150)) + shrinkVertically(tween(150))
            ) {
                Column(modifier = Modifier.padding(top = 10.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    // Alterador de DPI Seguro (15s)
                    NexgtCard(highlighted = dpiState.overrideDensity != null) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                                RiskTagBadge(FeatureRiskLevel.SAFE)
                                Text(
                                    text = "${dpiState.currentSmallestWidthDpi} DPI",
                                    color = palette.accent,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                            FeatureHelpButton(onClick = { activeHelp = NexgtCatalog.getToolHelp("dpi_safe", targetPackage) })
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Default.AspectRatio, contentDescription = null, tint = palette.accent)
                            Column {
                                Text("Alterador de DPI Seguro (15s)", color = palette.textPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Text("Auto-reversão em 15s • Limite ${NexgtCatalog.DPI_MIN}–${NexgtCatalog.DPI_MAX}", color = palette.textSecondary, fontSize = 11.sp)
                            }
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Largura: ${dpiState.screenWidthPx}px • Física: ${dpiState.physicalDensity} • Override: ${dpiState.overrideDensity?.toString() ?: "Fábrica"}",
                            color = palette.textSecondary,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            NexgtCatalog.dpiPresets.chunked(2).forEach { rowPresets ->
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    rowPresets.forEach { preset ->
                                        OutlinedButton(
                                            onClick = {
                                                if (preset.targetDpi == null) {
                                                    onResetFactoryDpi()
                                                } else {
                                                    customDpiInput = preset.targetDpi.toString()
                                                    onApplySafeDpi(preset.targetDpi)
                                                }
                                            },
                                            modifier = Modifier.weight(1f),
                                            shape = RoundedCornerShape(10.dp)
                                        ) {
                                            Text(preset.label, color = palette.textPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OutlinedTextField(
                                value = customDpiInput,
                                onValueChange = {
                                    customDpiInput = it.filter { ch -> ch.isDigit() }
                                    onClearDpiError()
                                },
                                modifier = Modifier.weight(1f),
                                label = { Text("DPI (${NexgtCatalog.DPI_MIN}-${NexgtCatalog.DPI_MAX})") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true
                            )
                            Button(
                                onClick = { onApplySafeDpi(customDpiInput.toIntOrNull()) },
                                colors = ButtonDefaults.buttonColors(containerColor = palette.accent),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Text("Aplicar", fontWeight = FontWeight.ExtraBold, fontSize = 12.sp)
                            }
                        }
                        if (dpiState.errorMessage != null) {
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(text = dpiState.errorMessage, color = palette.danger, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedButton(onClick = onResetFactoryDpi, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)) {
                            Icon(Icons.Default.Restore, contentDescription = null, tint = palette.accent, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Resetar para Fábrica (wm density reset)", color = palette.textPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    // Backup e Restauração de HUD / Sensibilidade
                    NexgtCard {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RiskTagBadge(FeatureRiskLevel.SAFE)
                            FeatureHelpButton(onClick = { activeHelp = NexgtCatalog.getToolHelp("hud_backup", targetPackage) })
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Default.BookmarkAdd, contentDescription = null, tint = palette.accent)
                            Column {
                                Text("Backup de HUD / Sensibilidade", color = palette.textPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Text("Salve perfis de DPI, miras e notas de configuração", color = palette.textSecondary, fontSize = 11.sp)
                            }
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = hudName,
                            onValueChange = { hudName = it },
                            modifier = Modifier.fillMaxWidth(),
                            label = { Text("Nome do perfil (ex: Sensi Mira Branca)") },
                            singleLine = true
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            OutlinedTextField(value = hudGeneral, onValueChange = { hudGeneral = it.filter(Char::isDigit) }, modifier = Modifier.weight(1f), label = { Text("Geral") }, singleLine = true)
                            OutlinedTextField(value = hudRedDot, onValueChange = { hudRedDot = it.filter(Char::isDigit) }, modifier = Modifier.weight(1f), label = { Text("RedDot") }, singleLine = true)
                            OutlinedTextField(value = hud2x, onValueChange = { hud2x = it.filter(Char::isDigit) }, modifier = Modifier.weight(1f), label = { Text("2x") }, singleLine = true)
                            OutlinedTextField(value = hud4x, onValueChange = { hud4x = it.filter(Char::isDigit) }, modifier = Modifier.weight(1f), label = { Text("4x") }, singleLine = true)
                            OutlinedTextField(value = hudAwm, onValueChange = { hudAwm = it.filter(Char::isDigit) }, modifier = Modifier.weight(1f), label = { Text("AWM") }, singleLine = true)
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        OutlinedTextField(
                            value = hudNotes,
                            onValueChange = { hudNotes = it },
                            modifier = Modifier.fillMaxWidth(),
                            label = { Text("Notas de HUD / Botão de tiro") },
                            singleLine = true
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Button(
                            onClick = {
                                onSaveHudProfile(
                                    hudName,
                                    customDpiInput.toIntOrNull() ?: dpiState.currentSmallestWidthDpi,
                                    hudGeneral.toIntOrNull() ?: 98,
                                    hudRedDot.toIntOrNull() ?: 95,
                                    hud2x.toIntOrNull() ?: 90,
                                    hud4x.toIntOrNull() ?: 86,
                                    hudAwm.toIntOrNull() ?: 65,
                                    hudNotes
                                )
                                hudName = ""
                                hudNotes = ""
                            },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = palette.accent),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("Salvar Perfil de Sensibilidade", fontWeight = FontWeight.ExtraBold, fontSize = 12.sp)
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            hudProfiles.forEach { profile ->
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(Color(0xFF18181F))
                                        .border(1.dp, palette.subtleBorder, RoundedCornerShape(12.dp))
                                        .padding(10.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(profile.name, color = palette.textPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                        Text("${profile.dpi} DPI", color = palette.accent, fontWeight = FontWeight.ExtraBold, fontFamily = FontFamily.Monospace, fontSize = 11.sp)
                                    }
                                    Text(
                                        text = "Geral ${profile.general} · Red ${profile.redDot} · 2x ${profile.scope2x} · 4x ${profile.scope4x} · AWM ${profile.awm}",
                                        color = palette.textSecondary,
                                        fontSize = 10.sp,
                                        fontFamily = FontFamily.Monospace
                                    )
                                    if (profile.notes.isNotBlank()) {
                                        Text(profile.notes, color = palette.textSecondary, fontSize = 10.sp)
                                    }
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        OutlinedButton(onClick = { onApplyHudProfile(profile) }, modifier = Modifier.weight(1f), shape = RoundedCornerShape(10.dp)) {
                                            Text("Restaurar / Aplicar DPI", color = palette.textPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                        }
                                        IconButton(onClick = { onDeleteHudProfile(profile.id) }) {
                                            Icon(Icons.Default.DeleteOutline, contentDescription = "Remover perfil", tint = palette.danger)
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // Teste de Toque (Hz)
                    NexgtCard {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Icon(Icons.Default.TouchApp, contentDescription = null, tint = palette.accent)
                                Text("Teste de Toque (Hz)", color = palette.textPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            }
                            Text("$touchHz Hz", color = palette.accent, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, fontFamily = FontFamily.Monospace)
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(86.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color(0xFF0E0E13))
                                .border(1.dp, palette.subtleBorder, RoundedCornerShape(12.dp))
                                .pointerInput(Unit) {
                                    awaitEachGesture {
                                        while (true) {
                                            awaitPointerEvent()
                                            val now = System.currentTimeMillis()
                                            if (lastEventMs > 0L) {
                                                val delta = (now - lastEventMs).coerceAtLeast(1L)
                                                touchHz = (1000L / delta).toInt().coerceIn(30, 1000)
                                            }
                                            lastEventMs = now
                                        }
                                    }
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Text("Deslize o dedo aqui para medir a taxa de toque", color = palette.textSecondary, fontSize = 11.sp)
                        }
                    }
                }
            }
        }

        // === ACORDEÃO 2: OTIMIZAÇÕES GAMER AVANÇADAS ===
        item {
            ToolsAccordionHeader(
                title = "Otimizações Gamer & Highlight",
                subtitle = "Shaders, DNS Anti-Lag, Gravador Liso e Trava de Borda",
                expanded = expandedSection == "gamer",
                onClick = { expandedSection = if (expandedSection == "gamer") "" else "gamer" }
            )
            AnimatedVisibility(
                visible = expandedSection == "gamer",
                enter = fadeIn(tween(150)) + expandVertically(tween(150)),
                exit = fadeOut(tween(150)) + shrinkVertically(tween(150))
            ) {
                Column(modifier = Modifier.padding(top = 10.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    // 1. Limpador de Cache de Shaders
                    NexgtCard(highlighted = shaderCleanResult != null) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            RiskTagBadge(FeatureRiskLevel.SAFE)
                            FeatureHelpButton(onClick = { activeHelp = NexgtCatalog.getToolHelp("shader_cleaner", targetPackage) })
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Default.AutoFixHigh, contentDescription = null, tint = palette.accent)
                            Column {
                                Text("Limpador de Cache de Shaders", color = palette.textPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Text("Anti-engasgo pós-atualização • Mantém login, HUD e OBB intactos", color = palette.textSecondary, fontSize = 11.sp)
                            }
                        }
                        if (shaderCleanResult != null) {
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "${shaderCleanResult.clearedFilesCount} shaders antigos removidos (+${shaderCleanResult.freedMb} MB) em ${shaderCleanResult.targetPackage}",
                                color = palette.success,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Button(onClick = onCleanShaders, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = palette.accent), shape = RoundedCornerShape(12.dp)) {
                            Text("LIMPAR SHADERS AGORA (1 TOQUE)", fontWeight = FontWeight.ExtraBold, fontSize = 11.sp)
                        }
                    }

                    // 2. Escudo de Ping & DNS Gamer
                    NexgtCard(highlighted = dnsShieldState.active) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            RiskTagBadge(FeatureRiskLevel.ADVANCED)
                            FeatureHelpButton(onClick = { activeHelp = NexgtCatalog.getToolHelp("dns_shield", targetPackage) })
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Default.NetworkCheck, contentDescription = null, tint = palette.accent)
                            Column {
                                Text("Escudo de Ping & DNS Gamer (Anti-Lag)", color = palette.textPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Text("Testa Cloudflare, Google e OpenDNS e trava tráfego paralelo", color = palette.textSecondary, fontSize = 11.sp)
                            }
                        }
                        if (dnsShieldState.results.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                dnsShieldState.results.forEach { res ->
                                    val winner = dnsShieldState.selectedDns?.id == res.id
                                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text(
                                            text = "${if (winner) "★ " else ""}${res.name} (${res.ip})",
                                            color = if (winner) palette.success else palette.textSecondary,
                                            fontSize = 11.sp,
                                            fontWeight = if (winner) FontWeight.Bold else FontWeight.Normal
                                        )
                                        Text("${res.pingMs} ms", color = if (winner) palette.success else palette.textPrimary, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                                    }
                                }
                            }
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = onActivateDnsShield,
                                enabled = !dnsShieldState.isTesting,
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(containerColor = palette.accent),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Text(if (dnsShieldState.isTesting) "TESTANDO DNS..." else "ATIVAR ESCUDO ANTI-LAG", fontWeight = FontWeight.ExtraBold, fontSize = 11.sp)
                            }
                            if (dnsShieldState.active) {
                                OutlinedButton(onClick = onDisableDnsShield, shape = RoundedCornerShape(12.dp)) {
                                    Text("Desligar", color = palette.danger, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }

                    // 3. Modo "Gravador Liso"
                    NexgtCard(highlighted = smoothRecorderState.active) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            RiskTagBadge(FeatureRiskLevel.ADVANCED)
                            FeatureHelpButton(onClick = { activeHelp = NexgtCatalog.getToolHelp("smooth_recorder", targetPackage) })
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(modifier = Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Icon(Icons.Default.Videocam, contentDescription = null, tint = palette.accent)
                                Column {
                                    Text("Modo \"Gravador Liso\" (Clipadas)", color = palette.textPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                    Text("Prioridade dupla CPU/GPU para jogo + gravador de tela", color = palette.textSecondary, fontSize = 11.sp)
                                }
                            }
                            NexgtSwitch(
                                checked = smoothRecorderState.active,
                                onCheckedChange = { onToggleSmoothRecorder(smoothRecorderState.recorderPackage, smoothRecorderState.recorderLabel) }
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(NexgtCatalog.recorderApps) { (pkg, label) ->
                                val selected = smoothRecorderState.recorderPackage == pkg
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(if (selected) palette.accent else Color(0xFF1A1A22))
                                        .clickable { onToggleSmoothRecorder(pkg, label) }
                                        .padding(horizontal = 10.dp, vertical = 6.dp)
                                ) {
                                    Text(label, color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }

                    // 4. Bloqueador de Gestos Acidentais (Trava de Borda)
                    NexgtCard(highlighted = edgeLockState.active) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            RiskTagBadge(FeatureRiskLevel.ADVANCED)
                            FeatureHelpButton(onClick = { activeHelp = NexgtCatalog.getToolHelp("edge_lock", targetPackage) })
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(modifier = Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Icon(Icons.Default.ScreenLockPortrait, contentDescription = null, tint = palette.accent)
                                Column {
                                    Text("Bloqueador de Gestos (Trava de Borda)", color = palette.textPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                    Text("Força immersive.full evitando Voltar ou barra de status no capa", color = palette.textSecondary, fontSize = 11.sp)
                                }
                            }
                            NexgtSwitch(checked = edgeLockState.active, onCheckedChange = { onToggleEdgeLock() })
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            EdgeLockScope.entries.forEach { scope ->
                                val active = edgeLockState.scope == scope
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(if (active) palette.accent else Color(0xFF1A1A22))
                                        .clickable { onSetEdgeLockScope(scope) }
                                        .padding(vertical = 8.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(scope.label, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }

        // === ACORDEÃO 3: MEMÓRIA RAM, RESFRIAMENTO & RELATÓRIO ===
        item {
            ToolsAccordionHeader(
                title = "Memória RAM, Resfriamento & Domingo",
                subtitle = "Cool Down 2 min (°C), Limpeza 3 Passos e Resumo",
                expanded = expandedSection == "ram",
                onClick = { expandedSection = if (expandedSection == "ram") "" else "ram" }
            )
            AnimatedVisibility(
                visible = expandedSection == "ram",
                enter = fadeIn(tween(150)) + expandVertically(tween(150)),
                exit = fadeOut(tween(150)) + shrinkVertically(tween(150))
            ) {
                Column(modifier = Modifier.padding(top = 10.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    // Resfriamento Rápido (Cool Down Pós-Partida)
                    NexgtCard(highlighted = coolDownState.active) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            RiskTagBadge(FeatureRiskLevel.HARDWARE)
                            FeatureHelpButton(onClick = { activeHelp = NexgtCatalog.getToolHelp("cool_down", targetPackage) })
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(modifier = Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Icon(Icons.Default.Thermostat, contentDescription = null, tint = palette.accent)
                                Column {
                                    Text("Resfriamento Rápido (Cool Down)", color = palette.textPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                    Text("Fecha jogo, reduz brilho por 2 min e monitora bateria °C", color = palette.textSecondary, fontSize = 11.sp)
                                }
                            }
                            Text(
                                text = String.format("%.1f°C", coolDownState.currentTempCelsius),
                                color = if (coolDownState.active) Color(0xFF38BDF8) else palette.accent,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.ExtraBold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                        if (coolDownState.active) {
                            val mins = coolDownState.remainingSeconds / 60
                            val secs = coolDownState.remainingSeconds % 60
                            Spacer(modifier = Modifier.height(8.dp))
                            LinearProgressIndicator(
                                progress = { (coolDownState.remainingSeconds / 120f).coerceIn(0f, 1f) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(7.dp)
                                    .clip(CircleShape),
                                color = Color(0xFF38BDF8),
                                trackColor = Color(0xFF1F242D)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Tempo restante: %02d:%02d • Inicial %.1f°C -> Atual %.1f°C".format(
                                    mins, secs, coolDownState.startTempCelsius, coolDownState.currentTempCelsius
                                ),
                                color = Color(0xFF38BDF8),
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        if (coolDownState.active) {
                            OutlinedButton(onClick = onStopCoolDown, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)) {
                                Text("Encerrar Cool Down e Restaurar Brilho", color = palette.textPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        } else {
                            Button(onClick = onStartCoolDown, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = palette.accent), shape = RoundedCornerShape(12.dp)) {
                                Text("INICIAR RESFRIAMENTO (2 MIN)", fontWeight = FontWeight.ExtraBold, fontSize = 11.sp)
                            }
                        }
                    }

                    // Limpeza Real de RAM (3 Passos)
                    NexgtCard(highlighted = lastCleanResult != null) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            RiskTagBadge(FeatureRiskLevel.SAFE)
                            FeatureHelpButton(onClick = { activeHelp = NexgtCatalog.getToolHelp("ram_clean", targetPackage) })
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Default.CleaningServices, contentDescription = null, tint = palette.accent)
                            Column {
                                Text("Jogar Fora RAM Ocupada (Limpeza Real)", color = palette.textPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Text("Passos A (killBg), B (am force-stop) e C (System.gc)", color = palette.textSecondary, fontSize = 11.sp)
                            }
                        }
                        if (lastCleanResult != null) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "Resultado: +${lastCleanResult.ramFreedMb} MB RAM • ${lastCleanResult.stepABackgroundKilled} bg • ${lastCleanResult.stepBForceStopped} force-stop • +${lastCleanResult.spaceSavedMb} MB",
                                color = palette.success,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        Button(
                            onClick = onRunDeepRamClean,
                            enabled = !isCleaningRam,
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = palette.accent),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text(
                                text = if (isCleaningRam) "EXECUTANDO LIMPEZA..." else "EXECUTAR LIMPEZA REAL DE RAM",
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 11.sp
                            )
                        }
                    }

                    // Relatório Semanal Resumido
                    NexgtCard {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(modifier = Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Icon(Icons.Default.NotificationsActive, contentDescription = null, tint = palette.accent)
                                Column {
                                    Text("Relatório Semanal (Domingo)", color = palette.textPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                    Text("Notificação discreta dominical com economia", color = palette.textSecondary, fontSize = 11.sp)
                                }
                            }
                            NexgtSwitch(checked = weeklyStats.sundayReportEnabled, onCheckedChange = { onToggleWeeklyReport() })
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        val spaceTxt = WeeklyReportScheduler.formatMbOrGb(weeklyStats.savedSpaceMb)
                        val ramTxt = WeeklyReportScheduler.formatMbOrGb(weeklyStats.ramFreedMb)
                        Text(
                            text = "Espaço: $spaceTxt • RAM: $ramTxt • Nota: ${systemScore.score}/100",
                            color = palette.accent,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedButton(onClick = onPreviewWeeklyNotification, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)) {
                            Text("Testar Notificação Discreta de Domingo", color = palette.textPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // === ACORDEÃO 4: APPS, TEMAS & SHIZUKU ===
        item {
            ToolsAccordionHeader(
                title = "Sistema, Congelador & Shizuku",
                subtitle = "10 Temas, Freezer sem Sistema, Terminal, Settings e Logs",
                expanded = expandedSection == "system",
                onClick = { expandedSection = if (expandedSection == "system") "" else "system" }
            )
            AnimatedVisibility(
                visible = expandedSection == "system",
                enter = fadeIn(tween(150)) + expandVertically(tween(150)),
                exit = fadeOut(tween(150)) + shrinkVertically(tween(150))
            ) {
                Column(modifier = Modifier.padding(top = 10.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    // Cor do App (10 temas)
                    NexgtCard {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Default.Palette, contentDescription = null, tint = palette.accent)
                            Text("Cor do App (10 Temas)", color = palette.textPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            items(NexgtThemes.all, key = { it.id }) { theme ->
                                val active = theme.id == selectedTheme.id
                                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.clickable { onSelectTheme(theme) }) {
                                    Box(
                                        modifier = Modifier
                                            .size(38.dp)
                                            .clip(CircleShape)
                                            .background(theme.accent)
                                            .border(if (active) 2.5.dp else 1.dp, if (active) Color.White else palette.subtleBorder, CircleShape),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        if (active) Icon(Icons.Default.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(theme.name.substringBefore(" "), color = if (active) palette.textPrimary else palette.textSecondary, fontSize = 10.sp)
                                }
                            }
                        }
                    }

                    // Congelador de Apps
                    NexgtCard {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Icon(Icons.Default.AcUnit, contentDescription = null, tint = palette.accent)
                                Column {
                                    Text("Congelador de Apps", color = palette.textPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                    Text("Qualquer app instalado (sistema protegido)", color = palette.textSecondary, fontSize = 11.sp)
                                }
                            }
                            OutlinedButton(onClick = onUnfreezeAllApps) {
                                Text("Descongelar", color = palette.accent, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = appSearchQuery,
                            onValueChange = { appSearchQuery = it },
                            modifier = Modifier.fillMaxWidth(),
                            placeholder = { Text("Buscar app instalado...") },
                            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = palette.accent) },
                            singleLine = true
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf("Todos", "Ativos", "Congelados").forEach { tab ->
                                val active = freezerFilter == tab
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(if (active) palette.accent else Color(0xFF1A1A22))
                                        .clickable { freezerFilter = tab }
                                        .padding(vertical = 8.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(tab, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        if (filteredUserApps.isEmpty()) {
                            Text("Nenhum app encontrado.", color = palette.textSecondary, fontSize = 12.sp)
                        } else {
                            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                filteredUserApps.forEach { app ->
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(10.dp))
                                            .background(if (app.isFrozen) palette.accentSoft else Color(0xFF16161C))
                                            .border(1.dp, if (app.isFrozen) palette.accent else palette.subtleBorder, RoundedCornerShape(10.dp))
                                            .padding(horizontal = 10.dp, vertical = 8.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(app.name, color = palette.textPrimary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                            Text(app.packageName, color = palette.textSecondary, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                                        }
                                        NexgtSwitch(checked = app.isFrozen, onCheckedChange = { onToggleFreezeApp(app.packageName) })
                                    }
                                }
                            }
                        }
                    }

                    // Central Shizuku + Terminal
                    NexgtCard {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Icon(Icons.Default.Terminal, contentDescription = null, tint = palette.accent)
                                Text("Central Shizuku", color = palette.textPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            }
                            Text("UID: ${shizukuUid ?: "--"} | API: ${shizukuVersion ?: "--"}", color = palette.accent, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text("Estado: ${shizukuState.name}", color = palette.textSecondary, fontSize = 12.sp)
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(value = terminalCmd, onValueChange = { terminalCmd = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Comando Shell Rápido") }, singleLine = true)
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = { onRunTerminalCommand(terminalCmd) }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = palette.accent)) {
                                Text("Executar", fontWeight = FontWeight.Bold)
                            }
                            OutlinedButton(onClick = onConnectShizuku, modifier = Modifier.weight(1f)) {
                                Text("Autorizar", color = palette.textPrimary)
                            }
                        }
                    }

                    // Editor Settings
                    NexgtCard {
                        Text("Editor de Configurações (Settings)", color = palette.textPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf("system", "secure", "global").forEach { table ->
                                val active = settingsTable == table
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(if (active) palette.accent else Color(0xFF1A1A22))
                                        .clickable { settingsTable = table }
                                        .padding(vertical = 8.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(table, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(value = settingKey, onValueChange = { settingKey = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Chave (key)") }, singleLine = true)
                        Spacer(modifier = Modifier.height(6.dp))
                        OutlinedTextField(value = settingValue, onValueChange = { settingValue = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Valor (value)") }, singleLine = true)
                        Spacer(modifier = Modifier.height(8.dp))
                        Button(onClick = { onApplySetting(settingsTable, settingKey, settingValue) }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = palette.accent)) {
                            Text("Aplicar settings put $settingsTable", fontWeight = FontWeight.Bold)
                        }
                    }

                    // Modo Banco + Restaurar + Desinstalar
                    NexgtCard {
                        Text("Funções Ativas (${activeTweaks.size})", color = palette.textPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Icon(Icons.Default.Security, contentDescription = null, tint = palette.accent)
                                Column {
                                    Text("Modo Banco", color = palette.textPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                    Text("Suspende overlays ao abrir bancos", color = palette.textSecondary, fontSize = 11.sp)
                                }
                            }
                            NexgtSwitch(checked = bankMode, onCheckedChange = { onToggleBankMode() })
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = onRestoreAll, modifier = Modifier.weight(1f)) {
                                Icon(Icons.Default.Restore, contentDescription = null, tint = palette.textPrimary, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Restaurar Tudo", color = palette.textPrimary, fontSize = 11.sp)
                            }
                            Button(onClick = onUninstallWithCleanup, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = palette.danger)) {
                                Icon(Icons.Default.DeleteForever, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Desinstalar", fontSize = 11.sp)
                            }
                        }
                    }

                    // Logs reais
                    NexgtCard {
                        Text("Registro de Atividades (Shell Real)", color = palette.textPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Spacer(modifier = Modifier.height(8.dp))
                        if (logs.isEmpty()) {
                            Text("Nenhuma saída registrada ainda.", color = palette.textSecondary, fontSize = 12.sp)
                        } else {
                            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                logs.take(12).forEach { log ->
                                    Column(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(10.dp))
                                            .background(Color(0xFF09090C))
                                            .padding(8.dp)
                                    ) {
                                        Text("[${log.timestamp}] ${log.command}", color = if (log.success) palette.success else palette.danger, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                                        Text(log.output, color = palette.textSecondary, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Créditos oficiais
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 14.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "NEXGT / FF Boost • Criado por Raylan",
                    color = palette.textSecondary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium
                )
            }
        }
    }

    if (dpiState.pendingConfirmation) {
        Dialog(
            onDismissRequest = onRestoreBackupDpi,
            properties = DialogProperties(dismissOnBackPress = false, dismissOnClickOutside = false)
        ) {
            NexgtCard(highlighted = true) {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text("CONFIRMAR NOVA DPI?", color = palette.textPrimary, fontSize = 15.sp, fontWeight = FontWeight.ExtraBold)
                    Text("${dpiState.countdownSeconds}s", color = palette.accent, fontSize = 36.sp, fontWeight = FontWeight.ExtraBold, fontFamily = FontFamily.Monospace)
                    LinearProgressIndicator(
                        progress = { (dpiState.countdownSeconds / 15f).coerceIn(0f, 1f) },
                        modifier = Modifier.fillMaxWidth().height(7.dp).clip(CircleShape),
                        color = palette.accent,
                        trackColor = Color(0xFF222230)
                    )
                    Text(
                        text = "Aplicado: ${dpiState.appliedTargetDpi} DPI (wm density ${dpiState.appliedDensity}).\nSe não confirmar em ${dpiState.countdownSeconds}s, restauraremos a DPI anterior automaticamente.",
                        color = palette.textSecondary,
                        fontSize = 11.sp,
                        textAlign = TextAlign.Center
                    )
                    Button(
                        onClick = onConfirmKeepDpi,
                        modifier = Modifier.fillMaxWidth().height(48.dp),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = palette.accent)
                    ) {
                        Text("MANTER DPI", fontWeight = FontWeight.ExtraBold, fontSize = 13.sp)
                    }
                    OutlinedButton(
                        onClick = onRestoreBackupDpi,
                        modifier = Modifier.fillMaxWidth().height(48.dp),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Text("RESTAURAR AGORA", color = palette.danger, fontWeight = FontWeight.ExtraBold, fontSize = 13.sp)
                    }
                }
            }
        }
    }

    activeHelp?.let { help ->
        FeatureHelpDialog(
            help = help,
            onDismiss = { activeHelp = null }
        )
    }
}

@Composable
private fun ToolsAccordionHeader(
    title: String,
    subtitle: String,
    expanded: Boolean,
    onClick: () -> Unit
) {
    val palette = LocalNexgtPalette.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(if (expanded) palette.accentSoft else palette.cardSurface)
            .border(
                width = if (expanded) 1.5.dp else 1.dp,
                color = if (expanded) palette.accent else palette.subtleBorder,
                shape = RoundedCornerShape(14.dp)
            )
            .clickable { onClick() }
            .padding(horizontal = 14.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(title, color = palette.textPrimary, fontSize = 14.sp, fontWeight = FontWeight.Bold)
            Text(subtitle, color = palette.textSecondary, fontSize = 11.sp)
        }
        Icon(
            imageVector = if (expanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
            contentDescription = if (expanded) "Recolher" else "Expandir",
            tint = palette.accent
        )
    }
}
