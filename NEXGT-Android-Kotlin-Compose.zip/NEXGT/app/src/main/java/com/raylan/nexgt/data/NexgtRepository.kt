package com.raylan.nexgt.data

import android.app.ActivityManager
import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Build
import android.view.WindowManager
import java.io.RandomAccessFile

class NexgtRepository(private val context: Context) {
    private val prefs = context.getSharedPreferences("nexgt_prefs", Context.MODE_PRIVATE)

    fun getSelectedThemeId(): String = prefs.getString("theme_id", "crimson") ?: "crimson"

    fun saveSelectedThemeId(id: String) {
        prefs.edit().putString("theme_id", id).apply()
    }

    fun readBatteryTempCelsius(): Float {
        return runCatching {
            val intent = context.registerReceiver(null, android.content.IntentFilter(android.content.Intent.ACTION_BATTERY_CHANGED))
            val tenths = intent?.getIntExtra(android.os.BatteryManager.EXTRA_TEMPERATURE, 365) ?: 365
            tenths / 10f
        }.getOrDefault(36.5f)
    }

    fun loadHudProfiles(): List<HudSensitivityProfile> {
        val raw = prefs.getString("hud_profiles_v1", null) ?: return NexgtCatalog.defaultHudProfiles
        return runCatching {
            val arr = org.json.JSONArray(raw)
            (0 until arr.length()).mapNotNull { idx ->
                val obj = arr.optJSONObject(idx) ?: return@mapNotNull null
                HudSensitivityProfile(
                    id = obj.optString("id"),
                    name = obj.optString("name"),
                    dpi = obj.optInt("dpi", 600),
                    general = obj.optInt("general", 95),
                    redDot = obj.optInt("redDot", 92),
                    scope2x = obj.optInt("scope2x", 88),
                    scope4x = obj.optInt("scope4x", 84),
                    awm = obj.optInt("awm", 65),
                    notes = obj.optString("notes", "")
                )
            }.ifEmpty { NexgtCatalog.defaultHudProfiles }
        }.getOrElse { NexgtCatalog.defaultHudProfiles }
    }

    fun saveHudProfiles(profiles: List<HudSensitivityProfile>) {
        runCatching {
            val arr = org.json.JSONArray()
            profiles.forEach { p ->
                arr.put(
                    org.json.JSONObject().apply {
                        put("id", p.id)
                        put("name", p.name)
                        put("dpi", p.dpi)
                        put("general", p.general)
                        put("redDot", p.redDot)
                        put("scope2x", p.scope2x)
                        put("scope4x", p.scope4x)
                        put("awm", p.awm)
                        put("notes", p.notes)
                    }
                )
            }
            prefs.edit().putString("hud_profiles_v1", arr.toString()).apply()
        }
    }

    fun isBankModeEnabled(): Boolean = prefs.getBoolean("bank_mode", false)

    fun setBankModeEnabled(enabled: Boolean) {
        prefs.edit().putBoolean("bank_mode", enabled).apply()
    }

    fun readHardwareInfo(): HardwareInfo {
        val model = runCatching {
            val mfg = Build.MANUFACTURER.replaceFirstChar { it.uppercase() }
            if (Build.MODEL.startsWith(mfg, ignoreCase = true)) Build.MODEL else "$mfg ${Build.MODEL}"
        }.getOrDefault("Android Device")

        val soc = runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val socModel = Build.SOC_MODEL
                if (!socModel.isNullOrBlank() && socModel != "unknown") socModel else Build.HARDWARE
            } else {
                Build.HARDWARE
            }
        }.getOrDefault("ARM64 SoC")

        val refreshHz = runCatching {
            val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
            @Suppress("DEPRECATION")
            val display = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                context.display ?: wm.defaultDisplay
            } else {
                wm.defaultDisplay
            }
            display?.mode?.refreshRate?.toInt() ?: 60
        }.getOrDefault(60)

        val memPair = runCatching {
            val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val memInfo = ActivityManager.MemoryInfo()
            am.getMemoryInfo(memInfo)
            val totalMb = (memInfo.totalMem / (1024L * 1024L)).coerceAtLeast(readProcMemTotalMb())
            val freeMb = memInfo.availMem / (1024L * 1024L)
            totalMb to freeMb
        }.getOrDefault(0L to 0L)

        return HardwareInfo(
            model = model,
            socOrGpu = soc,
            refreshRateHz = refreshHz,
            androidVersion = Build.VERSION.RELEASE ?: "14",
            totalRamMb = memPair.first,
            freeRamMb = memPair.second
        )
    }

    private fun readProcMemTotalMb(): Long {
        return runCatching {
            RandomAccessFile("/proc/meminfo", "r").use { raf ->
                val line = raf.readLine() ?: return@use 0L
                val kb = line.replace(Regex("[^0-9]"), "").toLongOrNull() ?: 0L
                kb / 1024L
            }
        }.getOrDefault(0L)
    }

    fun isWeeklyReportEnabled(): Boolean = prefs.getBoolean("weekly_report_enabled", true)

    fun setWeeklyReportEnabled(enabled: Boolean) {
        prefs.edit().putBoolean("weekly_report_enabled", enabled).apply()
    }

    fun saveLastActiveFunctions(count: Int) {
        prefs.edit().putInt("last_active_functions", count).apply()
    }

    fun getWeeklyReportStats(): WeeklyReportStats {
        return WeeklyReportStats(
            savedSpaceMb = prefs.getLong("weekly_saved_space_mb", 0L),
            ramFreedMb = prefs.getLong("weekly_ram_freed_mb", 0L),
            cleanCount = prefs.getInt("weekly_clean_count", 0),
            appsStoppedCount = prefs.getInt("weekly_apps_stopped", 0),
            lastCleanTimestampMs = prefs.getLong("last_clean_timestamp_ms", 0L),
            sundayReportEnabled = isWeeklyReportEnabled(),
            lastKnownActiveFunctions = prefs.getInt("last_active_functions", 3)
        )
    }

    fun recordDeepCleanStats(
        savedSpaceMb: Long,
        ramFreedMb: Long,
        appsStopped: Int,
        nowMs: Long = System.currentTimeMillis()
    ): WeeklyReportStats {
        val current = getWeeklyReportStats()
        val updatedSpace = current.savedSpaceMb + savedSpaceMb.coerceAtLeast(0L)
        val updatedRam = current.ramFreedMb + ramFreedMb.coerceAtLeast(0L)
        val updatedCount = current.cleanCount + 1
        val updatedApps = current.appsStoppedCount + appsStopped.coerceAtLeast(0)
        prefs.edit()
            .putLong("weekly_saved_space_mb", updatedSpace)
            .putLong("weekly_ram_freed_mb", updatedRam)
            .putInt("weekly_clean_count", updatedCount)
            .putInt("weekly_apps_stopped", updatedApps)
            .putLong("last_clean_timestamp_ms", nowMs)
            .apply()
        return getWeeklyReportStats()
    }

    fun readFreeRamMb(): Long {
        return runCatching {
            val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val memInfo = ActivityManager.MemoryInfo()
            am.getMemoryInfo(memInfo)
            memInfo.availMem / (1024L * 1024L)
        }.getOrDefault(0L)
    }

    // Passo A — Matar processos em segundo plano não essenciais via ActivityManager
    fun killBackgroundUserApps(excludePackage: String): List<String> {
        return runCatching {
            val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val userApps = getInstalledUserApps()
                .filter { it.packageName != excludePackage && it.packageName != context.packageName && !it.isSystem }
            val killed = mutableListOf<String>()
            userApps.forEach { app ->
                runCatching {
                    am.killBackgroundProcesses(app.packageName)
                    killed.add(app.packageName)
                }
            }
            killed
        }.getOrElse { emptyList() }
    }

    // Passo C — Acionar Garbage Collector antes de finalizar a otimização
    fun triggerGarbageCollector() {
        runCatching {
            System.gc()
            Runtime.getRuntime().gc()
        }
    }

    // Lista TODOS os apps instalados pelo usuário, excluindo estritamente apps de sistema e o próprio NEXGT
    fun getInstalledUserApps(): List<GameAppItem> {
        return runCatching {
            val pm = context.packageManager
            val apps = pm.getInstalledApplications(PackageManager.GET_META_DATA)
            apps.filter { app ->
                val isSystem = (app.flags and ApplicationInfo.FLAG_SYSTEM) != 0
                val isUpdatedSystem = (app.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0
                app.packageName != context.packageName && !isSystem && !isUpdatedSystem
            }.map { app ->
                val label = runCatching { pm.getApplicationLabel(app).toString() }.getOrDefault(app.packageName)
                GameAppItem(
                    packageName = app.packageName,
                    name = label,
                    isAdded = false,
                    isFrozen = !app.enabled,
                    isSystem = false
                )
            }.sortedBy { it.name.lowercase() }
        }.getOrElse { emptyList() }
    }
}
