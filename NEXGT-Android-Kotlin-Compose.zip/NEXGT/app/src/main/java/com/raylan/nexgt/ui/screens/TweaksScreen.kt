package com.raylan.nexgt.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.raylan.nexgt.data.FeatureRiskLevel
import com.raylan.nexgt.data.NexgtCatalog
import com.raylan.nexgt.data.TweakCategory
import com.raylan.nexgt.data.TweakItem
import com.raylan.nexgt.ui.components.FeatureHelpButton
import com.raylan.nexgt.ui.components.FeatureHelpDialog
import com.raylan.nexgt.ui.components.NexgtCard
import com.raylan.nexgt.ui.components.NexgtSwitch
import com.raylan.nexgt.ui.components.RiskTagBadge
import com.raylan.nexgt.ui.theme.LocalNexgtPalette

@Composable
fun TweaksScreen(
    tweaks: List<TweakItem>,
    onToggleTweak: (String) -> Unit,
    onToggleCategory: (TweakCategory, Boolean) -> Unit
) {
    val palette = LocalNexgtPalette.current
    var searchQuery by remember { mutableStateOf("") }
    var expandedCategory by remember { mutableStateOf<TweakCategory?>(TweakCategory.PERFORMANCE) }
    var infoTweak by remember { mutableStateOf<TweakItem?>(null) }

    val searchResults = remember(tweaks, searchQuery) {
        if (searchQuery.isBlank()) emptyList()
        else {
            val q = searchQuery.trim().lowercase()
            tweaks.filter {
                it.title.lowercase().contains(q) ||
                    it.summary.lowercase().contains(q) ||
                    it.enableCmd.lowercase().contains(q)
            }
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(6.dp))
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("Buscar entre ${tweaks.size} funções reais...", color = palette.textSecondary) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = palette.accent) },
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = palette.accent,
                    unfocusedBorderColor = palette.subtleBorder,
                    focusedTextColor = palette.textPrimary,
                    unfocusedTextColor = palette.textPrimary,
                    focusedContainerColor = palette.cardSurface,
                    unfocusedContainerColor = palette.cardSurface
                )
            )
        }

        if (searchQuery.isNotBlank()) {
            items(searchResults.chunked(2)) { rowItems ->
                TweakPairRow(
                    rowItems = rowItems,
                    onToggleTweak = onToggleTweak,
                    onHelpTweak = { infoTweak = it }
                )
            }
        } else {
            TweakCategory.entries.forEach { category ->
                val catTweaks = tweaks.filter { it.category == category }
                val activeInCat = catTweaks.count { it.enabled }
                val isExpanded = expandedCategory == category
                val accordionLabel = when (category) {
                    TweakCategory.PERFORMANCE -> "Desempenho & FPS"
                    TweakCategory.DISPLAY -> "Tela, Toque & DPI"
                    TweakCategory.SYSTEM -> "Memória RAM & Sistema"
                    TweakCategory.SOUND -> "Som & Áudio"
                    TweakCategory.INTERNET -> "Internet & Anti-Lag"
                }

                item(key = "header_${category.name}") {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(if (isExpanded) palette.accentSoft else palette.cardSurface)
                            .border(
                                width = if (isExpanded) 1.5.dp else 1.dp,
                                color = if (isExpanded) palette.accent else palette.subtleBorder,
                                shape = RoundedCornerShape(14.dp)
                            )
                            .clickable {
                                expandedCategory = if (isExpanded) null else category
                            }
                            .padding(horizontal = 14.dp, vertical = 12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = accordionLabel,
                                color = palette.textPrimary,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "${catTweaks.size} funções • $activeInCat ativas",
                                color = palette.textSecondary,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                        Icon(
                            imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                            contentDescription = if (isExpanded) "Recolher" else "Expandir",
                            tint = palette.accent
                        )
                    }

                    AnimatedVisibility(
                        visible = isExpanded,
                        enter = fadeIn(tween(150)) + expandVertically(tween(150)),
                        exit = fadeOut(tween(150)) + shrinkVertically(tween(150))
                    ) {
                        Column(
                            modifier = Modifier.padding(top = 10.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Button(
                                    onClick = { onToggleCategory(category, true) },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(12.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = palette.accent)
                                ) {
                                    Text("Ativar Todas (${catTweaks.size})", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                                OutlinedButton(
                                    onClick = { onToggleCategory(category, false) },
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Text("Desativar", color = palette.textPrimary, fontSize = 11.sp)
                                }
                            }

                            catTweaks.chunked(2).forEach { rowItems ->
                                TweakPairRow(
                                    rowItems = rowItems,
                                    onToggleTweak = onToggleTweak,
                                    onHelpTweak = { infoTweak = it }
                                )
                            }
                        }
                    }
                }
            }
        }

        item { Spacer(modifier = Modifier.height(16.dp)) }
    }

    infoTweak?.let { item ->
        FeatureHelpDialog(
            help = NexgtCatalog.getTweakHelp(item),
            onDismiss = { infoTweak = null }
        )
    }
}

@Composable
private fun TweakPairRow(
    rowItems: List<TweakItem>,
    onToggleTweak: (String) -> Unit,
    onHelpTweak: (TweakItem) -> Unit
) {
    val palette = LocalNexgtPalette.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(IntrinsicSize.Max),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        rowItems.forEach { item ->
            val risk = if (
                item.id.startsWith("perf_01") ||
                item.id.startsWith("perf_06") ||
                item.id.startsWith("perf_17") ||
                item.id.startsWith("disp_20")
            ) {
                FeatureRiskLevel.ADVANCED
            } else {
                FeatureRiskLevel.SAFE
            }
            NexgtCard(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight(),
                highlighted = item.enabled
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RiskTagBadge(risk = risk)
                    FeatureHelpButton(onClick = { onHelpTweak(item) })
                }
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = item.title,
                    color = palette.textPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = item.summary,
                    color = palette.textSecondary,
                    fontSize = 10.sp,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (item.enabled) "ATIVO" else "INATIVO",
                        color = if (item.enabled) palette.accent else palette.textSecondary,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.ExtraBold,
                        fontFamily = FontFamily.Monospace
                    )
                    NexgtSwitch(
                        checked = item.enabled,
                        onCheckedChange = { onToggleTweak(item.id) }
                    )
                }
            }
        }
        if (rowItems.size == 1) {
            Spacer(modifier = Modifier.weight(1f))
        }
    }
}

